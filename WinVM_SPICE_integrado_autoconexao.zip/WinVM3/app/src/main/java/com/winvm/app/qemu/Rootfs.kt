package com.winvm.app.qemu

import android.content.Context
import android.system.Os
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.zip.GZIPInputStream

/** Alpine Linux (arm64) rodando via proot; o QEMU é instalado dentro dele com o apk. */
object Rootfs {
    private const val MIRROR = "https://dl-cdn.alpinelinux.org/alpine"

    fun dir(ctx: Context) = File(ctx.filesDir, "rootfs")
    private fun readyMark(ctx: Context) = File(ctx.filesDir, "rootfs.ready")
    private fun noSeccompMark(ctx: Context) = File(ctx.filesDir, "proot.noseccomp")
    private fun nativeDir(ctx: Context) = ctx.applicationInfo.nativeLibraryDir

    fun prootBin(ctx: Context) = File(nativeDir(ctx), "libproot.so")
    fun hasProot(ctx: Context) =
        prootBin(ctx).exists() && File(nativeDir(ctx), "libproot-loader.so").exists()

    /** O Alpine (busybox) tem o comando taskset? (links simbólicos absolutos: olha o link, não o destino) */
    fun hasTaskset(ctx: Context): Boolean {
        val root = dir(ctx)
        return listOf("usr/bin/taskset", "bin/taskset", "usr/sbin/taskset", "sbin/taskset").any {
            java.nio.file.Files.exists(File(root, it).toPath(), java.nio.file.LinkOption.NOFOLLOW_LINKS)
        }
    }

    fun isReady(ctx: Context) =
        readyMark(ctx).exists() && File(dir(ctx), "usr/bin/qemu-system-x86_64").exists()

    private fun spiceMark(ctx: Context) = File(ctx.filesDir, "rootfs.spice")
    fun hasSpice(ctx: Context) = spiceMark(ctx).exists()

    /** Instala os módulos SPICE do QEMU no Alpine (uma vez, precisa de internet). true = pronto. */
    suspend fun ensureSpice(ctx: Context, onLine: (String) -> Unit = {}): Boolean {
        if (hasSpice(ctx)) return true
        val code = runGuest(
            ctx,
            listOf("/sbin/apk", "add", "--no-cache", "qemu-ui-spice-core", "qemu-hw-display-qxl", "qemu-chardev-spice", "py3-websockify"),
            null,
            onLine = onLine
        )
        if (code == 0) spiceMark(ctx).writeText("1")
        return code == 0
    }

    /** Monta a linha de comando do proot. vmDir (opcional) aparece dentro do Linux como /vm. */
    fun prootCommand(
        ctx: Context,
        vmDir: File?,
        guest: List<String>,
        extraBinds: List<Pair<String, String>> = emptyList()
    ): List<String> = buildList {
        add(prootBin(ctx).path)
        addAll(listOf("-0", "--link2symlink", "--kill-on-exit"))
        addAll(listOf("-r", dir(ctx).path))
        addAll(listOf("-b", "/dev", "-b", "/proc", "-b", "/sys"))
        if (vmDir != null) addAll(listOf("-b", "${vmDir.path}:/vm"))
        for ((host, inside) in extraBinds) addAll(listOf("-b", "$host:$inside"))
        addAll(listOf("-w", "/root"))
        add("/usr/bin/env"); add("-i")
        add("HOME=/root")
        add("PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin")
        add("TERM=xterm-256color")
        addAll(guest)
    }

    fun applyEnv(ctx: Context, pb: ProcessBuilder) {
        val env = pb.environment()
        val tmp = File(ctx.cacheDir, "proot-tmp").apply { mkdirs() }
        env["PROOT_LOADER"] = "${nativeDir(ctx)}/libproot-loader.so"
        env["PROOT_TMP_DIR"] = tmp.path
        env["LD_LIBRARY_PATH"] = nativeDir(ctx)
        if (noSeccompMark(ctx).exists()) env["PROOT_NO_SECCOMP"] = "1"
    }

    /** Executa um comando dentro do Alpine e espera terminar. Devolve o código de saída. */
    suspend fun runGuest(
        ctx: Context,
        guest: List<String>,
        vmDir: File? = null,
        extraBinds: List<Pair<String, String>> = emptyList(),
        onLine: (String) -> Unit = {}
    ): Int = withContext(Dispatchers.IO) {
        val pb = ProcessBuilder(prootCommand(ctx, vmDir, guest, extraBinds))
            .directory(ctx.filesDir)
            .redirectErrorStream(true)
        applyEnv(ctx, pb)
        val p = pb.start()
        p.inputStream.bufferedReader().forEachLine(onLine)
        p.waitFor()
    }

    // ------------------------------------------------------------------ instalação

    suspend fun install(ctx: Context, log: (String) -> Unit) = withContext(Dispatchers.IO) {
        if (!hasProot(ctx)) {
            error("libproot.so não está no APK. Gere o APK pelo workflow do GitHub (ele baixa o proot).")
        }
        val root = dir(ctx)
        val extracted = File(ctx.filesDir, "rootfs.extracted")
        val branchFile = File(ctx.filesDir, "rootfs.branch")

        if (!extracted.exists() || !File(root, "sbin/apk").exists()) {
            log("Consultando a versão atual do Alpine Linux (aarch64)…")
            val yaml = open("$MIRROR/latest-stable/releases/aarch64/latest-releases.yaml")
                .inputStream.bufferedReader().use { it.readText() }
            val rel = parseLatest(yaml)
            val tgz = File(ctx.cacheDir, "rootfs.tar.gz")
            log("Baixando ${rel.file}…")
            val sha = download("$MIRROR/latest-stable/releases/aarch64/${rel.file}", tgz, log)
            if (rel.sha256 != null && !sha.equals(rel.sha256, ignoreCase = true)) {
                tgz.delete()
                error("Checksum do rootfs não confere. Tente novamente.")
            }
            log("Extraindo o sistema…")
            root.deleteRecursively(); root.mkdirs()
            extractTarGz(tgz, root, log)
            tgz.delete()
            branchFile.writeText(rel.branch)
            extracted.writeText("1")
        }

        val br = if (branchFile.exists()) branchFile.readText().trim() else "latest-stable"
        File(root, "etc").mkdirs()
        File(root, "etc/resolv.conf").writeText("nameserver 1.1.1.1\nnameserver 8.8.8.8\n")
        File(root, "etc/apk").mkdirs()
        File(root, "etc/apk/repositories").writeText(
            "http://dl-cdn.alpinelinux.org/alpine/$br/main\n" +
                "http://dl-cdn.alpinelinux.org/alpine/$br/community\n"
        )

        log("Instalando o QEMU dentro do Alpine (alguns minutos)…")
        val add = listOf("/sbin/apk", "add", "--no-cache", "qemu-system-x86_64", "qemu-img")
        var code = runGuest(ctx, add, null, onLine = log)
        if (code != 0 && !noSeccompMark(ctx).exists()) {
            log("Falhou (código $code). Tentando o modo compatível do proot…")
            noSeccompMark(ctx).writeText("1")
            code = runGuest(ctx, add, null, onLine = log)
        }
        if (code != 0) error("A instalação do QEMU falhou (código $code). Veja o log acima.")
        runGuest(ctx, listOf("/sbin/apk", "add", "--no-cache", "seabios"), null, onLine = log)

        if (!File(root, "usr/bin/qemu-system-x86_64").exists()) {
            error("qemu-system-x86_64 não encontrado após a instalação")
        }
        readyMark(ctx).writeText("1")
        log("Pronto!")
    }

    private class AlpineRelease(val file: String, val sha256: String?, val branch: String)

    private fun parseLatest(yaml: String): AlpineRelease {
        // Formato real: cada item começa com "-" sozinho na linha, seguido de campos indentados.
        val blocks = yaml.split(Regex("(?m)^-(?=\\s|$)")).drop(1)
        for (b in blocks) {
            if (!Regex("(?m)^\\s*flavor:\\s*alpine-minirootfs\\s*$").containsMatchIn(b)) continue
            val file = Regex("(?m)^\\s*file:\\s*(\\S+)").find(b)?.groupValues?.get(1) ?: continue
            val sha = Regex("(?m)^\\s*sha256:\\s*([0-9a-fA-F]{64})").find(b)?.groupValues?.get(1)
            val branch = Regex("(?m)^\\s*branch:\\s*(\\S+)").find(b)?.groupValues?.get(1) ?: "latest-stable"
            return AlpineRelease(file, sha, branch)
        }
        // Plano B: procura direto o nome do arquivo no texto e deduz o branch (ex.: 3.22.1 -> v3.22)
        val m = Regex("alpine-minirootfs-(\\d+)\\.(\\d+)\\.\\d+-aarch64\\.tar\\.gz").find(yaml)
        if (m != null) {
            return AlpineRelease(m.value, null, "v${m.groupValues[1]}.${m.groupValues[2]}")
        }
        throw IllegalStateException("Não achei o minirootfs aarch64 no índice do Alpine")
    }

    private fun open(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20_000
        c.readTimeout = 30_000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "WinVM/1.0")
        return c
    }

    private fun download(url: String, dest: File, log: (String) -> Unit): String {
        val md = MessageDigest.getInstance("SHA-256")
        val c = open(url)
        val total = c.contentLengthLong
        var done = 0L
        var lastPct = -10
        c.inputStream.use { i ->
            FileOutputStream(dest).use { o ->
                val buf = ByteArray(1 shl 16)
                while (true) {
                    val r = i.read(buf)
                    if (r < 0) break
                    o.write(buf, 0, r); md.update(buf, 0, r); done += r
                    if (total > 0) {
                        val pct = (done * 100 / total).toInt()
                        if (pct >= lastPct + 10) { lastPct = pct; log("Baixando… $pct%") }
                    }
                }
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun extractTarGz(file: File, dest: File, log: (String) -> Unit) {
        dest.mkdirs()
        val destCanon = dest.canonicalPath
        var count = 0
        TarArchiveInputStream(GZIPInputStream(file.inputStream().buffered(1 shl 16))).use { tar ->
            while (true) {
                val e = tar.nextEntry ?: break
                val rel = e.name.removePrefix("./").trimStart('/')
                if (rel.isEmpty()) continue
                val out = File(dest, rel)
                if (!out.canonicalPath.startsWith(destCanon)) continue   // proteção contra path traversal
                val perms = e.mode and 0xFFF
                try {
                    when {
                        e.isDirectory -> {
                            out.mkdirs()
                            Os.chmod(out.path, perms or 0x1C0)                 // garante rwx do dono
                        }
                        e.isSymbolicLink -> {
                            out.parentFile?.mkdirs()
                            try { Os.remove(out.path) } catch (_: Exception) {}
                            Os.symlink(e.linkName, out.path)
                        }
                        e.isLink -> {
                            val target = File(dest, e.linkName.removePrefix("./").trimStart('/'))
                            out.parentFile?.mkdirs()
                            try { Os.remove(out.path) } catch (_: Exception) {}
                            try { Os.link(target.path, out.path) } catch (_: Exception) {
                                target.copyTo(out, overwrite = true)
                            }
                        }
                        e.isFile -> {
                            out.parentFile?.mkdirs()
                            if (out.exists()) out.delete()
                            FileOutputStream(out).use { tar.copyTo(it) }
                            Os.chmod(out.path, perms or 0x180)                 // rw do dono
                        }
                        else -> {}                                              // dispositivos etc.: ignora
                    }
                } catch (ex: Exception) {
                    log("aviso: ${e.name}: ${ex.message}")
                }
                count++
                if (count % 1000 == 0) log("Extraindo… $count arquivos")
            }
        }
        log("Extraídos $count itens")
    }
}
