# WinVM – frontend Android para QEMU (via Alpine Linux + proot)

Em vez de compilar o QEMU para Android, o app baixa um Alpine Linux arm64 (rootfs),
roda-o com o **proot** e instala o **QEMU** dentro dele com o `apk`.

## Gerar o APK (GitHub Actions)
O workflow baixa o `proot` pronto (repositorio do Termux) para `app/src/main/jniLibs/arm64-v8a/`
(`libproot.so`, `libproot-loader.so`, `libtalloc.so`) e compila o APK.

## Uso
1. Abra o app > **Instalar agora** (baixa ~100 MB; precisa de internet).
2. Crie a VM (escolha a ISO) e inicie. Display via VNC embutido.
Log do QEMU: files/vms/<nome>/qemu.log

## Discos e tela
- Disco principal: novo (qcow2) ou arquivo existente (.qcow2 .vhd .vhdx .vmdk .vdi .img). O formato é detectado com `qemu-img info`.
- Até 2 discos extras (IDE slots 1 e 3). O CD-ROM usa o slot 2.
- Resolução preferida (EDID) por VM; editável com a VM parada.

## USB / OTG, hardware e velocidade
- **Pendrive OTG:** na tela da VM, ⌨ > USB. O app lê o pendrive pela API USB do Android (Bulk-Only/SCSI),
  expõe como disco NBD em localhost e o QEMU o liga à VM a quente como `usb-storage` (QMP blockdev-add + device_add).
- **CPU Intel/AMD, placa de vídeo (VGA, VMware SVGA, Cirrus), memória de vídeo e resolução:** na criação e em Configurar.
- **Proporção da tela:** Original / Esticar / 4:3 / 16:9 / 16:10 (botão "Tela" na barra de teclas).
- **Inicialização mais rápida:** -nodefaults, hpet=off, 1 soquete, tb-size proporcional à RAM, qcow2 com metadados
  pré-alocados, decodificação VNC em bloco, APK sem modo depuração e **Hibernar** (savevm/loadvm) para retomar em segundos.

## Internet e som
- **Internet:** rede NAT (usa Wi-Fi/dados do celular). Placa: e1000, RTL8139, PCnet, VirtIO ou "Sem internet".
- **Som:** o QEMU grava PCM (backend `wav`) num FIFO em `files/vms/<nome>/audio.fifo`; o `AudioBridge` lê o FIFO e toca com `AudioTrack`.
  Placas: Intel HD Audio, AC97, Sound Blaster 16. Só saída (sem microfone).

## Telas e barras do sistema
- Telas normais: o sistema desenha status/navegação e o conteúdo fica entre elas.
- Tela da VM: tela cheia (barras ocultas) ou **Barras: visíveis** (botão na barra de teclas); imagem e botões respeitam o notch
  e a área de gestos. Home em grade adaptativa; Criar/Setup com largura máxima em tablets.

## HD externo / CD pela tela Configurar
- Com a VM parada: trocar/remover o CD (ISO) e adicionar até 2 HDs extras (.qcow2 .vhd .vhdx .vmdk .vdi .img).
- Os arquivos são copiados para a pasta da VM; o formato é detectado com `qemu-img info`.

## Visual
- Tema próprio (claro/escuro automático) com cantos bem arredondados: `ui/Theme.kt`.
- Componentes reutilizáveis em `ui/Common.kt` (SectionCard, PickerField, Pill).
- Início com cartões por VM (status, especificações, ações), Criar VM em seções, Instalação com terminal.
- A tela da VM (touchpad, teclas, USB, barras) não foi alterada.

## Teclado
- Teclado físico (Bluetooth / USB OTG) reconhecido na tela da VM: letras, números, símbolos, F1–F12, setas, Home/End,
  PgUp/PgDn, Ins/Del, teclado numérico, Ctrl/Alt/Shift/Win. Caps Lock e Num Lock têm botões na barra.
- Barra virtual: Shift, F1–F12 (botão "F1–F12"), Home, End, PgUp, PgDn, Ins, PrtSc, Caps, Num, Menu.

## Disco na pasta Download
- Disco novo (qcow2) é criado em `Download/WinVM/<nome>.qcow2` (interruptor na tela Criar VM). Fica visível no
  gerenciador de arquivos e sobrevive à desinstalação. Se a pasta não aceitar escrita, cai para dentro do app.
- A pasta é montada no Alpine como /ext0 (ver `DiskMounts`); esses discos usam `locking=off`.
- Excluir a VM não apaga o disco da pasta Download.

## Desempenho / inicialização
- **Disco turbo** (`cache=unsafe`): ignora fsync do convidado (padrão ligado; por VM em Configurar).
- **CPU Nehalem** como padrão de novas VMs (sem AVX2 na emulação).
- **Aquecimento do cache** do disco enquanto o QEMU inicia (`DiskWarmup`); ao retomar de hibernação lê também o fim do arquivo.
- **Wake lock** parcial enquanto há VM rodando; VNC limitado a ~25 quadros/s; conexão do display tenta a cada 250 ms; `key-delay-ms=0`.
- **Hibernar** só quando disco principal e extras são qcow2 (`VmConfig.canHibernate`).

## Inicialização turbo (segunda rodada)
- **CPU turbo** (padrão): TCG em **1 thread** (`thread=single`, sem barreiras de memória do MTTCG), no máximo **2 vCPUs**,
  CPU "Automática" = Nehalem, QEMU fixado nos núcleos rápidos via `taskset` (`CpuTopology`, só se o Alpine tiver taskset).
- **Início rápido** (padrão): o botão desligar hiberna (savevm) e o próximo início faz `-loadvm` (segundos).
  O estado salvo tem versão (`QemuCommandBuilder.HIB_VERSION`): versões incompatíveis dão boot normal em vez de falhar.
- Boot direto no disco quando não há ISO (`-boot order=c,menu=off`).

## Desempenho (2ª rodada)
- Boot: `-boot order=c,once=d` (CD só na 1ª inicialização), `smm=off`, `vmport=off`, qcow2 com `l2-cache-size=8M`, rede sem IPv6.
- Aquecimento do cache: QEMU/bibliotecas/firmware (`RootfsWarmup`), disco e ISO (`DiskWarmup`).
- `QemuBoost`: prioridade maior (nice) para as threads do QEMU/proot. HIB_VERSION=4 invalida estados hibernados antigos.

## RAM
- O controle de RAM (criar VM e Configurar) vai de 1 GB até a RAM do celular (máx. 16 GB) e avisa acima de ~60%.
- "RAM virtual" (swap/zram) exige root; o app orienta a ativar a do próprio celular. No Windows o arquivo de paginação já usa o disco.

## RAM virtual
- Por VM (Criar / Configurar): +0 a +8 GB. A memória inteira da VM vira um arquivo `ram.swap` (QEMU memory-backend-file, share=on)
  na pasta da VM; o Android mantém na RAM o que está em uso e manda o resto ao armazenamento. O arquivo é apagado ao iniciar/parar.

## SPICE integrado (cliente HTML5)
- O botão SPICE abre um cliente SPICE HTML5 dentro do próprio WinVM3 (WebView); não chama aSPICE nem bVNC.
- O build AndroidIDE baixa o cliente open-source spice-html5 e o inclui nos assets. A primeira compilação exige internet.
- Quando a VM tem SPICE ativo, o app instala no Alpine os módulos QEMU e `py3-websockify`, iniciando um proxy WebSocket local na porta SPICE + 1.
- O cliente usa o protocolo SPICE real através do WebSocket; não é VNC. O visor VNC existente continua disponível como alternativa.
- Controles de teclado/toque dependem dos recursos do cliente HTML5; teste com Windows e Linux convidados. O mouse pode funcionar como ponteiro relativo conforme o guest e a configuração QEMU.

## Build notes for AndroidIDE
1. Open the `WinVM3` folder extracted from this ZIP as a project.
2. Keep internet enabled for the first Gradle sync/build: `downloadSpiceHtml5` fetches the upstream client and bundles it in `app/src/main/assets/spice-client`.
3. Enable SPICE for the VM in Create/Configure. On first VM start the Alpine environment must have internet to install QEMU SPICE modules and `py3-websockify`.
4. In the VM display, tap **SPICE** to open the embedded HTML5 client. It connects through the local WebSocket proxy at port `${spicePort + 1}` to the QEMU SPICE port `${spicePort}`. If the upstream client shows connection fields, use host `127.0.0.1` and the WebSocket port shown by the app.

**Verification status:** this is a source-project integration; the ZIP was not compiled into an APK in this environment. AndroidIDE must download the HTML5 client and the Alpine packages, and the SPICE connection must be tested with a running VM. VNC remains available as a fallback.
