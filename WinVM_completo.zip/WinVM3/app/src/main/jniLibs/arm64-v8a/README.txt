Coloque aqui libqemu.so (qemu-system-x86_64 renomeado) e libqemu-img.so (qemu-img renomeado)
