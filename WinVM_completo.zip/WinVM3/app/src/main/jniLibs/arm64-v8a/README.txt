O workflow copia aqui libproot.so, libproot-loader.so e libtalloc.so (baixados do repositorio do Termux).
