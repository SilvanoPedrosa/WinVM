package com.winvm.app.qemu

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import com.winvm.app.model.VmConfig
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

class QemuService : Service() {

    companion object {
        private const val CHANNEL = "qemu"
        private val procs = ConcurrentHashMap<String, Process>()

        fun start(ctx: Context, cfg: VmConfig) {
            ContextCompat.startForegroundService(
                ctx, Intent(ctx, QemuService::class.java).putExtra("cfg", cfg)
            )
        }
    }

    private val running = AtomicInteger(0)

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Máquinas virtuais", NotificationManager.IMPORTANCE_LOW))
        val notif = NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("WinVM")
            .setContentText("Máquina virtual em execução")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(
            this, 1, notif,
            if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            else ServiceInfo.FOREGROUND_SERVICE_TYPE_MANIFEST
        )

        val cfg = i?.let { IntentCompat.getParcelableExtra(it, "cfg", VmConfig::class.java) }
        if (cfg == null || procs.containsKey(cfg.name)) {
            if (running.get() == 0) stopSelf()
            return START_NOT_STICKY
        }

        running.incrementAndGet()
        Thread {
            val vmDir = File(cfg.diskPath).parentFile!!
            val log = File(vmDir, "qemu.log")
            try {
                // Se a VM foi hibernada, retoma do estado salvo (e apaga o marcador: o próximo início é normal)
                val marker = File(vmDir, "hibernated")
                val resume = marker.exists()
                if (resume) marker.delete()
                val audio = cfg.audioCard != "none" && AudioBridge.start(cfg.name, vmDir)
                val cmd = Rootfs.prootCommand(this, vmDir, QemuCommandBuilder.build(cfg, resume, audio))
                log.writeText(cmd.joinToString(" ") + "\n\n")
                val pb = ProcessBuilder(cmd)
                    .directory(filesDir)
                    .redirectErrorStream(true)
                    .redirectOutput(ProcessBuilder.Redirect.appendTo(log))
                Rootfs.applyEnv(this, pb)
                val p = pb.start()
                procs[cfg.name] = p
                p.waitFor()
            } catch (e: Exception) {
                Log.e("QEMU", "falha ao iniciar", e)
                runCatching { log.appendText("ERRO: ${e.message}\n") }
            } finally {
                AudioBridge.stop(cfg.name)
                procs.remove(cfg.name)
                if (running.decrementAndGet() == 0) stopSelf()
            }
        }.start()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        procs.values.forEach { it.destroy() }
        procs.clear()
    }

    override fun onBind(i: Intent?): IBinder? = null
}
