package com.winvm.app.qemu

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import com.winvm.app.model.VmConfig
import com.winvm.app.model.VmRepository
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

class QemuService : Service() {

    companion object {
        private const val CHANNEL = "qemu"
        private val procs = ConcurrentHashMap<String, Process>()

        fun start(ctx: Context, cfg: VmConfig) {
            ContextCompat.startForegroundService(
                ctx, Intent(ctx, QemuService::class.java).putExtra("cfg", cfg)
            )
        }
    }

    private val running = AtomicInteger(0)
    private var wake: PowerManager.WakeLock? = null

    /** Mantém o processador ativo enquanto há VM rodando (tela apagada ou modo de economia não atrasam a VM). */
    private fun acquireWake() {
        if (wake == null) {
            wake = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "WinVM:vm")
                .apply { setReferenceCounted(false) }
        }
        if (wake?.isHeld != true) wake?.acquire(12L * 60L * 60L * 1000L)
    }

    private fun releaseWake() {
        runCatching { if (wake?.isHeld == true) wake?.release() }
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Máquinas virtuais", NotificationManager.IMPORTANCE_LOW))
        val notif = NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("WinVM")
            .setContentText("Máquina virtual em execução")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(
            this, 1, notif,
            if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            else ServiceInfo.FOREGROUND_SERVICE_TYPE_MANIFEST
        )

        val cfg = i?.let { IntentCompat.getParcelableExtra(it, "cfg", VmConfig::class.java) }
        if (cfg == null || procs.containsKey(cfg.name)) {
            if (running.get() == 0) stopSelf()
            return START_NOT_STICKY
        }

        acquireWake()
        running.incrementAndGet()
        Thread {
            val vmDir = File(VmRepository.root(this), cfg.name)
            val log = File(vmDir, "qemu.log")
            try {
                // Se a VM foi hibernada, retoma do estado salvo (e apaga o marcador: o próximo início é normal)
                val marker = File(vmDir, "hibernated")
                val resume = marker.exists() &&
                    runCatching { marker.readText().trim() }.getOrNull() == QemuCommandBuilder.HIB_VERSION
                if (marker.exists()) marker.delete()    // estado de outra versão do app não é compatível: início normal
                RootfsWarmup.start(this)               // QEMU, bibliotecas e firmware já no cache de memória
                DiskWarmup.start(cfg, resume)          // aquece o cache do disco enquanto o QEMU inicia
                val audio = cfg.audioCard != "none" && AudioBridge.start(cfg.name, vmDir)
                val mounts = DiskMounts(vmDir, cfg)
                val fast = if (cfg.cpuTurbo && Rootfs.hasTaskset(this)) CpuTopology.fastCores() else null
                val cmd = Rootfs.prootCommand(this, vmDir, QemuCommandBuilder.build(cfg, resume, audio, mounts, fast), mounts.binds())
                log.writeText(cmd.joinToString(" ") + "\n\n")
                val pb = ProcessBuilder(cmd)
                    .directory(filesDir)
                    .redirectErrorStream(true)
                    .redirectOutput(ProcessBuilder.Redirect.appendTo(log))
                Rootfs.applyEnv(this, pb)
                val p = pb.start()
                procs[cfg.name] = p
                QemuBoost.start(p)                     // prioridade maior para as threads da VM
                p.waitFor()
            } catch (e: Exception) {
                Log.e("QEMU", "falha ao iniciar", e)
                runCatching { log.appendText("ERRO: ${e.message}\n") }
            } finally {
                AudioBridge.stop(cfg.name)
                procs.remove(cfg.name)
                if (running.decrementAndGet() == 0) {
                    releaseWake()
                    stopSelf()
                }
            }
        }.start()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        releaseWake()
        procs.values.forEach { it.destroy() }
        procs.clear()
    }

    override fun onBind(i: Intent?): IBinder? = null
}
