package com.winvm.app.qemu

import android.app.ActivityManager
import android.content.Context

/** Memória do celular: limita o controle de RAM da VM a valores que fazem sentido. */
object DeviceMemory {
    fun totalMb(ctx: Context): Int {
        val info = ActivityManager.MemoryInfo()
        ctx.getSystemService(ActivityManager::class.java).getMemoryInfo(info)
        return (info.totalMem / (1024L * 1024L)).toInt()
    }

    /** Máximo do controle (múltiplo de 512 MB): até a RAM do celular, no máximo 16 GB, no mínimo 2 GB. */
    fun sliderMaxMb(totalMb: Int): Int = (minOf(totalMb, 16384) / 512 * 512).coerceAtLeast(2048)
}
