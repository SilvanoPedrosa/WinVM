package com.winvm.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.winvm.app.model.VmConfig
import com.winvm.app.qemu.UsbBridge
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun UsbDialog(cfg: VmConfig, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var devices by remember { mutableStateOf(UsbBridge.massStorageDevices(ctx)) }
    var attachedName by remember { mutableStateOf(UsbBridge.attachedName(cfg.name)) }
    var msg by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var readOnly by remember { mutableStateOf(false) }

    // Atualiza a lista sozinha: pendrive plugado ou tirado enquanto o diálogo está aberto
    LaunchedEffect(Unit) {
        while (true) {
            if (!busy) {
                devices = UsbBridge.massStorageDevices(ctx)
                attachedName = UsbBridge.attachedName(cfg.name)
            }
            delay(1500)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Pendrive (USB OTG)") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (attachedName != null) {
                    Text("Conectado à VM: $attachedName")
                    Button(
                        enabled = !busy,
                        onClick = {
                            scope.launch {
                                busy = true
                                msg = UsbBridge.eject(cfg)
                                attachedName = UsbBridge.attachedName(cfg.name)
                                busy = false
                            }
                        }
                    ) { Text("Ejetar da VM") }
                } else {
                    if (devices.isEmpty()) {
                        Text("Nenhum pendrive compatível encontrado. Conecte o pendrive ao cabo OTG; a lista atualiza sozinha.")
                    }
                    devices.forEach { d ->
                        OutlinedButton(
                            enabled = !busy,
                            modifier = Modifier.fillMaxWidth(),
                            onClick = {
                                scope.launch {
                                    busy = true; msg = null
                                    msg = UsbBridge.attach(ctx, d, cfg, readOnly)
                                    attachedName = UsbBridge.attachedName(cfg.name)
                                    if (msg == null) msg = "Conectado. No sistema da VM ele aparece como novo disco USB."
                                    busy = false
                                }
                            }
                        ) { Text(UsbBridge.label(d)) }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = readOnly, onCheckedChange = { readOnly = it })
                        Text("Somente leitura (mais seguro)")
                    }
                }
                if (busy) CircularProgressIndicator()
                msg?.let {
                    Text(
                        it,
                        color = if (attachedName != null) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.error
                    )
                }
                Text(
                    "Antes de tirar o pendrive: use \"Remover com segurança\" dentro do sistema da VM e depois Ejetar aqui. " +
                        "Enquanto conectado à VM, o Android não consegue ler o pendrive.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        },
        confirmButton = { TextButton(onClick = { devices = UsbBridge.massStorageDevices(ctx) }) { Text("Atualizar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Fechar") } }
    )
}
