package com.winvm.app.qemu

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.system.Os
import android.system.OsConstants
import java.io.File
import java.io.FileDescriptor
import java.io.FileInputStream
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * Som da VM: o QEMU (backend "wav") escreve o áudio PCM num FIFO dentro da pasta da VM e este objeto
 * lê o FIFO e toca com AudioTrack. A leitura nunca espera a reprodução (fila com descarte),
 * para o QEMU não travar se o Android atrasar o áudio.
 */
object AudioBridge {
    private val sessions = ConcurrentHashMap<String, Session>()

    /** Cria o FIFO e começa a tocar o que o QEMU escrever nele. false = som indisponível. */
    fun start(vmName: String, vmDir: File): Boolean {
        stop(vmName)
        return try {
            val fifo = File(vmDir, "audio.fifo")
            fifo.delete()
            Os.mkfifo(fifo.path, 0x180)                              // 0600
            val fd = Os.open(fifo.path, OsConstants.O_RDWR, 0)       // RDWR: abre sem esperar o QEMU
            val s = Session(fd)
            sessions[vmName] = s
            s.start()
            true
        } catch (e: Exception) {
            false
        }
    }

    fun stop(vmName: String) {
        sessions.remove(vmName)?.close()
    }

    private class Session(private val fd: FileDescriptor) {
        @Volatile private var running = true
        private val queue = ArrayBlockingQueue<ByteArray>(256)    // ~1,5 s de áudio

        fun start() {
            Thread({ readLoop() }, "audio-read").start()
        }

        fun close() {
            running = false
            runCatching { Os.write(fd, ByteArray(1), 0, 1) }       // acorda a leitura bloqueada
            runCatching { Os.close(fd) }
        }

        private fun readFully(inp: InputStream, buf: ByteArray): Boolean {
            var off = 0
            while (off < buf.size) {
                val n = try { inp.read(buf, off, buf.size - off) } catch (e: Exception) { return false }
                if (n < 0 || !running) return false
                off += n
            }
            return true
        }

        private fun readLoop() {
            val inp = FileInputStream(fd)
            val head = ByteArray(4)
            if (!readFully(inp, head)) return
            var rate = 44100
            var channels = 2
            if (String(head, Charsets.US_ASCII) == "RIFF") {
                val rest = ByteArray(40)                              // resto do cabeçalho WAV (44 bytes)
                if (!readFully(inp, rest)) return
                val bb = ByteBuffer.wrap(rest).order(ByteOrder.LITTLE_ENDIAN)
                channels = bb.getShort(18).toInt().coerceIn(1, 2)
                rate = bb.getInt(20).coerceIn(8000, 96000)
            }
            val mask = if (channels == 1) AudioFormat.CHANNEL_OUT_MONO else AudioFormat.CHANNEL_OUT_STEREO
            val minBuf = AudioTrack.getMinBufferSize(rate, mask, AudioFormat.ENCODING_PCM_16BIT)
            val track = try {
                AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(rate)
                            .setChannelMask(mask)
                            .build()
                    )
                    .setBufferSizeInBytes(maxOf(minBuf, rate * channels * 2 / 5))   // ~200 ms
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
            } catch (e: Exception) {
                null
            }
            if (track != null) {
                track.play()
                Thread({ playLoop(track) }, "audio-play").start()
            }
            val chunk = 1024                                          // múltiplo do tamanho do quadro
            while (running) {
                val buf = ByteArray(chunk)
                if (!readFully(inp, buf)) break
                if (track != null) queue.offer(buf)                   // cheio = descarta (nunca bloqueia)
            }
        }

        private fun playLoop(track: AudioTrack) {
            try {
                while (running) {
                    val b = queue.poll(200, TimeUnit.MILLISECONDS) ?: continue
                    track.write(b, 0, b.size)
                }
            } catch (e: Exception) {
            } finally {
                runCatching { track.stop() }
                runCatching { track.release() }
            }
        }
    }
}
