package com.winvm.app.qemu

import java.io.File

/**
 * Dá prioridade mais alta às threads do QEMU/proot enquanto a VM roda (nice negativo, se o Android permitir).
 * Complementa o taskset (núcleos rápidos): o agendador do Android passa a preferir a VM a apps em segundo plano.
 */
object QemuBoost {
    @Volatile private var level = -8

    fun start(p: java.lang.Process) {
        Thread({
            while (p.isAlive) {
                runCatching { applyToChildren() }
                Thread.sleep(5000)
            }
        }, "qemu-boost").apply { isDaemon = true }.start()
    }

    private fun applyToChildren() {
        val me = android.os.Process.myPid()
        val pids = File("/proc").list()?.mapNotNull { it.toIntOrNull() } ?: return
        for (pid in pids) {
            if (pid == me) continue
            val tids = File("/proc/$pid/task").list()?.mapNotNull { it.toIntOrNull() } ?: continue
            for (tid in tids) setPriority(tid)
        }
    }

    private fun setPriority(tid: Int) {
        if (level == 0) return
        try {
            android.os.Process.setThreadPriority(tid, level)
        } catch (e: SecurityException) {
            level = if (level < -2) -2 else 0          // sem permissão: tenta um nível menor e depois desiste
        } catch (e: Exception) {
            // a thread acabou de terminar: ignora
        }
    }
}
