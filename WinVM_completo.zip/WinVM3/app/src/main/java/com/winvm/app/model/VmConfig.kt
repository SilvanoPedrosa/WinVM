package com.winvm.app.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/** Disco extra anexado à VM. format = formato do QEMU (qcow2, vpc = VHD, vhdx, vmdk, vdi, raw). */
@Parcelize
data class DiskRef(val path: String, val format: String) : Parcelable

@Parcelize
data class VmConfig(
    val name: String,
    val ramMb: Int = 3072,
    val cpus: Int = 2,
    val diskPath: String,
    val isoPath: String? = null,
    val vncPort: Int = 0,      // display VNC N => porta 5900 + N
    val qmpPort: Int = 4444,
    val diskFormat: String = "qcow2",
    val extraDisks: List<DiskRef> = emptyList(),
    val width: Int = 0,        // 0 = automática (o sistema convidado escolhe)
    val height: Int = 0,
    val cpuModel: String = "max",   // modelo de CPU do QEMU (Intel/AMD)
    val videoCard: String = "std",  // std | vmware | cirrus
    val vramMb: Int = 32,
    val netModel: String = "e1000",   // placa de rede (ou "none" = sem internet)
    val audioCard: String = "none",   // none | hda | ac97 | sb16
    val diskTurbo: Boolean = true,    // cache=unsafe: ignora o flush do convidado (bem mais rápido)
    val cpuTurbo: Boolean = true,     // TCG de 1 thread, no máx. 2 CPUs, núcleos rápidos do celular
    val virtualRamMb: Int = 0,        // RAM virtual: parte da memória da VM fica num arquivo no armazenamento
    val quickStart: Boolean = true    // o botão desligar hiberna (salva a VM) e o próximo início volta em segundos
) : Parcelable {
    /** Na emulação, mais CPUs só deixam mais lento: com CPU turbo, no máximo 2 CPUs virtuais. */
    val vcpus: Int get() = if (cpuTurbo) minOf(cpus, 2) else cpus

    /** savevm (Hibernar) exige que TODOS os discos graváveis sejam qcow2. */
    val canHibernate: Boolean get() = diskFormat == "qcow2" && extraDisks.all { it.format == "qcow2" }
}

enum class VmState { STOPPED, STARTING, RUNNING, PAUSED }
