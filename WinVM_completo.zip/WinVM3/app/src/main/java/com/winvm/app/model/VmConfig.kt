package com.winvm.app.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/** Disco extra anexado à VM. format = formato do QEMU (qcow2, vpc = VHD, vhdx, vmdk, vdi, raw). */
@Parcelize
data class DiskRef(val path: String, val format: String) : Parcelable

@Parcelize
data class VmConfig(
    val name: String,
    val ramMb: Int = 3072,
    val cpus: Int = 2,
    val diskPath: String,
    val isoPath: String? = null,
    val vncPort: Int = 0,      // display VNC N => porta 5900 + N
    val qmpPort: Int = 4444,
    val diskFormat: String = "qcow2",
    val extraDisks: List<DiskRef> = emptyList(),
    val width: Int = 0,        // 0 = automática (o sistema convidado escolhe)
    val height: Int = 0
) : Parcelable

enum class VmState { STOPPED, STARTING, RUNNING, PAUSED }
