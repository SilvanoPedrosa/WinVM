package com.winvm.app.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class VmConfig(
    val name: String,
    val ramMb: Int = 3072,
    val cpus: Int = 2,
    val diskPath: String,
    val isoPath: String? = null,
    val vncPort: Int = 0,      // display VNC N => porta 5900 + N
    val qmpPort: Int = 4444,
    val useSpice: Boolean = false
) : Parcelable {
    val spicePort: Int get() = 5930 + vncPort
}

enum class VmState { STOPPED, STARTING, RUNNING, PAUSED }
