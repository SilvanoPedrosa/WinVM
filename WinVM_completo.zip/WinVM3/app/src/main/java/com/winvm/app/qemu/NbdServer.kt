package com.winvm.app.qemu

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket

/**
 * Servidor NBD mínimo (localhost) que expõe o pendrive como disco de blocos.
 * O QEMU conecta nele (blockdev nbd) e o entrega à VM como dispositivo usb-storage.
 */
class NbdServer(private val dev: MassStorage, private val readOnly: Boolean) {
    private val server = ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"))
    val port: Int get() = server.localPort
    @Volatile private var running = true

    fun start() {
        Thread({
            while (running) {
                try {
                    val s = server.accept()
                    s.tcpNoDelay = true
                    handle(s)
                } catch (e: Exception) {
                    if (!running) break
                }
            }
        }, "nbd-server").start()
    }

    fun close() {
        running = false
        runCatching { server.close() }
    }

    private fun flags(): Int = 1 or 4 or (if (readOnly) 2 else 0)    // HAS_FLAGS | SEND_FLUSH | READ_ONLY

    private fun handle(s: Socket) {
        s.use {
            val inp = DataInputStream(BufferedInputStream(s.getInputStream(), 1 shl 16))
            val out = DataOutputStream(BufferedOutputStream(s.getOutputStream(), 1 shl 16))
            if (!negotiate(inp, out)) return
            serve(inp, out)
        }
    }

    private fun repHeader(out: DataOutputStream, opt: Int, type: Int, len: Int) {
        out.writeLong(0x3e889045565a9L)
        out.writeInt(opt)
        out.writeInt(type)
        out.writeInt(len)
    }

    private fun negotiate(inp: DataInputStream, out: DataOutputStream): Boolean {
        out.writeLong(0x4e42444d41474943L)          // "NBDMAGIC"
        out.writeLong(0x49484156454f5054L)          // "IHAVEOPT"
        out.writeShort(3)                           // FIXED_NEWSTYLE | NO_ZEROES
        out.flush()
        val clientFlags = inp.readInt()
        val noZeroes = (clientFlags and 2) != 0
        while (true) {
            if (inp.readLong() != 0x49484156454f5054L) return false
            val opt = inp.readInt()
            val len = inp.readInt()
            val data = ByteArray(len)
            inp.readFully(data)
            when (opt) {
                1 -> {                               // NBD_OPT_EXPORT_NAME
                    out.writeLong(dev.size)
                    out.writeShort(flags())
                    if (!noZeroes) out.write(ByteArray(124))
                    out.flush()
                    return true
                }
                6, 7 -> {                            // NBD_OPT_INFO / NBD_OPT_GO
                    repHeader(out, opt, 3, 12)
                    out.writeShort(0)                // NBD_INFO_EXPORT
                    out.writeLong(dev.size)
                    out.writeShort(flags())
                    repHeader(out, opt, 3, 14)
                    out.writeShort(3)                // NBD_INFO_BLOCK_SIZE
                    out.writeInt(dev.blockSize)
                    out.writeInt(maxOf(4096, dev.blockSize))
                    out.writeInt(1 shl 20)
                    repHeader(out, opt, 1, 0)        // NBD_REP_ACK
                    out.flush()
                    if (opt == 7) return true
                }
                12 -> {                              // NBD_OPT_ABORT
                    repHeader(out, opt, 1, 0)
                    out.flush()
                    return false
                }
                else -> {                            // não suportado (structured reply etc.)
                    repHeader(out, opt, 0x80000001L.toInt(), 0)
                    out.flush()
                }
            }
        }
    }

    private fun reply(out: DataOutputStream, handle: Long, err: Int) {
        out.writeInt(0x67446698)
        out.writeInt(err)
        out.writeLong(handle)
    }

    private fun serve(inp: DataInputStream, out: DataOutputStream) {
        while (true) {
            if (inp.readInt() != 0x25609513) return
            inp.readUnsignedShort()                  // command flags
            val type = inp.readUnsignedShort()
            val handle = inp.readLong()
            val offset = inp.readLong()
            val len = inp.readInt()
            when (type) {
                0 -> {                               // READ
                    var data: ByteArray? = null
                    var err = 0
                    try { data = dev.read(offset, len) } catch (e: Exception) { err = 5 }
                    reply(out, handle, err)
                    if (data != null) out.write(data)
                    out.flush()
                }
                1 -> {                               // WRITE
                    val data = ByteArray(len)
                    inp.readFully(data)
                    val err = if (readOnly) 1 else try { dev.write(offset, data); 0 } catch (e: Exception) { 5 }
                    reply(out, handle, err)
                    out.flush()
                }
                2 -> return                          // DISCONNECT
                3 -> { reply(out, handle, 0); out.flush() }   // FLUSH
                else -> { reply(out, handle, 22); out.flush() }
            }
        }
    }
}
