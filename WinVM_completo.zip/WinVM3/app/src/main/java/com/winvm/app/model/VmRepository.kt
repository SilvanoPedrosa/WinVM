package com.winvm.app.model

import android.content.Context
import org.json.JSONObject
import java.io.File

object VmRepository {
    fun root(ctx: Context) = File(ctx.filesDir, "vms").apply { mkdirs() }

    fun save(ctx: Context, c: VmConfig) {
        val j = JSONObject()
            .put("name", c.name).put("ramMb", c.ramMb).put("cpus", c.cpus)
            .put("diskPath", c.diskPath)
            .put("isoPath", c.isoPath ?: JSONObject.NULL)
            .put("vncPort", c.vncPort).put("qmpPort", c.qmpPort)
            .put("useSpice", c.useSpice)
        File(root(ctx), "${c.name}/vm.json").writeText(j.toString())
    }

    fun list(ctx: Context): List<VmConfig> =
        root(ctx).listFiles().orEmpty().sortedBy { it.name }.mapNotNull { dir ->
            runCatching {
                val j = JSONObject(File(dir, "vm.json").readText())
                VmConfig(
                    name = j.getString("name"),
                    ramMb = j.getInt("ramMb"),
                    cpus = j.getInt("cpus"),
                    diskPath = j.getString("diskPath"),
                    isoPath = if (j.isNull("isoPath")) null else j.getString("isoPath"),
                    vncPort = j.getInt("vncPort"),
                    qmpPort = j.getInt("qmpPort"),
                    useSpice = j.optBoolean("useSpice", false)
                )
            }.getOrNull()
        }

    /** Menor índice livre, para não colidir portas entre VMs. */
    fun nextIndex(ctx: Context): Int {
        val used = list(ctx).map { it.vncPort }.toSet()
        return generateSequence(0) { it + 1 }.first { it !in used }
    }

    fun delete(ctx: Context, c: VmConfig) {
        File(root(ctx), c.name).deleteRecursively()
    }
}
