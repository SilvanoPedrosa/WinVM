package com.winvm.app.model

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object VmRepository {
    fun root(ctx: Context) = File(ctx.filesDir, "vms").apply { mkdirs() }

    fun save(ctx: Context, c: VmConfig) {
        val extras = JSONArray(
            c.extraDisks.map { JSONObject().put("path", it.path).put("format", it.format) }
        )
        val j = JSONObject()
            .put("name", c.name).put("ramMb", c.ramMb).put("cpus", c.cpus)
            .put("diskPath", c.diskPath)
            .put("isoPath", c.isoPath ?: JSONObject.NULL)
            .put("vncPort", c.vncPort).put("qmpPort", c.qmpPort)
            .put("diskFormat", c.diskFormat)
            .put("extra", extras)
            .put("width", c.width).put("height", c.height)
            .put("cpuModel", c.cpuModel).put("videoCard", c.videoCard).put("vramMb", c.vramMb)
            .put("netModel", c.netModel).put("audioCard", c.audioCard)
            .put("diskTurbo", c.diskTurbo)
            .put("cpuTurbo", c.cpuTurbo).put("quickStart", c.quickStart)
        File(root(ctx), "${c.name}/vm.json").writeText(j.toString())
    }

    fun list(ctx: Context): List<VmConfig> =
        root(ctx).listFiles().orEmpty().sortedBy { it.name }.mapNotNull { dir ->
            runCatching {
                val j = JSONObject(File(dir, "vm.json").readText())
                val extras = j.optJSONArray("extra")?.let { a ->
                    (0 until a.length()).map { i ->
                        val o = a.getJSONObject(i)
                        DiskRef(o.getString("path"), o.getString("format"))
                    }
                } ?: emptyList()
                VmConfig(
                    name = j.getString("name"),
                    ramMb = j.getInt("ramMb"),
                    cpus = j.getInt("cpus"),
                    diskPath = j.getString("diskPath"),
                    isoPath = if (j.isNull("isoPath")) null else j.getString("isoPath"),
                    vncPort = j.getInt("vncPort"),
                    qmpPort = j.getInt("qmpPort"),
                    diskFormat = j.optString("diskFormat", "qcow2"),
                    extraDisks = extras,
                    width = j.optInt("width", 0),
                    height = j.optInt("height", 0),
                    cpuModel = j.optString("cpuModel", "max"),
                    videoCard = j.optString("videoCard", "std"),
                    vramMb = j.optInt("vramMb", 32),
                    netModel = j.optString("netModel", "e1000"),
                    audioCard = j.optString("audioCard", "none"),
                    diskTurbo = j.optBoolean("diskTurbo", true),
                    cpuTurbo = j.optBoolean("cpuTurbo", true),
                    quickStart = j.optBoolean("quickStart", true)
                )
            }.getOrNull()
        }

    /** Menor índice livre, para não colidir portas entre VMs. */
    fun nextIndex(ctx: Context): Int {
        val used = list(ctx).map { it.vncPort }.toSet()
        return generateSequence(0) { it + 1 }.first { it !in used }
    }

    fun delete(ctx: Context, c: VmConfig) {
        File(root(ctx), c.name).deleteRecursively()
    }
}
