package com.winvm.app.qemu

import android.content.Context
import java.io.File

object QemuPaths {
    fun bin(ctx: Context) = File(ctx.applicationInfo.nativeLibraryDir, "libqemu.so")
    fun img(ctx: Context) = File(ctx.applicationInfo.nativeLibraryDir, "libqemu-img.so")

    /** Copia assets/qemu-share para filesDir (firmwares: bios, vgabios, roms). */
    fun share(ctx: Context): File {
        val dir = File(ctx.filesDir, "qemu-share")
        val stamp = ctx.packageManager.getPackageInfo(ctx.packageName, 0).lastUpdateTime.toString()
        val mark = File(dir, ".stamp")
        if (!mark.exists() || mark.readText() != stamp) {
            dir.mkdirs()
            copyAsset(ctx, "qemu-share", dir)
            mark.writeText(stamp)
        }
        return dir
    }

    private fun copyAsset(ctx: Context, path: String, dest: File) {
        for (n in ctx.assets.list(path).orEmpty()) {
            val sub = "$path/$n"
            if (ctx.assets.list(sub).orEmpty().isNotEmpty()) {
                copyAsset(ctx, sub, File(dest, n).apply { mkdirs() })
            } else {
                ctx.assets.open(sub).use { i -> File(dest, n).outputStream().use { o -> i.copyTo(o) } }
            }
        }
    }
}
