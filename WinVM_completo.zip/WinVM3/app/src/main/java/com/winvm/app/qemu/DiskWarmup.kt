package com.winvm.app.qemu

import com.winvm.app.model.VmConfig
import java.io.File
import java.io.RandomAccessFile

/**
 * Lê o disco em segundo plano (prioridade mínima) enquanto o QEMU inicia, para o Android
 * já deixá-lo no cache de memória. Ao retomar uma VM hibernada lê também o fim do arquivo,
 * onde fica o estado da RAM salvo.
 */
object DiskWarmup {
    private const val MB = 1024L * 1024L

    fun start(cfg: VmConfig, resume: Boolean) {
        Thread({
            runCatching {
                val f = File(cfg.diskPath)
                if (f.exists()) {
                    read(f, 0L, 256 * MB)
                    if (resume) read(f, maxOf(0L, f.length() - 1536 * MB), 1536 * MB)
                }
                // instalação: o boot lê o começo da ISO
                cfg.isoPath?.let { iso ->
                    val i = File(iso)
                    if (!resume && i.exists()) read(i, 0L, 512 * MB)
                }
            }
        }, "disk-warmup").apply {
            priority = Thread.MIN_PRIORITY
            isDaemon = true
        }.start()
    }

    private fun read(file: File, offset: Long, bytes: Long) {
        RandomAccessFile(file, "r").use { raf ->
            val total = raf.length()
            var pos = offset.coerceIn(0L, total)
            val end = minOf(total, pos + bytes)
            raf.seek(pos)
            val buf = ByteArray(1 shl 20)
            while (pos < end) {
                val n = raf.read(buf, 0, minOf(buf.size.toLong(), end - pos).toInt())
                if (n <= 0) break
                pos += n
            }
        }
    }
}
