package com.winvm.app.ui

import android.app.Activity
import android.content.Context
import android.widget.Toast
import android.net.Uri
import android.content.Intent
import android.content.ContextWrapper
import android.os.Build
import android.os.SystemClock
import android.view.KeyCharacterMap
import android.view.KeyEvent as AKeyEvent
import androidx.compose.foundation.focusable
import androidx.compose.ui.input.key.KeyEvent
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import android.view.WindowManager
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.hapticfeedback.HapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEvent
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.winvm.app.model.VmConfig
import com.winvm.app.qemu.Keysyms
import com.winvm.app.qemu.RfbClient

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DisplayScreen(cfg: VmConfig, onExit: () -> Unit) {
    val client = remember { RfbClient(5900 + cfg.vncPort) }
    val ready by client.ready.collectAsState()
    val tick by client.frame.collectAsState()
    var error by remember { mutableStateOf<String?>(null) }
    var showKeys by remember { mutableStateOf(false) }
    val haptic = LocalHapticFeedback.current
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("winvm", Context.MODE_PRIVATE) }
    var mode by remember {
        mutableStateOf(DisplayMode.values().getOrElse(prefs.getInt("display_mode", 0)) { DisplayMode.FIT })
    }
    val modeState = rememberUpdatedState(mode)
    var showUsb by remember { mutableStateOf(false) }
    var immersive by remember { mutableStateOf(prefs.getBoolean("immersive", true)) }

    // Teclado físico (Bluetooth / USB OTG) e teclas especiais: tudo vai para a VM
    val rootFocus = remember { FocusRequester() }
    val pressedKeys = remember { HashMap<Int, Int>() }
    LaunchedEffect(showUsb) {
        if (!showUsb) runCatching { rootFocus.requestFocus() }
    }
    val onHwKey: (KeyEvent) -> Boolean = { ev -> handleHardwareKey(client, pressedKeys, ev) }

    // Tela cheia: esconde barra de status e de navegação (arrastar da borda mostra por um instante)
    val view = LocalView.current
    DisposableEffect(immersive) {
        val window = view.context.findActivity()?.window
        if (window != null) {
            val controller = WindowInsetsControllerCompat(window, view)
            if (immersive) {
                // Tela cheia de verdade: desenha por baixo das barras (e do notch) e esconde as barras
                WindowCompat.setDecorFitsSystemWindows(window, false)
                if (Build.VERSION.SDK_INT >= 28) {
                    window.attributes = window.attributes.apply {
                        layoutInDisplayCutoutMode =
                            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                    }
                }
                controller.systemBarsBehavior =
                    WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                controller.hide(WindowInsetsCompat.Type.systemBars())
            } else {
                // Barras visíveis: o conteúdo fica ENTRE as barras, sem sobrepor nada
                WindowCompat.setDecorFitsSystemWindows(window, true)
                if (Build.VERSION.SDK_INT >= 28) {
                    window.attributes = window.attributes.apply {
                        layoutInDisplayCutoutMode =
                            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
                    }
                }
                controller.show(WindowInsetsCompat.Type.systemBars())
            }
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        onDispose {
            if (window != null) {
                WindowInsetsControllerCompat(window, view).show(WindowInsetsCompat.Type.systemBars())
                WindowCompat.setDecorFitsSystemWindows(window, true)
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                if (Build.VERSION.SDK_INT >= 28) {
                    window.attributes = window.attributes.apply {
                        layoutInDisplayCutoutMode =
                            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
                    }
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        try {
            client.connectWithRetry()
        } catch (e: Exception) {
            error = e.message ?: "Desconectado"
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            client.close()
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .focusRequester(rootFocus)
            .focusable()
            .onPreviewKeyEvent(onHwKey)
    ) {
        Box(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.displayCutout)) {
            if (!ready) {
                Text(
                    error ?: "Aguardando o QEMU iniciar…",
                    color = Color.White,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(24.dp)
                )
            } else {
                Canvas(
                    Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            touchpad(client, haptic) { modeState.value }
                        }
                ) {
                    tick
                    val bw = client.bitmap.width.toFloat()
                    val bh = client.bitmap.height.toFloat()
                    val (dw, dh) = fitSize(size.width, size.height, aspectFor(mode, bw, bh))
                    drawImage(
                        client.bitmap.asImageBitmap(),
                        dstOffset = IntOffset(((size.width - dw) / 2).toInt(), ((size.height - dh) / 2).toInt()),
                        dstSize = IntSize(dw.toInt(), dh.toInt())
                    )
                }

                if (error != null) {
                    Text(
                        error!!,
                        color = Color.Red,
                        modifier = Modifier.align(Alignment.TopCenter)
                    )
                }
            }
        }

        // Botão flutuante: mostra/oculta as teclas especiais
        Box(
            Modifier
                .align(Alignment.TopEnd)
                .windowInsetsPadding(WindowInsets.displayCutout)
                .padding(8.dp)
                .size(48.dp)
                .clip(CircleShape)
                .background(if (showKeys) Color(0xCC3D6EFF) else Color(0x66000000))
                .clickable { showKeys = !showKeys },
            contentAlignment = Alignment.Center
        ) {
            Text("⌨", color = Color.White)
        }

        VirtualKeyBar(
            c = client,
            showKeys = showKeys,
            onExit = onExit,
            modeLabel = mode.label,
            onCycleMode = {
                val all = DisplayMode.values()
                mode = all[(mode.ordinal + 1) % all.size]
                prefs.edit().putInt("display_mode", mode.ordinal).apply()
            },
            onUsb = { showUsb = true },
            barsLabel = if (immersive) "ocultas" else "visíveis",
            onToggleBars = {
                immersive = !immersive
                prefs.edit().putBoolean("immersive", immersive).apply()
            },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .windowInsetsPadding(WindowInsets.displayCutout.only(WindowInsetsSides.Horizontal))
                .then(
                    if (immersive) Modifier.windowInsetsPadding(WindowInsets.systemGestures.only(WindowInsetsSides.Bottom))
                    else Modifier
                )
        )

        if (showUsb) UsbDialog(cfg) { showUsb = false }
    }
}

/** Proporção da imagem na tela: Original (da VM), Esticar (preenche), 4:3, 16:9, 16:10. */
enum class DisplayMode(val label: String) {
    FIT("Original"), FILL("Esticar"), R4_3("4:3"), R16_9("16:9"), R16_10("16:10")
}

private fun aspectFor(mode: DisplayMode, bw: Float, bh: Float): Float = when (mode) {
    DisplayMode.FIT -> bw / bh
    DisplayMode.FILL -> 0f
    DisplayMode.R4_3 -> 4f / 3f
    DisplayMode.R16_9 -> 16f / 9f
    DisplayMode.R16_10 -> 16f / 10f
}

/** Maior retângulo com a proporção pedida que cabe em w x h (aspect <= 0 = preenche tudo). */
private fun fitSize(w: Float, h: Float, aspect: Float): Pair<Float, Float> =
    if (aspect <= 0f) Pair(w, h)
    else if (w / h > aspect) Pair(h * aspect, h)
    else Pair(w, w / aspect)

private fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

private const val TAP_MS = 250L           // toque curto = clique
private const val LONG_PRESS_MS = 450L    // segurar parado = comecar a arrastar
private const val DOUBLE_TAP_MS = 300L    // toque + segurar logo em seguida = arrastar
private const val POINTER_SPEED = 1.25f   // sensibilidade base do cursor

/**
 * Tela como touchpad de notebook:
 *  - 1 dedo deslizando: move o cursor (relativo, com aceleração: devagar = preciso)
 *  - toque: clique esquerdo | dois toques rápidos: duplo clique
 *  - toque + segurar e deslizar (ou segurar parado e deslizar): arrasta com o botão esquerdo
 *  - 2 dedos: toque = clique direito | deslizar para cima/baixo = rolagem
 *  - 3 dedos: toque = clique do meio
 */
private suspend fun PointerInputScope.touchpad(c: RfbClient, haptic: HapticFeedback, mode: () -> DisplayMode) {
    val slop = viewConfiguration.touchSlop
    val wheelStep = 16.dp.toPx()
    var curX = c.bitmap.width / 2f
    var curY = c.bitmap.height / 2f
    var lastTapUp = 0L

    fun send(buttons: Int) = c.pointer(curX.toInt(), curY.toInt(), buttons)

    fun click(buttons: Int) {
        send(buttons)
        send(0)
    }

    fun applyMove(d: Offset, dt: Long, buttons: Int) {
        val speed = d.getDistance() / maxOf(dt, 1L)                  // px/ms
        val gain = POINTER_SPEED * (1f + minOf(speed / 2f, 1.5f))    // aceleração
        val bw = c.bitmap.width.toFloat()
        val bh = c.bitmap.height.toFloat()
        val (dw, dh) = fitSize(size.width.toFloat(), size.height.toFloat(), aspectFor(mode(), bw, bh))
        val sx = bw / dw
        val sy = bh / dh
        curX = (curX + d.x * sx * gain).coerceIn(0f, (c.bitmap.width - 1).toFloat())
        curY = (curY + d.y * sy * gain).coerceIn(0f, (c.bitmap.height - 1).toFloat())
        send(buttons)
    }

    awaitPointerEventScope {
        while (true) {
            val first = awaitFirstDown(requireUnconsumed = false)
            first.consume()
            val tDown = SystemClock.uptimeMillis()

            // toque + segurar logo após um toque = arrastar (como no touchpad)
            var buttons = 0
            if (lastTapUp != 0L && tDown - lastTapUp < DOUBLE_TAP_MS) {
                buttons = 1
                send(1)
            }
            lastTapUp = 0L

            var moved = false
            var multi = false
            var multiMoved = false
            var maxPointers = 1
            var total = Offset.Zero
            var prev = first.position
            var prevCentroid = Offset.Zero
            var prevCount = 1
            var multiTotal = Offset.Zero
            var scrollAcc = 0f
            var lastT = tDown

            while (true) {
                val canLongPress = !moved && !multi && buttons == 0
                val event: PointerEvent? = if (canLongPress) {
                    val remaining = LONG_PRESS_MS - (SystemClock.uptimeMillis() - tDown)
                    if (remaining <= 0) null else withTimeoutOrNull(remaining) { awaitPointerEvent() }
                } else {
                    awaitPointerEvent()
                }

                if (event == null) {                        // segurou parado: começa a arrastar
                    buttons = 1
                    send(1)
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    continue
                }

                event.changes.forEach { it.consume() }
                val ps = event.changes.filter { it.pressed }
                if (ps.isEmpty()) break

                val now = SystemClock.uptimeMillis()
                maxPointers = maxOf(maxPointers, ps.size)

                if (ps.size >= 2) {
                    val cen = ps.fold(Offset.Zero) { a, p -> a + p.position } / ps.size.toFloat()
                    if (!multi) {
                        multi = true
                        multiTotal = Offset.Zero
                        if (buttons != 0) { send(0); buttons = 0 }
                    } else if (ps.size == prevCount) {
                        val d = cen - prevCentroid
                        multiTotal += d
                        if (multiTotal.getDistance() > slop) multiMoved = true
                        if (multiMoved && ps.size == 2) {
                            scrollAcc += d.y
                            // dedos para cima = rola para baixo (como no celular)
                            while (scrollAcc <= -wheelStep) { click(16); scrollAcc += wheelStep }
                            while (scrollAcc >= wheelStep) { click(8); scrollAcc -= wheelStep }
                        }
                    }
                    prevCentroid = cen
                    prevCount = ps.size
                } else if (multi) {
                    prevCentroid = ps[0].position          // sobrou 1 dedo: ignora o movimento
                    prevCount = 1
                } else {
                    val p = ps[0]
                    val d = p.position - prev
                    prev = p.position
                    total += d
                    if (!moved && total.getDistance() > slop) {
                        moved = true
                        applyMove(total, now - tDown, buttons)
                    } else if (moved) {
                        applyMove(d, now - lastT, buttons)
                    }
                }
                lastT = now
            }

            val dur = SystemClock.uptimeMillis() - tDown
            when {
                multi -> {
                    if (!moved && !multiMoved && dur < 350L) {
                        if (maxPointers >= 3) click(2) else click(4)
                    }
                }
                buttons != 0 -> send(0)                      // fim do arrasto (ou 2º toque = duplo clique)
                !moved && dur < TAP_MS -> {
                    click(1)
                    lastTapUp = SystemClock.uptimeMillis()
                }
            }
        }
    }
}

private const val SENTINEL = " "

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun VirtualKeyBar(
    c: RfbClient,
    showKeys: Boolean,
    onExit: () -> Unit,
    modeLabel: String,
    onCycleMode: () -> Unit,
    onUsb: () -> Unit,
    barsLabel: String,
    onToggleBars: () -> Unit,
    modifier: Modifier = Modifier
) {
    var ctrl by remember { mutableStateOf(false) }
    var alt by remember { mutableStateOf(false) }
    var shift by remember { mutableStateOf(false) }
    var more by remember { mutableStateOf(false) }
    var buf by remember { mutableStateOf(SENTINEL) }

    val focus = remember { FocusRequester() }
    val kb = LocalSoftwareKeyboardController.current

    fun tap(sym: Int) {
        if (ctrl) c.key(Keysyms.CTRL, true)
        if (alt) c.key(Keysyms.ALT, true)
        if (shift) c.key(Keysyms.SHIFT, true)

        c.key(sym, true)
        c.key(sym, false)

        if (shift) c.key(Keysyms.SHIFT, false)
        if (alt) c.key(Keysyms.ALT, false)
        if (ctrl) c.key(Keysyms.CTRL, false)

        ctrl = false
        alt = false
        shift = false
    }

    Column(modifier.imePadding()) {
    // Campo invisível que recebe o teclado Android.
    // O espaço inicial ajuda a detectar o Backspace.
    BasicTextField(
        value = buf,
        onValueChange = { new ->
            when {
                new.length > SENTINEL.length -> {
                    new.drop(SENTINEL.length).forEach { ch ->
                        if (ch == '\n') {
                            tap(Keysyms.ENTER)
                        } else {
                            tap(Keysyms.fromChar(ch))
                        }
                    }
                }

                new.isEmpty() -> {
                    tap(Keysyms.BACKSPACE)
                }
            }

            buf = SENTINEL
        },
        keyboardOptions = KeyboardOptions(
            keyboardType = KeyboardType.Text
        ),
        modifier = Modifier
            .size(1.dp)
            .focusRequester(focus)
    )

    if (showKeys) Row(
        Modifier
            .fillMaxWidth()
            .background(Color(0xFF222222))
            .horizontalScroll(rememberScrollState())
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        KeyBtn("⌨") {
            focus.requestFocus()
            kb?.show()
        }

        KeyBtn("Esc") {
            tap(Keysyms.ESC)
        }

        KeyBtn("Tab") {
            tap(Keysyms.TAB)
        }

        KeyBtn("Ctrl", active = ctrl) {
            ctrl = !ctrl
        }

        KeyBtn("Alt", active = alt) {
            alt = !alt
        }

        KeyBtn("Shift", active = shift) {
            shift = !shift
        }

        KeyBtn("Win") {
            tap(Keysyms.SUPER)
        }

        KeyBtn("←") {
            tap(Keysyms.LEFT)
        }

        KeyBtn("↑") {
            tap(Keysyms.UP)
        }

        KeyBtn("↓") {
            tap(Keysyms.DOWN)
        }

        KeyBtn("→") {
            tap(Keysyms.RIGHT)
        }

        KeyBtn("Del") {
            tap(Keysyms.DELETE)
        }

        KeyBtn("Ctrl+Alt+Del") {
            c.key(Keysyms.CTRL, true)
            c.key(Keysyms.ALT, true)
            c.key(Keysyms.DELETE, true)

            c.key(Keysyms.DELETE, false)
            c.key(Keysyms.ALT, false)
            c.key(Keysyms.CTRL, false)
        }

        KeyBtn("F1–F12", active = more) {
            more = !more
        }

        KeyBtn("Tela: $modeLabel") {
            onCycleMode()
        }

        KeyBtn("Barras: $barsLabel") {
            onToggleBars()
        }

        KeyBtn("USB") {
            onUsb()
        }

        KeyBtn("✕") {
            onExit()
        }
    }

    // Segunda linha: F1–F12 e demais teclas
    if (showKeys && more) Row(
        Modifier
            .fillMaxWidth()
            .background(Color(0xFF222222))
            .horizontalScroll(rememberScrollState())
            .padding(start = 4.dp, end = 4.dp, bottom = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        for (n in 1..12) {
            KeyBtn("F$n") {
                tap(Keysyms.f(n))
            }
        }

        KeyBtn("Home") { tap(Keysyms.HOME) }
        KeyBtn("End") { tap(Keysyms.END) }
        KeyBtn("PgUp") { tap(Keysyms.PGUP) }
        KeyBtn("PgDn") { tap(Keysyms.PGDN) }
        KeyBtn("Ins") { tap(Keysyms.INSERT) }
        KeyBtn("PrtSc") { tap(Keysyms.PRINT) }
        KeyBtn("Caps") { tap(Keysyms.CAPS) }
        KeyBtn("Num") { tap(Keysyms.NUMLOCK) }
        KeyBtn("Menu") { tap(Keysyms.MENU) }
    }
    }
}

@Composable
private fun KeyBtn(
    label: String,
    active: Boolean = false,
    onClick: () -> Unit
) {
    Box(
        Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(
                if (active) Color(0xFF3D6EFF)
                else Color(0xFF444444)
            )
            .clickable(onClick = onClick)
    ) {
        Text(
            text = label,
            color = Color.White,
            modifier = Modifier.padding(
                horizontal = 12.dp,
                vertical = 8.dp
            )
        )
    }
}


/**
 * Teclado físico: converte KeyEvent do Android em teclas da VM (keysyms).
 * Letras/símbolos usam o caractere digitado; teclas especiais (F1–F12, setas, Home/End, PgUp/PgDn,
 * Ins/Del, teclado numérico, Ctrl/Alt/Shift/Win...) usam o mapa de Keysyms.fromAndroidKey.
 * Devolve true quando a tecla foi enviada à VM (e não deve chegar a mais ninguém).
 */
private fun handleHardwareKey(c: RfbClient, pressed: HashMap<Int, Int>, ev: KeyEvent): Boolean {
    val n = ev.nativeKeyEvent
    val code = n.keyCode
    val isDown = ev.type == KeyEventType.KeyDown
    val isUp = ev.type == KeyEventType.KeyUp
    if (!isDown && !isUp) return false

    when (code) {
        // Voltar, volume, energia, brilho e mídia continuam com o Android
        AKeyEvent.KEYCODE_BACK, AKeyEvent.KEYCODE_HOME, AKeyEvent.KEYCODE_APP_SWITCH,
        AKeyEvent.KEYCODE_VOLUME_UP, AKeyEvent.KEYCODE_VOLUME_DOWN, AKeyEvent.KEYCODE_VOLUME_MUTE,
        AKeyEvent.KEYCODE_POWER, AKeyEvent.KEYCODE_SLEEP, AKeyEvent.KEYCODE_WAKEUP,
        AKeyEvent.KEYCODE_BRIGHTNESS_UP, AKeyEvent.KEYCODE_BRIGHTNESS_DOWN,
        AKeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, AKeyEvent.KEYCODE_MEDIA_NEXT,
        AKeyEvent.KEYCODE_MEDIA_PREVIOUS, AKeyEvent.KEYCODE_MEDIA_STOP -> return false
        // Caps Lock / Num Lock: use os botões Caps e Num da barra (evita maiúsculas invertidas em dobro)
        AKeyEvent.KEYCODE_CAPS_LOCK, AKeyEvent.KEYCODE_NUM_LOCK -> return true
    }

    if (isUp) {
        val sym = pressed.remove(code) ?: return false
        c.key(sym, false)
        return true
    }

    val sym = Keysyms.fromAndroidKey(code) ?: run {
        val mods = n.isCtrlPressed || n.isMetaPressed || (n.metaState and AKeyEvent.META_ALT_LEFT_ON) != 0
        val ch = if (mods) n.getUnicodeChar(0) else n.unicodeChar
        if (ch <= 0 || (ch and KeyCharacterMap.COMBINING_ACCENT) != 0) null else Keysyms.fromChar(ch.toChar())
    } ?: return false

    pressed[code] = sym
    c.key(sym, true)          // repetições (tecla segurada) chegam como novos "pressionar": a VM repete a tecla
    return true
}


