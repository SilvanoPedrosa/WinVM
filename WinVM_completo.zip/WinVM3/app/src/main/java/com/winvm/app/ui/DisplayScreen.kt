package com.winvm.app.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.os.Build
import android.view.WindowManager
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.winvm.app.model.VmConfig
import com.winvm.app.qemu.Keysyms
import com.winvm.app.qemu.RfbClient

@Composable
fun DisplayScreen(cfg: VmConfig, onExit: () -> Unit) {
    val client = remember { RfbClient(5900 + cfg.vncPort) }
    val ready by client.ready.collectAsState()
    val tick by client.frame.collectAsState()
    var error by remember { mutableStateOf<String?>(null) }
    var showKeys by remember { mutableStateOf(false) }

    // Tela cheia: esconde barra de status e de navegação (arrastar da borda mostra por um instante)
    val view = LocalView.current
    DisposableEffect(Unit) {
        val window = view.context.findActivity()?.window
        if (window != null) {
            WindowCompat.setDecorFitsSystemWindows(window, false)
            if (Build.VERSION.SDK_INT >= 28) {
                window.attributes = window.attributes.apply {
                    layoutInDisplayCutoutMode =
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
            }
            val controller = WindowInsetsControllerCompat(window, view)
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        onDispose {
            if (window != null) {
                WindowInsetsControllerCompat(window, view).show(WindowInsetsCompat.Type.systemBars())
                WindowCompat.setDecorFitsSystemWindows(window, true)
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                if (Build.VERSION.SDK_INT >= 28) {
                    window.attributes = window.attributes.apply {
                        layoutInDisplayCutoutMode =
                            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
                    }
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        try {
            client.connectWithRetry()
        } catch (e: Exception) {
            error = e.message ?: "Desconectado"
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            client.close()
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        Box(Modifier.fillMaxSize()) {
            if (!ready) {
                Text(
                    error ?: "Aguardando o QEMU iniciar…",
                    color = Color.White,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(24.dp)
                )
            } else {
                Canvas(
                    Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            tapGestures(client, size)
                        }
                        .pointerInput(Unit) {
                            dragGestures(client, size)
                        }
                ) {
                    tick
                    drawImage(
                        client.bitmap.asImageBitmap(),
                        dstSize = IntSize(
                            size.width.toInt(),
                            size.height.toInt()
                        )
                    )
                }

                if (error != null) {
                    Text(
                        error!!,
                        color = Color.Red,
                        modifier = Modifier.align(Alignment.TopCenter)
                    )
                }
            }
        }

        // Botão flutuante: mostra/oculta as teclas especiais
        Box(
            Modifier
                .align(Alignment.TopEnd)
                .padding(8.dp)
                .size(40.dp)
                .clip(CircleShape)
                .background(if (showKeys) Color(0xCC3D6EFF) else Color(0x66000000))
                .clickable { showKeys = !showKeys },
            contentAlignment = Alignment.Center
        ) {
            Text("⌨", color = Color.White)
        }

        VirtualKeyBar(
            c = client,
            showKeys = showKeys,
            onExit = onExit,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

private fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

private fun mapPoint(
    c: RfbClient,
    sz: IntSize,
    o: Offset
): Pair<Int, Int> = Pair(
    (o.x * c.bitmap.width / sz.width)
        .toInt()
        .coerceIn(0, c.bitmap.width - 1),
    (o.y * c.bitmap.height / sz.height)
        .toInt()
        .coerceIn(0, c.bitmap.height - 1)
)

/** Toque = clique, toque duplo = duplo clique, toque longo = botão direito. */
private suspend fun PointerInputScope.tapGestures(
    c: RfbClient,
    sz: IntSize
) {
    detectTapGestures(
        onTap = { o ->
            val (x, y) = mapPoint(c, sz, o)
            c.pointer(x, y, 1)
            c.pointer(x, y, 0)
        },
        onDoubleTap = { o ->
            val (x, y) = mapPoint(c, sz, o)
            repeat(2) {
                c.pointer(x, y, 1)
                c.pointer(x, y, 0)
            }
        },
        onLongPress = { o ->
            val (x, y) = mapPoint(c, sz, o)
            c.pointer(x, y, 4)
            c.pointer(x, y, 0)
        }
    )
}

/** Arrastar = mover com o botão esquerdo pressionado. */
private suspend fun PointerInputScope.dragGestures(
    c: RfbClient,
    sz: IntSize
) {
    detectDragGestures(
        onDragStart = { o ->
            val (x, y) = mapPoint(c, sz, o)
            c.pointer(x, y, 1)
        },
        onDrag = { ch, _ ->
            val (x, y) = mapPoint(c, sz, ch.position)
            c.pointer(x, y, 1)
        },
        onDragEnd = {
            c.pointer(c.lastX, c.lastY, 0)
        },
        onDragCancel = {
            c.pointer(c.lastX, c.lastY, 0)
        }
    )
}

private const val SENTINEL = " "

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun VirtualKeyBar(
    c: RfbClient,
    showKeys: Boolean,
    onExit: () -> Unit,
    modifier: Modifier = Modifier
) {
    var ctrl by remember { mutableStateOf(false) }
    var alt by remember { mutableStateOf(false) }
    var buf by remember { mutableStateOf(SENTINEL) }

    val focus = remember { FocusRequester() }
    val kb = LocalSoftwareKeyboardController.current

    fun tap(sym: Int) {
        if (ctrl) c.key(Keysyms.CTRL, true)
        if (alt) c.key(Keysyms.ALT, true)

        c.key(sym, true)
        c.key(sym, false)

        if (alt) c.key(Keysyms.ALT, false)
        if (ctrl) c.key(Keysyms.CTRL, false)

        ctrl = false
        alt = false
    }

    Column(modifier.imePadding()) {
    // Campo invisível que recebe o teclado Android.
    // O espaço inicial ajuda a detectar o Backspace.
    BasicTextField(
        value = buf,
        onValueChange = { new ->
            when {
                new.length > SENTINEL.length -> {
                    new.drop(SENTINEL.length).forEach { ch ->
                        if (ch == '\n') {
                            tap(Keysyms.ENTER)
                        } else {
                            tap(Keysyms.fromChar(ch))
                        }
                    }
                }

                new.isEmpty() -> {
                    tap(Keysyms.BACKSPACE)
                }
            }

            buf = SENTINEL
        },
        keyboardOptions = KeyboardOptions(
            keyboardType = KeyboardType.Text
        ),
        modifier = Modifier
            .size(1.dp)
            .focusRequester(focus)
    )

    if (showKeys) Row(
        Modifier
            .fillMaxWidth()
            .background(Color(0xFF222222))
            .horizontalScroll(rememberScrollState())
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        KeyBtn("⌨") {
            focus.requestFocus()
            kb?.show()
        }

        KeyBtn("Esc") {
            tap(Keysyms.ESC)
        }

        KeyBtn("Tab") {
            tap(Keysyms.TAB)
        }

        KeyBtn("Ctrl", active = ctrl) {
            ctrl = !ctrl
        }

        KeyBtn("Alt", active = alt) {
            alt = !alt
        }

        KeyBtn("Win") {
            tap(Keysyms.SUPER)
        }

        KeyBtn("←") {
            tap(Keysyms.LEFT)
        }

        KeyBtn("↑") {
            tap(Keysyms.UP)
        }

        KeyBtn("↓") {
            tap(Keysyms.DOWN)
        }

        KeyBtn("→") {
            tap(Keysyms.RIGHT)
        }

        KeyBtn("Del") {
            tap(Keysyms.DELETE)
        }

        KeyBtn("Ctrl+Alt+Del") {
            c.key(Keysyms.CTRL, true)
            c.key(Keysyms.ALT, true)
            c.key(Keysyms.DELETE, true)

            c.key(Keysyms.DELETE, false)
            c.key(Keysyms.ALT, false)
            c.key(Keysyms.CTRL, false)
        }

        KeyBtn("✕") {
            onExit()
        }
    }
    }
}

@Composable
private fun KeyBtn(
    label: String,
    active: Boolean = false,
    onClick: () -> Unit
) {
    Box(
        Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(
                if (active) Color(0xFF3D6EFF)
                else Color(0xFF444444)
            )
            .clickable(onClick = onClick)
    ) {
        Text(
            text = label,
            color = Color.White,
            modifier = Modifier.padding(
                horizontal = 12.dp,
                vertical = 8.dp
            )
        )
    }
}