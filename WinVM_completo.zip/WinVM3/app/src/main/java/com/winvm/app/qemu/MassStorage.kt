package com.winvm.app.qemu

import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Pendrive (USB Mass Storage, Bulk-Only Transport + comandos SCSI) acessado direto pela API USB do Android. */
class MassStorage private constructor(
    private val conn: UsbDeviceConnection,
    private val itf: UsbInterface,
    private val epIn: UsbEndpoint,
    private val epOut: UsbEndpoint
) {
    var blockSize = 512
        private set
    var blocks = 0L
        private set
    val size: Long get() = blocks * blockSize
    private var tag = 1

    companion object {
        private const val TIMEOUT = 5000
        private const val CHUNK = 16384
        private const val RETRIES = 3

        /**
         * Interface de armazenamento Bulk-Only (classe 8, protocolo 0x50).
         * Aceita qualquer subclasse: há pendrives que informam subclasses diferentes de 0x06.
         */
        fun isBotInterface(itf: UsbInterface): Boolean =
            itf.interfaceClass == 8 && itf.interfaceProtocol == 0x50

        fun open(manager: UsbManager, dev: UsbDevice): MassStorage {
            val conn = manager.openDevice(dev) ?: throw IOException("Sem permissão para abrir o dispositivo USB")
            var found: UsbInterface? = null
            for (i in 0 until dev.interfaceCount) {
                val itf = dev.getInterface(i)
                if (isBotInterface(itf)) { found = itf; break }
            }
            if (found == null) {
                conn.close()
                throw IOException("Este dispositivo não é um pendrive compatível (armazenamento USB comum)")
            }
            var inEp: UsbEndpoint? = null
            var outEp: UsbEndpoint? = null
            for (e in 0 until found.endpointCount) {
                val ep = found.getEndpoint(e)
                if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                    if (ep.direction == UsbConstants.USB_DIR_IN) inEp = ep else outEp = ep
                }
            }
            if (inEp == null || outEp == null) { conn.close(); throw IOException("Endpoints USB não encontrados") }
            if (!conn.claimInterface(found, true)) {
                conn.close(); throw IOException("Não consegui assumir o controle do pendrive")
            }
            val ms = MassStorage(conn, found, inEp, outEp)
            try {
                ms.initDevice()
            } catch (e: Exception) {
                ms.close(); throw e
            }
            return ms
        }
    }

    fun close() {
        runCatching { conn.releaseInterface(itf) }
        runCatching { conn.close() }
    }

    private fun clearHalt(ep: UsbEndpoint) {
        conn.controlTransfer(0x02, 0x01, 0, ep.address, null, 0, 1000)
    }

    /** Bulk-Only Mass Storage Reset + limpeza de travamento nos dois endpoints. Usado após falhas. */
    @Synchronized
    private fun resetRecovery() {
        runCatching { conn.controlTransfer(0x21, 0xFF, 0, itf.id, null, 0, 1000) }
        runCatching { clearHalt(epIn) }
        runCatching { clearHalt(epOut) }
    }

    /** Repete a operação em caso de erro de transporte, com reset do pendrive entre as tentativas. */
    private fun <T> withRetry(block: () -> T): T {
        var attempt = 0
        while (true) {
            try {
                return block()
            } catch (e: IOException) {
                attempt++
                if (attempt >= RETRIES) throw e
                resetRecovery()
                Thread.sleep(150L * attempt)
            }
        }
    }

    /** Envia CBW, faz a fase de dados e lê o CSW. Devolve o status SCSI (0 = ok). */
    @Synchronized
    private fun command(cb: ByteArray, len: Int, dataIn: Boolean, buf: ByteArray?, bufOff: Int = 0): Int {
        val cbw = ByteArray(31)
        val t = tag++
        val bb = ByteBuffer.wrap(cbw).order(ByteOrder.LITTLE_ENDIAN)
        bb.putInt(0x43425355)                       // "USBC"
        bb.putInt(t)
        bb.putInt(len)
        bb.put(if (dataIn) 0x80.toByte() else 0.toByte())
        bb.put(0.toByte())                          // LUN 0
        bb.put(cb.size.toByte())
        bb.put(cb)
        if (conn.bulkTransfer(epOut, cbw, cbw.size, TIMEOUT) != cbw.size) {
            throw IOException("Falha ao enviar comando ao pendrive")
        }
        var dataFailed = false
        if (len > 0 && buf != null) {
            val ep = if (dataIn) epIn else epOut
            var done = 0
            while (done < len) {
                val n = minOf(CHUNK, len - done)
                val r = conn.bulkTransfer(ep, buf, bufOff + done, n, TIMEOUT)
                if (r < 0) { clearHalt(ep); dataFailed = true; break }
                if (r == 0) break
                done += r
            }
            if (!dataFailed && done < len) dataFailed = true
        }
        val csw = ByteArray(13)
        var r = conn.bulkTransfer(epIn, csw, csw.size, TIMEOUT)
        if (r < 0) { clearHalt(epIn); r = conn.bulkTransfer(epIn, csw, csw.size, TIMEOUT) }
        if (r != 13) throw IOException("Resposta inválida do pendrive")
        val rb = ByteBuffer.wrap(csw).order(ByteOrder.LITTLE_ENDIAN)
        if (rb.getInt(0) != 0x53425355 || rb.getInt(4) != t) throw IOException("CSW inesperado")
        if (dataFailed) throw IOException("Falha na transferência de dados USB")
        return csw[12].toInt()
    }

    private fun initDevice() {
        var ready = false
        for (i in 0 until 12) {
            try {
                if (command(ByteArray(6), 0, true, null) == 0) { ready = true; break }      // TEST UNIT READY
                command(byteArrayOf(0x03, 0, 0, 0, 18, 0), 18, true, ByteArray(18))          // REQUEST SENSE
            } catch (_: IOException) {
                resetRecovery()
            }
            Thread.sleep(300)
        }
        if (!ready) throw IOException("O pendrive não ficou pronto. Tente desconectar e conectar de novo.")
        val cap = ByteArray(8)
        val cb = ByteArray(10)
        cb[0] = 0x25                                                                         // READ CAPACITY(10)
        if (withRetry { command(cb, 8, true, cap) } != 0) {
            throw IOException("Não consegui ler a capacidade do pendrive")
        }
        val bb = ByteBuffer.wrap(cap).order(ByteOrder.BIG_ENDIAN)
        val last = bb.getInt(0).toLong() and 0xFFFFFFFFL
        val bs = bb.getInt(4)
        if (last == 0xFFFFFFFFL) throw IOException("Pendrives acima de 2 TB não são suportados")
        if (bs <= 0 || bs % 512 != 0) throw IOException("Tamanho de bloco não suportado: $bs")
        blockSize = bs
        blocks = last + 1
    }

    private fun rw(op: Int, lba: Long, n: Int): ByteArray {
        val cb = ByteArray(10)
        cb[0] = op.toByte()
        cb[2] = (lba shr 24).toByte(); cb[3] = (lba shr 16).toByte()
        cb[4] = (lba shr 8).toByte(); cb[5] = lba.toByte()
        cb[7] = (n shr 8).toByte(); cb[8] = n.toByte()
        return cb
    }

    private fun check(offset: Long, len: Int) {
        if (offset < 0 || offset % blockSize != 0L || len % blockSize != 0 || offset + len > size) {
            throw IOException("Acesso fora dos limites do pendrive")
        }
    }

    fun read(offset: Long, len: Int): ByteArray {
        check(offset, len)
        val out = ByteArray(len)
        val maxBlocks = maxOf(1, (256 * 1024) / blockSize)
        var done = 0
        while (done < len) {
            val n = minOf((len - done) / blockSize, maxBlocks)
            val st = withRetry { command(rw(0x28, (offset + done) / blockSize, n), n * blockSize, true, out, done) }
            if (st != 0) throw IOException("Erro de leitura (SCSI)")
            done += n * blockSize
        }
        return out
    }

    fun write(offset: Long, data: ByteArray) {
        check(offset, data.size)
        val maxBlocks = maxOf(1, (256 * 1024) / blockSize)
        var done = 0
        while (done < data.size) {
            val n = minOf((data.size - done) / blockSize, maxBlocks)
            // Escrever o mesmo bloco de novo é seguro, então a tentativa extra não corrompe dados.
            val st = withRetry { command(rw(0x2A, (offset + done) / blockSize, n), n * blockSize, false, data, done) }
            if (st != 0) throw IOException("Erro de escrita (SCSI)")
            done += n * blockSize
        }
    }
}
