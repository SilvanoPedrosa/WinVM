package com.winvm.app.qemu

import com.winvm.app.model.VmState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket

class QmpClient(private val port: Int) {

    suspend fun query(cmd: String): JSONObject = withContext(Dispatchers.IO) {
        Socket().use { s ->
            s.connect(InetSocketAddress("127.0.0.1", port), 800)
            s.soTimeout = 1500
            val w = s.getOutputStream().bufferedWriter()
            val r = s.getInputStream().bufferedReader()
            r.readLine()                                   // saudação
            w.write("""{"execute":"qmp_capabilities"}""" + "\n"); w.flush()
            r.readLine()
            w.write("""{"execute":"$cmd"}""" + "\n"); w.flush()
            var res = JSONObject()
            while (true) {
                val line = r.readLine() ?: break
                val j = JSONObject(line)
                if (j.has("return") || j.has("error")) { res = j; break }   // ignora "event"
            }
            res
        }
    }

    suspend fun send(cmd: String) { query(cmd) }

    /** null = QEMU não responde (VM parada) */
    suspend fun status(): VmState? = runCatching {
        val st = query("query-status").getJSONObject("return").getString("status")
        if (st == "paused" || st == "prelaunch") VmState.PAUSED else VmState.RUNNING
    }.getOrNull()
}
