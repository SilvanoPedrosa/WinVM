package com.winvm.app.qemu

import com.winvm.app.model.VmState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket

class QmpClient(private val port: Int) {

    /** Executa um comando QMP (com argumentos opcionais) e devolve {"return":...} ou {"error":...}. */
    suspend fun execute(cmd: String, args: JSONObject? = null, timeoutMs: Int = 5000): JSONObject =
        withContext(Dispatchers.IO) {
            Socket().use { s ->
                s.connect(InetSocketAddress("127.0.0.1", port), 800)
                s.soTimeout = timeoutMs
                val w = s.getOutputStream().bufferedWriter()
                val r = s.getInputStream().bufferedReader()
                r.readLine()                                   // saudação
                w.write("""{"execute":"qmp_capabilities"}""" + "\n"); w.flush()
                r.readLine()
                val req = JSONObject().put("execute", cmd)
                if (args != null) req.put("arguments", args)
                w.write(req.toString() + "\n"); w.flush()
                var res = JSONObject()
                while (true) {
                    val line = r.readLine() ?: break
                    val j = JSONObject(line)
                    if (j.has("return") || j.has("error")) { res = j; break }   // ignora "event"
                }
                res
            }
        }

    suspend fun query(cmd: String): JSONObject = execute(cmd, null, 1500)

    suspend fun send(cmd: String) { query(cmd) }

    /** null = QEMU não responde (VM parada) */
    suspend fun status(): VmState? = runCatching {
        val st = query("query-status").getJSONObject("return").getString("status")
        if (st == "paused" || st == "prelaunch") VmState.PAUSED else VmState.RUNNING
    }.getOrNull()
}
