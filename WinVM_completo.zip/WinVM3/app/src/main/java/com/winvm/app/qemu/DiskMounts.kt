package com.winvm.app.qemu

import com.winvm.app.model.VmConfig
import java.io.File

/**
 * Mapeia onde cada arquivo (disco, discos extras, ISO) aparece DENTRO do Alpine.
 * A pasta da VM é /vm; discos guardados em outra pasta (ex.: Download/WinVM) ganham /ext0, /ext1...
 */
class DiskMounts(private val vmDir: File, cfg: VmConfig) {
    private val extDirs: List<String> =
        (listOf(cfg.diskPath) + cfg.extraDisks.map { it.path } + listOfNotNull(cfg.isoPath))
            .mapNotNull { File(it).parentFile?.path }
            .filter { it != vmDir.path }
            .distinct()

    fun isExternal(hostPath: String): Boolean = File(hostPath).parentFile?.path in extDirs

    fun guestPath(hostPath: String): String {
        val f = File(hostPath)
        val idx = extDirs.indexOf(f.parentFile?.path)
        return if (idx >= 0) "/ext$idx/${f.name}" else "/vm/${f.name}"
    }

    /** Pares (pasta no Android, pasta dentro do Alpine) que o proot precisa montar. */
    fun binds(): List<Pair<String, String>> = extDirs.mapIndexed { i, d -> d to "/ext$i" }
}
