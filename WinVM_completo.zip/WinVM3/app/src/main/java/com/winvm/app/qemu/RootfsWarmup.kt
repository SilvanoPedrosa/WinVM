package com.winvm.app.qemu

import android.content.Context
import java.io.File
import java.nio.file.Files
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Lê o QEMU, as bibliotecas e o firmware do Alpine em segundo plano (uma vez por abertura do app) para o
 * Android deixá-los no cache de memória: o primeiro início da VM não espera a leitura do armazenamento.
 */
object RootfsWarmup {
    private val done = AtomicBoolean(false)

    fun start(ctx: Context) {
        if (!Rootfs.isReady(ctx)) return
        if (!done.compareAndSet(false, true)) return
        val root = Rootfs.dir(ctx)
        Thread({
            runCatching {
                val files = ArrayList<File>()
                files += File(root, "usr/bin/qemu-system-x86_64")
                files += File(root, "usr/bin/qemu-img")
                for (dir in listOf("usr/lib", "lib", "usr/share/qemu", "usr/share/seabios")) {
                    File(root, dir).listFiles()?.filter { it.isFile }?.let { files += it }
                }
                val buf = ByteArray(1 shl 20)
                for (f in files) {
                    if (!f.exists() || Files.isSymbolicLink(f.toPath()) || f.length() > 120L * 1024 * 1024) continue
                    runCatching { f.inputStream().use { i -> while (i.read(buf) > 0) { } } }
                }
            }
        }, "rootfs-warmup").apply {
            priority = Thread.MIN_PRIORITY
            isDaemon = true
        }.start()
    }
}
