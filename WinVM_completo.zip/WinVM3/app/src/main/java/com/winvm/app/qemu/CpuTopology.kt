package com.winvm.app.qemu

import java.io.File

/** Descobre os núcleos mais rápidos do celular (big.LITTLE) para o QEMU rodar neles (taskset -c). */
object CpuTopology {
    /**
     * Lista de núcleos rápidos no formato "4,5,6,7", ou null se todos são iguais / não deu para ler.
     * Núcleo rápido = frequência máxima >= 75% da maior frequência do aparelho.
     */
    fun fastCores(): String? = try {
        val freqs = HashMap<Int, Long>()
        for (i in 0 until 64) {
            val f = File("/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq")
            if (f.exists()) {
                val v = f.readText().trim().toLongOrNull()
                if (v != null && v > 0) freqs[i] = v
            }
        }
        val max = freqs.values.maxOrNull() ?: 0L
        val fast = freqs.filter { it.value * 100 >= max * 75 }.keys.sorted()
        if (freqs.size < 2 || fast.isEmpty() || fast.size == freqs.size) null else fast.joinToString(",")
    } catch (e: Exception) {
        null
    }
}
