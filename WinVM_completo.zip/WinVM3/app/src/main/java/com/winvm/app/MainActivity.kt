package com.winvm.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.winvm.app.model.VmRepository
import com.winvm.app.qemu.QemuService
import com.winvm.app.ui.CreateVmScreen
import com.winvm.app.ui.DisplayScreen
import com.winvm.app.ui.HomeScreen
import com.winvm.app.ui.SetupScreen

class MainActivity : ComponentActivity() {
    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent { MaterialTheme { App() } }
    }
}

@Composable
fun App() {
    val nav = rememberNavController()
    val ctx = LocalContext.current

    NavHost(nav, startDestination = "home") {
        composable("home") {
            HomeScreen(
                onCreate = { nav.navigate("create") },
                onSetup = { nav.navigate("setup") },
                onOpenDisplay = { nav.navigate("display/${it.name}") }
            )
        }
        composable("setup") {
            SetupScreen(onDone = { nav.popBackStack() })
        }
        composable("create") {
            CreateVmScreen { cfg ->
                QemuService.start(ctx, cfg)
                nav.popBackStack()
                nav.navigate("display/${cfg.name}")
            }
        }
        composable("display/{name}") { entry ->
            val name = entry.arguments?.getString("name").orEmpty()
            val cfg = remember(name) { VmRepository.list(ctx).firstOrNull { it.name == name } }
            if (cfg == null) {
                LaunchedEffect(Unit) { nav.popBackStack() }
            } else {
                DisplayScreen(cfg) { nav.popBackStack() }
            }
        }
    }
}
