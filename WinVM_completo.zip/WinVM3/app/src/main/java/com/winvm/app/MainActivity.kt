package com.winvm.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.winvm.app.model.VmConfig
import com.winvm.app.model.VmRepository
import com.winvm.app.qemu.QemuService
import com.winvm.app.ui.CreateVmScreen
import com.winvm.app.ui.DisplayScreen
import com.winvm.app.ui.HomeScreen

class MainActivity : ComponentActivity() {
    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent { MaterialTheme { App() } }
    }
}

@Composable
fun App() {
    val nav = rememberNavController()
    val ctx = LocalContext.current

    fun openDisplay(c: VmConfig) {
        if (c.useSpice) {
            try {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("spice://127.0.0.1:${c.spicePort}")))
            } catch (e: Exception) {
                Toast.makeText(ctx, "Instale o aSPICE para usar o modo SPICE", Toast.LENGTH_LONG).show()
            }
        } else nav.navigate("display/${c.name}")
    }

    NavHost(nav, startDestination = "home") {
        composable("home") {
            HomeScreen(onCreate = { nav.navigate("create") }, onOpenDisplay = { openDisplay(it) })
        }
        composable("create") {
            CreateVmScreen { cfg ->
                QemuService.start(ctx, cfg)
                nav.popBackStack()
                openDisplay(cfg)
            }
        }
        composable("display/{name}") { entry ->
            val name = entry.arguments?.getString("name").orEmpty()
            val cfg = remember(name) { VmRepository.list(ctx).firstOrNull { it.name == name } }
            if (cfg == null) {
                LaunchedEffect(Unit) { nav.popBackStack() }
            } else {
                DisplayScreen(cfg) { nav.popBackStack() }
            }
        }
    }
}
