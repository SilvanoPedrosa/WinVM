package com.winvm.app.ui

import android.app.Application
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.winvm.app.qemu.Rootfs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SetupViewModel(private val app: Application) : AndroidViewModel(app) {
    var ready by mutableStateOf(Rootfs.isReady(app))
    var busy by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    val logLines = mutableStateListOf<String>()

    private fun push(line: String) {
        logLines.add(line)
        while (logLines.size > 300) logLines.removeAt(0)
    }

    fun install() {
        if (busy) return
        viewModelScope.launch {
            busy = true; error = null
            try {
                Rootfs.install(app) { line ->
                    viewModelScope.launch(Dispatchers.Main.immediate) { push(line) }
                }
                ready = Rootfs.isReady(app)
                if (!ready) error = "Instalação incompleta."
            } catch (e: Exception) {
                error = e.message ?: e.toString()
                push("ERRO: $error")
            } finally {
                busy = false
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SetupScreen(vm: SetupViewModel = viewModel(), onDone: () -> Unit) {
    Scaffold(topBar = { TopAppBar(title = { Text("Ambiente Linux") }) }) { pad ->
        Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.TopCenter) {
        Column(
            Modifier.widthIn(max = 640.dp).fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Instala um Alpine Linux (arm64) dentro do app e, nele, o QEMU. " +
                "Precisa de internet e baixa cerca de 100 MB.")
            if (vm.ready) {
                Text("Ambiente instalado.")
                Button(onClick = onDone, modifier = Modifier.fillMaxWidth()) { Text("Voltar") }
            } else {
                Button(
                    onClick = { vm.install() },
                    enabled = !vm.busy,
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (vm.busy) "Instalando…" else "Instalar ambiente") }
            }
            vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                items(vm.logLines) { Text(it, fontFamily = FontFamily.Monospace, fontSize = 11.sp) }
            }
        }
        }
    }
}
