package com.winvm.app.ui

import android.app.Application
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.background
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.winvm.app.qemu.Rootfs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SetupViewModel(private val app: Application) : AndroidViewModel(app) {
    var ready by mutableStateOf(Rootfs.isReady(app))
    var busy by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    val logLines = mutableStateListOf<String>()

    private fun push(line: String) {
        logLines.add(line)
        while (logLines.size > 300) logLines.removeAt(0)
    }

    fun install() {
        if (busy) return
        viewModelScope.launch {
            busy = true; error = null
            try {
                Rootfs.install(app) { line ->
                    viewModelScope.launch(Dispatchers.Main.immediate) { push(line) }
                }
                ready = Rootfs.isReady(app)
                if (!ready) error = "Instalação incompleta."
            } catch (e: Exception) {
                error = e.message ?: e.toString()
                push("ERRO: $error")
            } finally {
                busy = false
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SetupScreen(vm: SetupViewModel = viewModel(), onDone: () -> Unit) {
    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = { Text("Ambiente Linux") },
                navigationIcon = {
                    IconButton(onClick = onDone) { Icon(Icons.Default.ArrowBack, contentDescription = "Voltar") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.TopCenter) {
            Column(
                Modifier.widthIn(max = 640.dp).fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                SectionCard("Instalação", "Alpine Linux (arm64) com QEMU, dentro do app") {
                    Text(
                        "Precisa de internet e baixa cerca de 100 MB. Mantenha o app aberto durante a instalação.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    if (vm.ready) {
                        Pill(
                            "Ambiente instalado",
                            container = MaterialTheme.colorScheme.primaryContainer,
                            content = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Button(onClick = onDone, modifier = Modifier.fillMaxWidth()) { Text("Voltar") }
                    } else {
                        Button(
                            onClick = { vm.install() },
                            enabled = !vm.busy,
                            modifier = Modifier.fillMaxWidth().height(52.dp)
                        ) {
                            if (vm.busy) {
                                CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.width(10.dp))
                            }
                            Text(if (vm.busy) "Instalando…" else "Instalar ambiente")
                        }
                    }
                    vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }

                Box(
                    Modifier.weight(1f).fillMaxWidth()
                        .clip(MaterialTheme.shapes.large)
                        .background(Color(0xFF0B1418))
                        .padding(14.dp)
                ) {
                    LazyColumn(Modifier.fillMaxSize()) {
                        items(vm.logLines) {
                            Text(it, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color(0xFFBFE3EA))
                        }
                    }
                }
            }
        }
    }
}
