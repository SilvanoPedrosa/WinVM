package com.winvm.app.qemu

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.winvm.app.model.VmConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume

/** Liga pendrives USB (OTG) a uma VM em execução: USB Android -> NBD local -> QEMU usb-storage. */
object UsbBridge {
    private const val ACTION = "com.winvm.app.USB_PERMISSION"

    private class Attached(
        val label: String,
        val deviceName: String,
        val app: Context,
        val storage: MassStorage,
        val server: NbdServer,
        val detachWatch: BroadcastReceiver
    )

    private val attached = ConcurrentHashMap<String, Attached>()

    private fun manager(ctx: Context) = ctx.getSystemService(Context.USB_SERVICE) as UsbManager

    fun isMassStorage(d: UsbDevice): Boolean =
        (0 until d.interfaceCount).any { MassStorage.isBotInterface(d.getInterface(it)) }

    fun massStorageDevices(ctx: Context): List<UsbDevice> =
        manager(ctx).deviceList.values.filter { isMassStorage(it) }.sortedBy { it.deviceName }

    fun label(d: UsbDevice): String {
        val n = listOfNotNull(d.manufacturerName, d.productName).joinToString(" ")
        return if (n.isBlank()) d.deviceName else n
    }

    fun attachedName(vmName: String): String? = attached[vmName]?.label

    private suspend fun requestPermission(ctx: Context, d: UsbDevice): Boolean {
        val app = ctx.applicationContext
        return suspendCancellableCoroutine { cont ->
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(c: Context, i: Intent) {
                    val granted = i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                    runCatching { app.unregisterReceiver(this) }
                    if (cont.isActive) cont.resume(granted)
                }
            }
            ContextCompat.registerReceiver(app, receiver, IntentFilter(ACTION), ContextCompat.RECEIVER_NOT_EXPORTED)
            val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
            val pi = PendingIntent.getBroadcast(app, 0, Intent(ACTION).setPackage(app.packageName), flags)
            manager(app).requestPermission(d, pi)
            cont.invokeOnCancellation { runCatching { app.unregisterReceiver(receiver) } }
        }
    }

    /** Abre o pendrive com algumas tentativas: logo após plugar, ele às vezes demora a responder. */
    private suspend fun openWithRetry(mgr: UsbManager, d: UsbDevice): MassStorage {
        var last: IOException? = null
        for (i in 0 until 3) {
            try {
                return MassStorage.open(mgr, d)
            } catch (e: IOException) {
                last = e
                if (e.message?.contains("não é um pendrive") == true) break   // não adianta tentar de novo
                delay(700L * (i + 1))
            }
        }
        throw last ?: IOException("Não consegui abrir o pendrive")
    }

    private fun deviceFromIntent(i: Intent): UsbDevice? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
        else @Suppress("DEPRECATION") i.getParcelableExtra(UsbManager.EXTRA_DEVICE)

    /** Se o pendrive for tirado do cabo, a VM é desligada do pendrive automaticamente. */
    private fun watchDetach(app: Context, deviceName: String, cfg: VmConfig): BroadcastReceiver {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                if (i.action != UsbManager.ACTION_USB_DEVICE_DETACHED) return
                val gone = deviceFromIntent(i) ?: return
                if (gone.deviceName == deviceName) {
                    CoroutineScope(Dispatchers.IO).launch { eject(cfg) }
                }
            }
        }
        ContextCompat.registerReceiver(
            app, r, IntentFilter(UsbManager.ACTION_USB_DEVICE_DETACHED), ContextCompat.RECEIVER_EXPORTED
        )
        return r
    }

    private fun release(a: Attached) {
        runCatching { a.app.unregisterReceiver(a.detachWatch) }
        a.server.close()
        a.storage.close()
    }

    /** Devolve null se deu certo, ou a mensagem de erro. */
    suspend fun attach(ctx: Context, d: UsbDevice, cfg: VmConfig, readOnly: Boolean): String? =
        withContext(Dispatchers.IO) {
            try {
                val old = attached[cfg.name]
                if (old != null) {
                    if (QmpClient(cfg.qmpPort).status() == null) {      // VM parou: limpa o que sobrou
                        attached.remove(cfg.name)
                        release(old)
                    } else {
                        return@withContext "Já há um pendrive nesta VM. Ejete primeiro."
                    }
                }
                val app = ctx.applicationContext
                val mgr = manager(ctx)
                if (!mgr.hasPermission(d) && !requestPermission(ctx, d)) {
                    return@withContext "Permissão USB negada."
                }
                val ms = openWithRetry(mgr, d)
                val srv = NbdServer(ms, readOnly)
                srv.start()
                val q = QmpClient(cfg.qmpPort)
                val serverJson = JSONObject().put("type", "inet").put("host", "127.0.0.1").put("port", srv.port.toString())
                val add = q.execute(
                    "blockdev-add",
                    JSONObject().put("driver", "nbd").put("node-name", "usbblk0")
                        .put("server", serverJson).put("read-only", readOnly),
                    15000
                )
                add.optJSONObject("error")?.let {
                    srv.close(); ms.close()
                    return@withContext "QEMU: " + it.optString("desc")
                }
                val dev = q.execute(
                    "device_add",
                    JSONObject().put("driver", "usb-storage").put("id", "usbdev0")
                        .put("drive", "usbblk0").put("bus", "usb.0"),
                    10000
                )
                dev.optJSONObject("error")?.let {
                    runCatching { q.execute("blockdev-del", JSONObject().put("node-name", "usbblk0")) }
                    srv.close(); ms.close()
                    return@withContext "QEMU: " + it.optString("desc")
                }
                val watch = watchDetach(app, d.deviceName, cfg)
                attached[cfg.name] = Attached(label(d), d.deviceName, app, ms, srv, watch)
                null
            } catch (e: Exception) {
                e.message ?: e.toString()
            }
        }

    /**
     * Desconecta o pendrive da VM. Só fecha a ponte depois que o QEMU confirmar a remoção:
     * se o sistema da VM ainda estiver usando o pendrive, nada é fechado e o usuário tenta de novo.
     */
    suspend fun eject(cfg: VmConfig): String? = withContext(Dispatchers.IO) {
        val a = attached[cfg.name] ?: return@withContext null
        val q = QmpClient(cfg.qmpPort)
        if (q.status() == null) {                                 // VM já parou
            attached.remove(cfg.name); release(a)
            return@withContext null
        }
        runCatching { q.execute("device_del", JSONObject().put("id", "usbdev0")) }
        var removed = false
        for (i in 0 until 10) {
            delay(400)
            val r = runCatching { q.execute("blockdev-del", JSONObject().put("node-name", "usbblk0")) }.getOrNull()
            if (r != null && r.optJSONObject("error") == null) { removed = true; break }
        }
        if (!removed) {
            return@withContext "O sistema da VM ainda está usando o pendrive. Use \"Remover com segurança\" lá dentro e tente de novo."
        }
        attached.remove(cfg.name)
        release(a)
        null
    }
}
