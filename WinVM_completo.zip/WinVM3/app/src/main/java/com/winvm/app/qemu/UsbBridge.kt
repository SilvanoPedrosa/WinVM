package com.winvm.app.qemu

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.winvm.app.model.VmConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume

/** Liga pendrives USB (OTG) a uma VM em execução: USB Android -> NBD local -> QEMU usb-storage. */
object UsbBridge {
    private const val ACTION = "com.winvm.app.USB_PERMISSION"

    private class Attached(val label: String, val storage: MassStorage, val server: NbdServer)

    private val attached = ConcurrentHashMap<String, Attached>()

    private fun manager(ctx: Context) = ctx.getSystemService(Context.USB_SERVICE) as UsbManager

    fun isMassStorage(d: UsbDevice): Boolean {
        for (i in 0 until d.interfaceCount) {
            val itf = d.getInterface(i)
            if (itf.interfaceClass == 8 && itf.interfaceSubclass == 6 && itf.interfaceProtocol == 0x50) return true
        }
        return false
    }

    fun massStorageDevices(ctx: Context): List<UsbDevice> =
        manager(ctx).deviceList.values.filter { isMassStorage(it) }

    fun label(d: UsbDevice): String {
        val n = listOfNotNull(d.manufacturerName, d.productName).joinToString(" ")
        return if (n.isBlank()) d.deviceName else n
    }

    fun attachedName(vmName: String): String? = attached[vmName]?.label

    private suspend fun requestPermission(ctx: Context, d: UsbDevice): Boolean {
        val app = ctx.applicationContext
        return suspendCancellableCoroutine { cont ->
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(c: Context, i: Intent) {
                    val granted = i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                    runCatching { app.unregisterReceiver(this) }
                    if (cont.isActive) cont.resume(granted)
                }
            }
            ContextCompat.registerReceiver(app, receiver, IntentFilter(ACTION), ContextCompat.RECEIVER_NOT_EXPORTED)
            val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
            val pi = PendingIntent.getBroadcast(app, 0, Intent(ACTION).setPackage(app.packageName), flags)
            manager(app).requestPermission(d, pi)
            cont.invokeOnCancellation { runCatching { app.unregisterReceiver(receiver) } }
        }
    }

    /** Devolve null se deu certo, ou a mensagem de erro. */
    suspend fun attach(ctx: Context, d: UsbDevice, cfg: VmConfig, readOnly: Boolean): String? =
        withContext(Dispatchers.IO) {
            try {
                val old = attached[cfg.name]
                if (old != null) {
                    if (QmpClient(cfg.qmpPort).status() == null) {      // VM parou: limpa o que sobrou
                        attached.remove(cfg.name)
                        old.server.close(); old.storage.close()
                    } else {
                        return@withContext "Já há um pendrive nesta VM. Ejete primeiro."
                    }
                }
                val mgr = manager(ctx)
                if (!mgr.hasPermission(d) && !requestPermission(ctx, d)) {
                    return@withContext "Permissão USB negada."
                }
                val ms = MassStorage.open(mgr, d)
                val srv = NbdServer(ms, readOnly)
                srv.start()
                val q = QmpClient(cfg.qmpPort)
                val serverJson = JSONObject().put("type", "inet").put("host", "127.0.0.1").put("port", srv.port.toString())
                val add = q.execute(
                    "blockdev-add",
                    JSONObject().put("driver", "nbd").put("node-name", "usbblk0")
                        .put("server", serverJson).put("read-only", readOnly),
                    15000
                )
                add.optJSONObject("error")?.let {
                    srv.close(); ms.close()
                    return@withContext "QEMU: " + it.optString("desc")
                }
                val dev = q.execute(
                    "device_add",
                    JSONObject().put("driver", "usb-storage").put("id", "usbdev0")
                        .put("drive", "usbblk0").put("bus", "usb.0"),
                    10000
                )
                dev.optJSONObject("error")?.let {
                    runCatching { q.execute("blockdev-del", JSONObject().put("node-name", "usbblk0")) }
                    srv.close(); ms.close()
                    return@withContext "QEMU: " + it.optString("desc")
                }
                attached[cfg.name] = Attached(label(d), ms, srv)
                null
            } catch (e: Exception) {
                e.message ?: e.toString()
            }
        }

    suspend fun eject(cfg: VmConfig): String? = withContext(Dispatchers.IO) {
        val a = attached.remove(cfg.name) ?: return@withContext null
        val q = QmpClient(cfg.qmpPort)
        runCatching { q.execute("device_del", JSONObject().put("id", "usbdev0")) }
        for (i in 0 until 4) {
            delay(400)
            val r = runCatching { q.execute("blockdev-del", JSONObject().put("node-name", "usbblk0")) }.getOrNull()
            if (r != null && r.optJSONObject("error") == null) break
        }
        a.server.close()
        a.storage.close()
        null
    }
}
