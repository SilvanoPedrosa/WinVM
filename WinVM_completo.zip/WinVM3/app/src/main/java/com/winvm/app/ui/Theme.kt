package com.winvm.app.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Surface
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

private val LightColors = lightColorScheme(
    primary = Color(0xFF2B6F80),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCDE9F0),
    onPrimaryContainer = Color(0xFF0B2A33),
    secondary = Color(0xFF4F6B74),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD7E7EC),
    onSecondaryContainer = Color(0xFF0D242B),
    tertiary = Color(0xFF6A5B8C),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFE6DEFF),
    onTertiaryContainer = Color(0xFF231A42),
    background = Color(0xFFF2F7F8),
    onBackground = Color(0xFF111D21),
    surface = Color(0xFFF2F7F8),
    onSurface = Color(0xFF111D21),
    surfaceVariant = Color(0xFFDDE8EB),
    onSurfaceVariant = Color(0xFF3F5359),
    outline = Color(0xFF70858B),
    outlineVariant = Color(0xFFC1D0D4),
    error = Color(0xFFBA1A1A),
    onError = Color.White,
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFE9F1F3),
    surfaceContainer = Color(0xFFE2ECEF),
    surfaceContainerHigh = Color(0xFFDAE6E9),
    surfaceContainerHighest = Color(0xFFD3E0E4)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF8FCDDF),
    onPrimary = Color(0xFF00363F),
    primaryContainer = Color(0xFF1B4F5C),
    onPrimaryContainer = Color(0xFFCDE9F0),
    secondary = Color(0xFFB6CCD3),
    onSecondary = Color(0xFF21373E),
    secondaryContainer = Color(0xFF384F56),
    onSecondaryContainer = Color(0xFFD7E7EC),
    tertiary = Color(0xFFCFBFF5),
    onTertiary = Color(0xFF362B5A),
    tertiaryContainer = Color(0xFF4E4273),
    onTertiaryContainer = Color(0xFFE6DEFF),
    background = Color(0xFF0E181C),
    onBackground = Color(0xFFDCE6E9),
    surface = Color(0xFF0E181C),
    onSurface = Color(0xFFDCE6E9),
    surfaceVariant = Color(0xFF3F5359),
    onSurfaceVariant = Color(0xFFC1D0D4),
    outline = Color(0xFF8A9DA3),
    outlineVariant = Color(0xFF3F5359),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
    surfaceContainerLowest = Color(0xFF0A1316),
    surfaceContainerLow = Color(0xFF131F24),
    surfaceContainer = Color(0xFF16252B),
    surfaceContainerHigh = Color(0xFF1D2F36),
    surfaceContainerHighest = Color(0xFF253A42)
)

/** Cantos bem arredondados em todo o app. */
private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(10.dp),
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(36.dp)
)

private val BaseTypography = Typography()
private val AppTypography = BaseTypography.copy(
    headlineMedium = BaseTypography.headlineMedium.copy(fontWeight = FontWeight.Bold),
    headlineSmall = BaseTypography.headlineSmall.copy(fontWeight = FontWeight.Bold),
    titleLarge = BaseTypography.titleLarge.copy(fontWeight = FontWeight.SemiBold),
    titleMedium = BaseTypography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
    titleSmall = BaseTypography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
    labelLarge = BaseTypography.labelLarge.copy(fontWeight = FontWeight.SemiBold)
)

@Composable
fun WinVmTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val colors = if (dark) DarkColors else LightColors
    val view = LocalView.current
    SideEffect {
        val window = view.context.findHostActivity()?.window
        if (window != null) {
            // barras do sistema na mesma cor do app, com ícones claros/escuros conforme o tema
            window.statusBarColor = colors.background.toArgb()
            window.navigationBarColor = colors.background.toArgb()
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !dark
            controller.isAppearanceLightNavigationBars = !dark
        }
    }
    MaterialTheme(colorScheme = colors, typography = AppTypography, shapes = AppShapes) {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            content()
        }
    }
}

private fun Context.findHostActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}
