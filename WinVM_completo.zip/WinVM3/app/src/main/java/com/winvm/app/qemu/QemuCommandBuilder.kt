package com.winvm.app.qemu

import com.winvm.app.model.VmConfig
import java.io.File

/** Argumentos do QEMU DENTRO do Alpine. A pasta da VM aparece lá como /vm. */
object QemuCommandBuilder {
    private fun guestPath(hostPath: String) = "/vm/" + File(hostPath).name

    /** resume = true => volta do estado salvo pelo botão Hibernar (-loadvm hib). */
    fun build(c: VmConfig, resume: Boolean = false): List<String> = buildList {
        add("qemu-system-x86_64")
        // Sem dispositivos padrão (serial, paralela, disquete...): inicia mais rápido
        addAll(listOf("-nodefaults", "-no-user-config"))
        // pc (i440fx) + IDE + e1000: o Windows instala sem drivers extras. HPET desligado = menos timers
        addAll(listOf("-machine", "pc,hpet=off"))
        addAll(listOf("-cpu", c.cpuModel.ifBlank { "max" }))
        // 1 soquete: o Windows Home só usa 1-2 soquetes
        addAll(listOf("-smp", "${c.cpus},sockets=1,cores=${c.cpus},threads=1", "-m", "${c.ramMb}"))
        // cache de tradução do TCG proporcional à RAM (mais cache = menos retradução = boot mais rápido)
        val tb = (c.ramMb / 2).coerceIn(256, 1024)
        addAll(listOf("-accel", "tcg,thread=multi,tb-size=$tb"))
        addAll(listOf("-rtc", "base=localtime"))

        // IDE: 0 = disco principal, 1 e 3 = discos extras, 2 = CD-ROM
        addAll(listOf("-drive", "file=${guestPath(c.diskPath)},format=${c.diskFormat},if=ide,index=0,media=disk"))
        c.extraDisks.take(2).forEachIndexed { i, d ->
            val idx = if (i == 0) 1 else 3
            addAll(listOf("-drive", "file=${guestPath(d.path)},format=${d.format},if=ide,index=$idx,media=disk"))
        }
        c.isoPath?.let {
            addAll(listOf("-drive", "file=${guestPath(it)},if=ide,index=2,media=cdrom,readonly=on"))
            addAll(listOf("-boot", "order=dc,menu=off"))
        }

        addAll(listOf("-netdev", "user,id=n0", "-device", "e1000,netdev=n0"))
        // USB 2.0 (EHCI) + mouse absoluto; pendrives entram a quente por esse barramento (usb.0)
        addAll(listOf("-device", "usb-ehci,id=usb", "-device", "usb-tablet,bus=usb.0"))

        // Placa de vídeo + memória de vídeo (+ resolução preferida via EDID na VGA padrão)
        addAll(listOf("-display", "none", "-vga", "none"))
        val vram = c.vramMb.coerceIn(8, 256)
        val video = when (c.videoCard) {
            "vmware" -> "vmware-svga,vgamem_mb=$vram"
            "cirrus" -> "cirrus-vga,vgamem_mb=${if (vram >= 16) 16 else 8}"
            else ->
                if (c.width > 0 && c.height > 0) "VGA,vgamem_mb=$vram,edid=on,xres=${c.width},yres=${c.height}"
                else "VGA,vgamem_mb=$vram"
        }
        addAll(listOf("-device", video))

        addAll(listOf("-vnc", "127.0.0.1:${c.vncPort}"))
        addAll(listOf("-qmp", "tcp:127.0.0.1:${c.qmpPort},server,nowait"))
        if (resume) addAll(listOf("-loadvm", "hib"))
    }
}
