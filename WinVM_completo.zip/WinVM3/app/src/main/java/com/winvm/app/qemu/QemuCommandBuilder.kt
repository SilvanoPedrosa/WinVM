package com.winvm.app.qemu

import com.winvm.app.model.VmConfig
import java.io.File

/** Argumentos do QEMU DENTRO do Alpine. A pasta da VM aparece lá como /vm. */
object QemuCommandBuilder {
    private fun guestPath(hostPath: String) = "/vm/" + File(hostPath).name

    fun build(c: VmConfig): List<String> = buildList {
        add("qemu-system-x86_64")
        // pc (i440fx) + IDE + e1000: o Windows instala sem drivers extras
        addAll(listOf("-machine", "pc", "-cpu", "max"))
        addAll(listOf("-smp", "${c.cpus}", "-m", "${c.ramMb}"))
        addAll(listOf("-accel", "tcg,thread=multi,tb-size=512"))
        addAll(listOf("-rtc", "base=localtime"))

        // IDE: 0 = disco principal, 1 e 3 = discos extras, 2 = CD-ROM
        addAll(listOf("-drive", "file=${guestPath(c.diskPath)},format=${c.diskFormat},if=ide,index=0,media=disk"))
        c.extraDisks.take(2).forEachIndexed { i, d ->
            val idx = if (i == 0) 1 else 3
            addAll(listOf("-drive", "file=${guestPath(d.path)},format=${d.format},if=ide,index=$idx,media=disk"))
        }
        c.isoPath?.let {
            addAll(listOf("-drive", "file=${guestPath(it)},if=ide,index=2,media=cdrom,readonly=on"))
            addAll(listOf("-boot", "order=dc"))
        }

        addAll(listOf("-netdev", "user,id=n0", "-device", "e1000,netdev=n0"))
        addAll(listOf("-device", "usb-ehci,id=usb", "-device", "usb-tablet,bus=usb.0"))   // mouse absoluto

        add("-display"); add("none")
        if (c.width > 0 && c.height > 0) {
            // resolução preferida (EDID) + memória de vídeo grande para liberar modos altos
            addAll(listOf("-vga", "none"))
            addAll(listOf("-device", "VGA,vgamem_mb=64,edid=on,xres=${c.width},yres=${c.height}"))
        } else {
            addAll(listOf("-vga", "std"))
        }
        addAll(listOf("-vnc", "127.0.0.1:${c.vncPort}"))
        addAll(listOf("-qmp", "tcp:127.0.0.1:${c.qmpPort},server,nowait"))
    }
}
