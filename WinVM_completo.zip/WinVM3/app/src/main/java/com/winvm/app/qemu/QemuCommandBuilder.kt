package com.winvm.app.qemu

import com.winvm.app.model.VmConfig
import java.io.File

/** Argumentos do QEMU DENTRO do Alpine. A pasta da VM aparece lá como /vm. */
object QemuCommandBuilder {
    private fun guestPath(hostPath: String) = "/vm/" + File(hostPath).name

    fun build(c: VmConfig): List<String> = buildList {
        add("qemu-system-x86_64")
        // pc (i440fx) + IDE + e1000: o Windows instala sem drivers extras
        addAll(listOf("-machine", "pc", "-cpu", "max"))
        addAll(listOf("-smp", "${c.cpus}", "-m", "${c.ramMb}"))
        addAll(listOf("-accel", "tcg,thread=multi,tb-size=512"))
        addAll(listOf("-rtc", "base=localtime"))

        addAll(listOf("-drive", "file=${guestPath(c.diskPath)},format=qcow2,if=ide,index=0,media=disk"))
        c.isoPath?.let {
            addAll(listOf("-drive", "file=${guestPath(it)},if=ide,index=2,media=cdrom,readonly=on"))
            addAll(listOf("-boot", "order=dc"))
        }

        addAll(listOf("-netdev", "user,id=n0", "-device", "e1000,netdev=n0"))
        addAll(listOf("-device", "usb-ehci,id=usb", "-device", "usb-tablet,bus=usb.0"))   // mouse absoluto

        addAll(listOf("-display", "none", "-vga", "std"))
        addAll(listOf("-vnc", "127.0.0.1:${c.vncPort}"))
        addAll(listOf("-qmp", "tcp:127.0.0.1:${c.qmpPort},server,nowait"))
    }
}
