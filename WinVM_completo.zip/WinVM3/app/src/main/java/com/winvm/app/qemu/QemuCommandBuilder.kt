package com.winvm.app.qemu

import com.winvm.app.model.VmConfig
import java.io.File

/** Argumentos do QEMU DENTRO do Alpine. A pasta da VM aparece lá como /vm. */
object QemuCommandBuilder {
    /** Versão do formato do estado hibernado: muda quando a linha de comando muda de forma incompatível. */
    const val HIB_VERSION = "4"

    /** resume = true => volta do estado salvo pelo botão Hibernar (-loadvm hib). */
    fun build(
        c: VmConfig,
        resume: Boolean,
        audio: Boolean,
        mounts: DiskMounts,
        fastCores: String? = null
    ): List<String> = buildList {
        // CPU turbo: fixa o QEMU nos núcleos mais rápidos do celular (taskset do Alpine)
        if (c.cpuTurbo && fastCores != null) {
            add("taskset"); add("-c"); add(fastCores)
        }
        add("qemu-system-x86_64")
        // Sem dispositivos padrão (serial, paralela, disquete...): inicia mais rápido
        addAll(listOf("-nodefaults", "-no-user-config"))
        // pc (i440fx) + IDE + e1000: o Windows instala sem drivers extras. HPET desligado = menos timers
        // smm/vmport desligados: menos dispositivos e interrupções (vmport só é útil com a placa VMware)
        val vmport = if (c.videoCard == "vmware") "" else ",vmport=off"
        addAll(listOf("-machine", "pc,hpet=off,smm=off$vmport"))
        // "Automática" vira Nehalem com CPU turbo: sem AVX, que na emulação é bem mais lento
        val cpu = c.cpuModel.ifBlank { "max" }.let { if (c.cpuTurbo && it == "max") "Nehalem" else it }
        addAll(listOf("-cpu", cpu))
        // 1 soquete: o Windows Home só usa 1-2 soquetes
        addAll(listOf("-smp", "${c.vcpus},sockets=1,cores=${c.vcpus},threads=1", "-m", "${c.ramMb}"))
        // cache de tradução do TCG proporcional à RAM (mais cache = menos retradução = boot mais rápido)
        val tb = (c.ramMb / 2).coerceIn(256, 1024)
        // 1 thread: x86 em ARM com várias threads precisa de barreiras de memória em cada acesso (bem mais lento)
        val thread = if (c.cpuTurbo || c.vcpus == 1) "single" else "multi"
        addAll(listOf("-accel", "tcg,thread=$thread,tb-size=$tb"))
        addAll(listOf("-rtc", "base=localtime"))

        // IDE: 0 = disco principal, 1 e 3 = discos extras, 2 = CD-ROM
        // locking=off em discos fora do app (pasta Download): o sistema de arquivos do Android não aceita travas
        fun lock(path: String) = if (mounts.isExternal(path)) ",locking=off" else ""
        // Disco turbo: o QEMU ignora o pedido de gravação forçada (fsync) do convidado, que no Android é lento
        val cache = if (c.diskTurbo) ",cache=unsafe" else ""
        // qcow2: cache de tabelas de 8 MB (cobre ~64 GB de disco) = bem menos leituras de metadados no boot
        fun l2(format: String) = if (format == "qcow2") ",l2-cache-size=8M" else ""
        addAll(listOf("-drive", "file=${mounts.guestPath(c.diskPath)},format=${c.diskFormat},if=ide,index=0,media=disk${lock(c.diskPath)}$cache${l2(c.diskFormat)}"))
        c.extraDisks.take(2).forEachIndexed { i, d ->
            val idx = if (i == 0) 1 else 3
            addAll(listOf("-drive", "file=${mounts.guestPath(d.path)},format=${d.format},if=ide,index=$idx,media=disk${lock(d.path)}$cache${l2(d.format)}"))
        }
        c.isoPath?.let {
            addAll(listOf("-drive", "file=${mounts.guestPath(it)},if=ide,index=2,media=cdrom,readonly=on"))
            // 1ª inicialização pelo CD; depois que o instalador reinicia vai direto ao disco (sem "pressione uma tecla")
            addAll(listOf("-boot", "order=c,once=d,menu=off"))
        }
        // sem ISO: vai direto ao disco, sem esperar o menu de boot
        if (c.isoPath == null) addAll(listOf("-boot", "order=c,menu=off"))

        // Internet: rede NAT que usa a conexão do celular (Wi-Fi ou dados). "none" = VM sem rede.
        if (c.netModel != "none") {
            addAll(listOf("-netdev", "user,id=n0,ipv6=off", "-device", "${c.netModel},netdev=n0"))
        }
        // USB 2.0 (EHCI) + mouse absoluto; pendrives entram a quente por esse barramento (usb.0)
        addAll(listOf("-device", "usb-ehci,id=usb", "-device", "usb-tablet,bus=usb.0"))

        // Som: o QEMU escreve PCM num FIFO (/vm/audio.fifo) e o app toca com AudioTrack (AudioBridge)
        if (audio && c.audioCard != "none") {
            addAll(listOf("-audiodev", "wav,id=snd0,path=/vm/audio.fifo,out.frequency=44100,out.channels=2,out.format=s16"))
            when (c.audioCard) {
                "ac97" -> addAll(listOf("-device", "AC97,audiodev=snd0"))
                "sb16" -> addAll(listOf("-device", "sb16,audiodev=snd0"))
                else -> addAll(listOf("-device", "intel-hda,id=hda0", "-device", "hda-output,bus=hda0.0,audiodev=snd0"))
            }
        }

        // Placa de vídeo + memória de vídeo (+ resolução preferida via EDID na VGA padrão)
        addAll(listOf("-display", "none", "-vga", "none"))
        val vram = c.vramMb.coerceIn(8, 256)
        val video = when (c.videoCard) {
            "vmware" -> "vmware-svga,vgamem_mb=$vram"
            "cirrus" -> "cirrus-vga,vgamem_mb=${if (vram >= 16) 16 else 8}"
            else ->
                if (c.width > 0 && c.height > 0) "VGA,vgamem_mb=$vram,edid=on,xres=${c.width},yres=${c.height}"
                else "VGA,vgamem_mb=$vram"
        }
        addAll(listOf("-device", video))

        addAll(listOf("-vnc", "127.0.0.1:${c.vncPort},key-delay-ms=0"))
        addAll(listOf("-qmp", "tcp:127.0.0.1:${c.qmpPort},server,nowait"))
        if (resume) addAll(listOf("-loadvm", "hib"))
    }
}
