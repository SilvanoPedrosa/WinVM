package com.winvm.app.qemu

import android.content.Context
import com.winvm.app.model.VmConfig

object QemuCommandBuilder {
    fun build(ctx: Context, c: VmConfig): List<String> = buildList {
        add(QemuPaths.bin(ctx).path)
        addAll(listOf("-L", QemuPaths.share(ctx).path))

        // pc (i440fx) + IDE + e1000: o Windows instala sem drivers extras
        addAll(listOf("-machine", "pc", "-cpu", "max"))
        addAll(listOf("-smp", "${c.cpus}", "-m", "${c.ramMb}"))
        addAll(listOf("-accel", "tcg,thread=multi,tb-size=512"))
        addAll(listOf("-rtc", "base=localtime"))

        addAll(listOf("-drive", "file=${c.diskPath},format=qcow2,if=ide,index=0,media=disk"))
        c.isoPath?.let {
            addAll(listOf("-drive", "file=$it,if=ide,index=2,media=cdrom,readonly=on"))
            addAll(listOf("-boot", "order=dc"))
        }

        addAll(listOf("-netdev", "user,id=n0", "-device", "e1000,netdev=n0"))

        // mouse absoluto (evita cursor desalinhado no VNC)
        addAll(listOf("-device", "usb-ehci,id=usb", "-device", "usb-tablet,bus=usb.0"))

        addAll(listOf("-display", "none"))
        if (c.useSpice) {
            addAll(listOf("-vga", "qxl"))
            addAll(listOf("-spice", "port=${c.spicePort},addr=127.0.0.1,disable-ticketing=on"))
            addAll(listOf("-device", "virtio-serial"))
            addAll(listOf("-chardev", "spicevmc,id=vda,name=vdagent"))
            addAll(listOf("-device", "virtserialport,chardev=vda,name=com.redhat.spice.0"))
        } else {
            addAll(listOf("-vga", "std"))
            addAll(listOf("-vnc", "127.0.0.1:${c.vncPort}"))
        }
        addAll(listOf("-qmp", "tcp:127.0.0.1:${c.qmpPort},server,nowait"))
    }
}
