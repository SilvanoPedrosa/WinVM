package com.winvm.app.qemu

import android.view.KeyEvent

object Keysyms {
    const val BACKSPACE = 0xFF08; const val TAB = 0xFF09; const val ENTER = 0xFF0D
    const val ESC = 0xFF1B; const val DELETE = 0xFFFF; const val HOME = 0xFF50
    const val LEFT = 0xFF51; const val UP = 0xFF52; const val RIGHT = 0xFF53
    const val DOWN = 0xFF54; const val SHIFT = 0xFFE1
    const val CTRL = 0xFFE3; const val ALT = 0xFFE9; const val SUPER = 0xFFEB
    const val INSERT = 0xFF63; const val END = 0xFF57; const val PGUP = 0xFF55; const val PGDN = 0xFF56
    const val PRINT = 0xFF61; const val CAPS = 0xFFE5; const val NUMLOCK = 0xFF7F; const val MENU = 0xFF67
    const val KP_ENTER = 0xFF8D

    /** F1..F12 */
    fun f(n: Int): Int = 0xFFBE + (n - 1)

    /** ASCII e Latin-1 = próprio código; demais = keysym Unicode. */
    fun fromChar(c: Char): Int = if (c.code < 0x100) c.code else 0x01000000 + c.code

    /** Teclas especiais do Android (KEYCODE_*) -> keysym X11. null = não é tecla especial (usa o caractere). */
    fun fromAndroidKey(code: Int): Int? = when (code) {
        in KeyEvent.KEYCODE_F1..KeyEvent.KEYCODE_F12 -> f(code - KeyEvent.KEYCODE_F1 + 1)
        KeyEvent.KEYCODE_ESCAPE -> ESC
        KeyEvent.KEYCODE_TAB -> TAB
        KeyEvent.KEYCODE_ENTER -> ENTER
        KeyEvent.KEYCODE_NUMPAD_ENTER -> KP_ENTER
        KeyEvent.KEYCODE_DEL -> BACKSPACE
        KeyEvent.KEYCODE_FORWARD_DEL -> DELETE
        KeyEvent.KEYCODE_INSERT -> INSERT
        KeyEvent.KEYCODE_MOVE_HOME -> HOME
        KeyEvent.KEYCODE_MOVE_END -> END
        KeyEvent.KEYCODE_PAGE_UP -> PGUP
        KeyEvent.KEYCODE_PAGE_DOWN -> PGDN
        KeyEvent.KEYCODE_DPAD_LEFT -> LEFT
        KeyEvent.KEYCODE_DPAD_UP -> UP
        KeyEvent.KEYCODE_DPAD_RIGHT -> RIGHT
        KeyEvent.KEYCODE_DPAD_DOWN -> DOWN
        KeyEvent.KEYCODE_SHIFT_LEFT -> SHIFT
        KeyEvent.KEYCODE_SHIFT_RIGHT -> 0xFFE2
        KeyEvent.KEYCODE_CTRL_LEFT -> CTRL
        KeyEvent.KEYCODE_CTRL_RIGHT -> 0xFFE4
        KeyEvent.KEYCODE_ALT_LEFT -> ALT
        KeyEvent.KEYCODE_ALT_RIGHT -> 0xFFEA
        KeyEvent.KEYCODE_META_LEFT -> SUPER
        KeyEvent.KEYCODE_META_RIGHT -> 0xFFEC
        KeyEvent.KEYCODE_SCROLL_LOCK -> 0xFF14
        KeyEvent.KEYCODE_BREAK -> 0xFF13
        KeyEvent.KEYCODE_SYSRQ -> PRINT
        KeyEvent.KEYCODE_MENU -> MENU
        in KeyEvent.KEYCODE_NUMPAD_0..KeyEvent.KEYCODE_NUMPAD_9 -> 0xFFB0 + (code - KeyEvent.KEYCODE_NUMPAD_0)
        KeyEvent.KEYCODE_NUMPAD_DIVIDE -> 0xFFAF
        KeyEvent.KEYCODE_NUMPAD_MULTIPLY -> 0xFFAA
        KeyEvent.KEYCODE_NUMPAD_SUBTRACT -> 0xFFAD
        KeyEvent.KEYCODE_NUMPAD_ADD -> 0xFFAB
        KeyEvent.KEYCODE_NUMPAD_DOT -> 0xFFAE
        KeyEvent.KEYCODE_NUMPAD_COMMA -> 0xFFAC
        KeyEvent.KEYCODE_NUMPAD_EQUALS -> 0xFFBD
        else -> null
    }
}
