package com.winvm.app.qemu

object Keysyms {
    const val BACKSPACE = 0xFF08; const val TAB = 0xFF09; const val ENTER = 0xFF0D
    const val ESC = 0xFF1B; const val DELETE = 0xFFFF; const val HOME = 0xFF50
    const val LEFT = 0xFF51; const val UP = 0xFF52; const val RIGHT = 0xFF53
    const val DOWN = 0xFF54; const val SHIFT = 0xFFE1
    const val CTRL = 0xFFE3; const val ALT = 0xFFE9; const val SUPER = 0xFFEB

    /** ASCII e Latin-1 = próprio código; demais = keysym Unicode. */
    fun fromChar(c: Char): Int = if (c.code < 0x100) c.code else 0x01000000 + c.code
}
