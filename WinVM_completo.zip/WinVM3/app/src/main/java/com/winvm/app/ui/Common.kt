package com.winvm.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** 0 x 0 = automática. */
val RESOLUTIONS = listOf(
    0 to 0, 640 to 480, 800 to 600, 1024 to 768, 1280 to 720,
    1280 to 800, 1366 to 768, 1600 to 900, 1920 to 1080
)

/** Modelos de CPU do QEMU (identificam a VM como Intel ou AMD). */
val CPU_MODELS = listOf(
    "max" to "Automática (mais compatível)",
    "Nehalem" to "Intel Nehalem (clássico)",
    "Haswell-noTSX" to "Intel Haswell (moderno)",
    "phenom" to "AMD Phenom (clássico)",
    "EPYC" to "AMD EPYC (moderno)"
)

val VIDEO_CARDS = listOf(
    "std" to "VGA padrão (recomendada)",
    "vmware" to "VMware SVGA",
    "cirrus" to "Cirrus Logic (antiga: Win 9x/XP)"
)

val VRAM_OPTIONS = listOf(16, 32, 64, 128, 256)

fun resolutionLabel(w: Int, h: Int): String =
    if (w <= 0 || h <= 0) "Automática (o sistema escolhe)" else "$w x $h"

@Composable
fun <T> OptionPicker(
    title: String,
    selectedLabel: String,
    options: List<Pair<T, String>>,
    onPick: (T) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            Text("$title: $selectedLabel")
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { (value, label) ->
                DropdownMenuItem(
                    text = { Text(label) },
                    onClick = { onPick(value); open = false }
                )
            }
        }
    }
}

@Composable
fun ResolutionPicker(width: Int, height: Int, onPick: (Int, Int) -> Unit) {
    OptionPicker(
        title = "Resolução",
        selectedLabel = resolutionLabel(width, height),
        options = RESOLUTIONS.map { it to resolutionLabel(it.first, it.second) },
        onPick = { onPick(it.first, it.second) }
    )
}

/** Processador, placa de vídeo, memória de vídeo e resolução. */
@Composable
fun HardwarePickers(
    cpu: String, onCpu: (String) -> Unit,
    card: String, onCard: (String) -> Unit,
    vram: Int, onVram: (Int) -> Unit,
    resW: Int, resH: Int, onRes: (Int, Int) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OptionPicker("Processador", CPU_MODELS.firstOrNull { it.first == cpu }?.second ?: cpu, CPU_MODELS, onCpu)
        OptionPicker("Placa de vídeo", VIDEO_CARDS.firstOrNull { it.first == card }?.second ?: card, VIDEO_CARDS, onCard)
        OptionPicker("Memória de vídeo", "$vram MB", VRAM_OPTIONS.map { it to "$it MB" }, onVram)
        ResolutionPicker(resW, resH, onRes)
    }
}
