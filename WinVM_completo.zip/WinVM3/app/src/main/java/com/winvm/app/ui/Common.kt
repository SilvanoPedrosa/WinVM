package com.winvm.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/** 0 x 0 = automática. */
val RESOLUTIONS = listOf(
    0 to 0, 640 to 480, 800 to 600, 1024 to 768, 1280 to 720,
    1280 to 800, 1366 to 768, 1600 to 900, 1920 to 1080
)

/** Modelos de CPU do QEMU (identificam a VM como Intel ou AMD). */
val CPU_MODELS = listOf(
    "max" to "Automática (mais compatível)",
    "Nehalem" to "Intel Nehalem (clássico)",
    "Haswell-noTSX" to "Intel Haswell (moderno)",
    "phenom" to "AMD Phenom (clássico)",
    "EPYC" to "AMD EPYC (moderno)"
)

val VIDEO_CARDS = listOf(
    "std" to "VGA padrão (recomendada)",
    "vmware" to "VMware SVGA",
    "cirrus" to "Cirrus Logic (antiga: Win 9x/XP)"
)

val VRAM_OPTIONS = listOf(16, 32, 64, 128, 256)

val NET_MODELS = listOf(
    "e1000" to "Intel e1000 (recomendada)",
    "rtl8139" to "Realtek RTL8139 (Windows XP / ReactOS)",
    "pcnet" to "AMD PCnet (Windows 9x)",
    "virtio-net-pci" to "VirtIO (Linux / Windows com drivers)",
    "none" to "Sem internet"
)

val AUDIO_CARDS = listOf(
    "none" to "Sem som",
    "hda" to "Intel HD Audio (Windows 7+ / Linux)",
    "ac97" to "AC97 (ReactOS / Linux)",
    "sb16" to "Sound Blaster 16 (Windows 9x / XP)"
)

fun resolutionLabel(w: Int, h: Int): String =
    if (w <= 0 || h <= 0) "Automática (o sistema escolhe)" else "$w x $h"

// ---------------------------------------------------------------- componentes de visual

/** Campo arredondado "rótulo + valor" que abre uma ação (lista, seletor de arquivo...). */
@Composable
fun PickerField(
    title: String,
    value: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    trailing: (@Composable () -> Unit)? = null
) {
    Row(
        modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .background(MaterialTheme.colorScheme.surfaceContainerHigh)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                title,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(value, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
        }
        if (trailing != null) {
            trailing()
        } else {
            Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun <T> OptionPicker(
    title: String,
    selectedLabel: String,
    options: List<Pair<T, String>>,
    onPick: (T) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    Box {
        PickerField(title = title, value = selectedLabel, onClick = { open = true })
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { (value, label) ->
                DropdownMenuItem(
                    text = { Text(label) },
                    onClick = { onPick(value); open = false }
                )
            }
        }
    }
}

@Composable
fun ResolutionPicker(width: Int, height: Int, onPick: (Int, Int) -> Unit) {
    OptionPicker(
        title = "Resolução",
        selectedLabel = resolutionLabel(width, height),
        options = RESOLUTIONS.map { it to resolutionLabel(it.first, it.second) },
        onPick = { onPick(it.first, it.second) }
    )
}

/** Cartão de seção com título (organiza as telas em blocos). */
@Composable
fun SectionCard(
    title: String,
    subtitle: String? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Column {
                Text(title, style = MaterialTheme.typography.titleMedium)
                if (subtitle != null) {
                    Text(
                        subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            content()
        }
    }
}

/** Rótulo em forma de pílula. */
@Composable
fun Pill(
    text: String,
    container: Color = MaterialTheme.colorScheme.secondaryContainer,
    content: Color = MaterialTheme.colorScheme.onSecondaryContainer
) {
    Box(
        Modifier
            .clip(CircleShape)
            .background(container)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(text, style = MaterialTheme.typography.labelMedium, color = content)
    }
}

@Composable
fun GroupTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 4.dp, start = 4.dp)
    )
}

/** Processador, placa de vídeo, memória de vídeo, resolução, internet e som. */
@Composable
fun HardwarePickers(
    cpu: String, onCpu: (String) -> Unit,
    card: String, onCard: (String) -> Unit,
    vram: Int, onVram: (Int) -> Unit,
    net: String, onNet: (String) -> Unit,
    audio: String, onAudio: (String) -> Unit,
    resW: Int, resH: Int, onRes: (Int, Int) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        GroupTitle("Processador e vídeo")
        OptionPicker("Processador", CPU_MODELS.firstOrNull { it.first == cpu }?.second ?: cpu, CPU_MODELS, onCpu)
        OptionPicker("Placa de vídeo", VIDEO_CARDS.firstOrNull { it.first == card }?.second ?: card, VIDEO_CARDS, onCard)
        OptionPicker("Memória de vídeo", "$vram MB", VRAM_OPTIONS.map { it to "$it MB" }, onVram)
        ResolutionPicker(resW, resH, onRes)
        GroupTitle("Rede e som")
        OptionPicker("Internet", NET_MODELS.firstOrNull { it.first == net }?.second ?: net, NET_MODELS, onNet)
        OptionPicker("Som", AUDIO_CARDS.firstOrNull { it.first == audio }?.second ?: audio, AUDIO_CARDS, onAudio)
    }
}
