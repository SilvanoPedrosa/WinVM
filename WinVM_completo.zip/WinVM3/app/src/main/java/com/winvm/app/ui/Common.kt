package com.winvm.app.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier

/** 0 x 0 = automática. */
val RESOLUTIONS = listOf(
    0 to 0, 640 to 480, 800 to 600, 1024 to 768, 1280 to 720,
    1280 to 800, 1366 to 768, 1600 to 900, 1920 to 1080
)

fun resolutionLabel(w: Int, h: Int): String =
    if (w <= 0 || h <= 0) "Automática (o sistema escolhe)" else "$w x $h"

@Composable
fun ResolutionPicker(width: Int, height: Int, onPick: (Int, Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            Text("Resolução: ${resolutionLabel(width, height)}")
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            RESOLUTIONS.forEach { (w, h) ->
                DropdownMenuItem(
                    text = { Text(resolutionLabel(w, h)) },
                    onClick = { onPick(w, h); open = false }
                )
            }
        }
    }
}
