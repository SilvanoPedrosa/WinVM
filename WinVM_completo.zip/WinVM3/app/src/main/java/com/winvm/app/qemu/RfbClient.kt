package com.winvm.app.qemu

import android.graphics.Bitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.Socket
import java.util.concurrent.Executors

/** Cliente VNC (RFB 3.8) mínimo: sem autenticação, encodings Raw + DesktopSize. */
class RfbClient(private val port: Int) {
    private var socket: Socket? = null
    private lateinit var inp: DataInputStream
    private lateinit var out: DataOutputStream
    private val writer = Executors.newSingleThreadExecutor()
    private val lock = Any()
    private var everConnected = false

    @Volatile lateinit var bitmap: Bitmap
    val ready = MutableStateFlow(false)
    val frame = MutableStateFlow(0)
    @Volatile var lastX = 0
    @Volatile var lastY = 0

    private fun post(block: () -> Unit) {
        writer.execute {
            runCatching { synchronized(lock) { block(); out.flush() } }
        }
    }

    suspend fun connectWithRetry(tries: Int = 40) {
        repeat(tries) {
            try { connect(); return } catch (e: IOException) {
                if (everConnected) throw e
                delay(1000)
            }
        }
        throw IOException("VNC não respondeu. Veja qemu.log da VM.")
    }

    private suspend fun connect() = withContext(Dispatchers.IO) {
        val s = Socket("127.0.0.1", port).also { it.tcpNoDelay = true }
        socket = s
        inp = DataInputStream(s.getInputStream().buffered())
        out = DataOutputStream(s.getOutputStream().buffered())

        inp.readFully(ByteArray(12))                              // versão do servidor
        out.write("RFB 003.008\n".toByteArray()); out.flush()
        val n = inp.readUnsignedByte()
        if (n == 0) throw IOException("Servidor recusou a conexão")
        inp.readFully(ByteArray(n))                               // tipos de segurança
        out.writeByte(1); out.flush()                             // None
        if (inp.readInt() != 0) throw IOException("Falha de segurança")
        out.writeByte(1); out.flush()                             // ClientInit (shared)
        val w = inp.readUnsignedShort(); val h = inp.readUnsignedShort()
        inp.readFully(ByteArray(16))                              // pixel format do servidor
        inp.readFully(ByteArray(inp.readInt()))                   // nome do desktop
        bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)

        // SetPixelFormat: 32bpp, little-endian, RGB shifts 16/8/0
        out.write(byteArrayOf(0, 0, 0, 0, 32, 24, 0, 1))
        out.writeShort(255); out.writeShort(255); out.writeShort(255)
        out.write(byteArrayOf(16, 8, 0, 0, 0, 0))
        // SetEncodings: Raw (0) + DesktopSize (-223)
        out.write(byteArrayOf(2, 0, 0, 2)); out.writeInt(0); out.writeInt(-223)
        out.flush()

        everConnected = true
        ready.value = true
        post { requestUpdate(false) }
        readLoop()
    }

    private fun requestUpdate(incremental: Boolean) {
        out.writeByte(3); out.writeByte(if (incremental) 1 else 0)
        out.writeShort(0); out.writeShort(0)
        out.writeShort(bitmap.width); out.writeShort(bitmap.height)
    }

    private fun readLoop() {
        while (true) {
            when (inp.readUnsignedByte()) {
                0 -> {                                            // FramebufferUpdate
                    inp.readByte()
                    var resized = false
                    repeat(inp.readUnsignedShort()) {
                        val x = inp.readUnsignedShort(); val y = inp.readUnsignedShort()
                        val w = inp.readUnsignedShort(); val h = inp.readUnsignedShort()
                        when (inp.readInt()) {
                            0 -> {
                                val buf = ByteArray(w * h * 4); inp.readFully(buf)
                                val px = IntArray(w * h) { i ->
                                    0xFF000000.toInt() or
                                        ((buf[i * 4 + 2].toInt() and 255) shl 16) or
                                        ((buf[i * 4 + 1].toInt() and 255) shl 8) or
                                        (buf[i * 4].toInt() and 255)
                                }
                                if (x + w <= bitmap.width && y + h <= bitmap.height)
                                    bitmap.setPixels(px, 0, w, x, y, w, h)
                            }
                            -223 -> {
                                bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                                resized = true
                            }
                            else -> throw IOException("Encoding não suportado")
                        }
                    }
                    frame.value = frame.value + 1
                    post { requestUpdate(!resized) }
                }
                1 -> throw IOException("Mapa de cores não suportado")
                2 -> {}                                           // bell
                3 -> {                                            // ServerCutText
                    inp.readFully(ByteArray(3))
                    inp.readFully(ByteArray(inp.readInt()))
                }
                else -> throw IOException("Mensagem RFB desconhecida")
            }
        }
    }

    /** buttons: 1 = esquerdo, 2 = meio, 4 = direito, 0 = soltar */
    fun pointer(x: Int, y: Int, buttons: Int) {
        lastX = x; lastY = y
        post {
            out.writeByte(5); out.writeByte(buttons)
            out.writeShort(x); out.writeShort(y)
        }
    }

    fun key(keysym: Int, down: Boolean) = post {
        out.writeByte(4); out.writeByte(if (down) 1 else 0)
        out.writeShort(0); out.writeInt(keysym)
    }

    fun close() {
        ready.value = false
        runCatching { socket?.close() }
        writer.shutdownNow()
    }
}
