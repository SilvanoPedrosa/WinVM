package com.winvm.app.qemu

import android.graphics.Bitmap
import android.os.SystemClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.Socket
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Cliente VNC (RFB 3.8) mínimo: sem autenticação, encodings Raw + DesktopSize. */
class RfbClient(private val port: Int) {
    private var socket: Socket? = null
    private lateinit var inp: DataInputStream
    private lateinit var out: DataOutputStream
    private val writer = Executors.newSingleThreadExecutor()
    private val updater = Executors.newSingleThreadScheduledExecutor()
    private var lastRequestAt = 0L
    private val minFrameMs = 40L          // ~25 quadros/s: sobra CPU para a VM
    private val lock = Any()
    private var everConnected = false
    private var rawBuf = ByteArray(0)
    private var px = IntArray(0)

    @Volatile lateinit var bitmap: Bitmap
    val ready = MutableStateFlow(false)
    val frame = MutableStateFlow(0)
    @Volatile var lastX = 0
    @Volatile var lastY = 0

    private fun post(block: () -> Unit) {
        writer.execute {
            runCatching { synchronized(lock) { block(); out.flush() } }
        }
    }

    suspend fun connectWithRetry(tries: Int = 160) {
        repeat(tries) {
            try { connect(); return } catch (e: IOException) {
                if (everConnected) throw e
                delay(250)
            }
        }
        throw IOException("VNC não respondeu. Veja qemu.log da VM.")
    }

    private suspend fun connect() = withContext(Dispatchers.IO) {
        val s = Socket("127.0.0.1", port).also { it.tcpNoDelay = true }
        socket = s
        inp = DataInputStream(s.getInputStream().buffered())
        out = DataOutputStream(s.getOutputStream().buffered())

        inp.readFully(ByteArray(12))                              // versão do servidor
        out.write("RFB 003.008\n".toByteArray()); out.flush()
        val n = inp.readUnsignedByte()
        if (n == 0) throw IOException("Servidor recusou a conexão")
        inp.readFully(ByteArray(n))                               // tipos de segurança
        out.writeByte(1); out.flush()                             // None
        if (inp.readInt() != 0) throw IOException("Falha de segurança")
        out.writeByte(1); out.flush()                             // ClientInit (shared)
        val w = inp.readUnsignedShort(); val h = inp.readUnsignedShort()
        inp.readFully(ByteArray(16))                              // pixel format do servidor
        inp.readFully(ByteArray(inp.readInt()))                   // nome do desktop
        bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)

        // SetPixelFormat: 32bpp, little-endian, RGB shifts 16/8/0
        out.write(byteArrayOf(0, 0, 0, 0, 32, 24, 0, 1))
        out.writeShort(255); out.writeShort(255); out.writeShort(255)
        out.write(byteArrayOf(16, 8, 0, 0, 0, 0))
        // SetEncodings: Raw (0) + DesktopSize (-223)
        out.write(byteArrayOf(2, 0, 0, 2)); out.writeInt(0); out.writeInt(-223)
        out.flush()

        everConnected = true
        ready.value = true
        post { requestUpdate(false) }
        readLoop()
    }

    private fun requestUpdate(incremental: Boolean) {
        out.writeByte(3); out.writeByte(if (incremental) 1 else 0)
        out.writeShort(0); out.writeShort(0)
        out.writeShort(bitmap.width); out.writeShort(bitmap.height)
    }

    private fun readLoop() {
        while (true) {
            when (inp.readUnsignedByte()) {
                0 -> {                                            // FramebufferUpdate
                    inp.readByte()
                    var resized = false
                    repeat(inp.readUnsignedShort()) {
                        val x = inp.readUnsignedShort(); val y = inp.readUnsignedShort()
                        val w = inp.readUnsignedShort(); val h = inp.readUnsignedShort()
                        when (inp.readInt()) {
                            0 -> {
                                // leitura em bloco + conversão em massa (sem laço byte a byte)
                                val n = w * h
                                if (rawBuf.size < n * 4) rawBuf = ByteArray(n * 4)
                                inp.readFully(rawBuf, 0, n * 4)
                                if (px.size < n) px = IntArray(n)
                                ByteBuffer.wrap(rawBuf, 0, n * 4).order(ByteOrder.LITTLE_ENDIAN)
                                    .asIntBuffer().get(px, 0, n)
                                for (i in 0 until n) px[i] = px[i] or -0x1000000   // alpha = 255
                                if (x + w <= bitmap.width && y + h <= bitmap.height)
                                    bitmap.setPixels(px, 0, w, x, y, w, h)
                            }
                            -223 -> {
                                bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                                resized = true
                            }
                            else -> throw IOException("Encoding não suportado")
                        }
                    }
                    frame.value = frame.value + 1
                    // pede o próximo quadro no máximo ~25 vezes por segundo
                    val now = SystemClock.uptimeMillis()
                    val wait = maxOf(0L, minFrameMs - (now - lastRequestAt))
                    lastRequestAt = now + wait
                    runCatching {
                        updater.schedule(Runnable { post { requestUpdate(!resized) } }, wait, TimeUnit.MILLISECONDS)
                    }
                }
                1 -> throw IOException("Mapa de cores não suportado")
                2 -> {}                                           // bell
                3 -> {                                            // ServerCutText
                    inp.readFully(ByteArray(3))
                    inp.readFully(ByteArray(inp.readInt()))
                }
                else -> throw IOException("Mensagem RFB desconhecida")
            }
        }
    }

    /** buttons: 1 = esquerdo, 2 = meio, 4 = direito, 0 = soltar */
    fun pointer(x: Int, y: Int, buttons: Int) {
        lastX = x; lastY = y
        post {
            out.writeByte(5); out.writeByte(buttons)
            out.writeShort(x); out.writeShort(y)
        }
    }

    fun key(keysym: Int, down: Boolean) = post {
        out.writeByte(4); out.writeByte(if (down) 1 else 0)
        out.writeShort(0); out.writeInt(keysym)
    }

    fun close() {
        ready.value = false
        runCatching { socket?.close() }
        writer.shutdownNow()
        updater.shutdownNow()
    }
}
