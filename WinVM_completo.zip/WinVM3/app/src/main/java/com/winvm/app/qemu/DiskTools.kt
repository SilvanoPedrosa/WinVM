package com.winvm.app.qemu

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.io.IOException

/** Utilitários para trazer arquivos de disco/ISO para dentro da pasta da VM. */
object DiskTools {
    fun displayName(ctx: Context, uri: Uri): String {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0) ?: "arquivo"
        }
        return uri.lastPathSegment ?: "arquivo"
    }

    fun extOf(name: String): String =
        name.substringAfterLast('.', "").lowercase().filter { it.isLetterOrDigit() }.take(6).ifEmpty { "img" }

    /** Copia o arquivo escolhido para dentro do app. onBytes é chamado a cada MB copiado. */
    fun copy(ctx: Context, uri: Uri, dest: File, onBytes: (Long) -> Unit) {
        val input = ctx.contentResolver.openInputStream(uri) ?: throw IOException("Não consegui abrir o arquivo")
        input.use { i ->
            dest.outputStream().use { o ->
                val buf = ByteArray(1 shl 20)
                var total = 0L
                var lastMb = -1L
                while (true) {
                    val r = i.read(buf)
                    if (r < 0) break
                    o.write(buf, 0, r)
                    total += r
                    val mb = total / (1024L * 1024L)
                    if (mb != lastMb) { lastMb = mb; onBytes(total) }
                }
            }
        }
    }

    /** Pergunta ao qemu-img qual é o formato (qcow2, vpc = VHD, vhdx, vmdk, vdi, raw). */
    suspend fun detectFormat(ctx: Context, dir: File, f: File): String {
        val out = StringBuilder()
        Rootfs.runGuest(ctx, listOf("qemu-img", "info", "/vm/${f.name}"), dir) { out.appendLine(it) }
        val fmt = Regex("file format:\\s*(\\S+)").find(out.toString())?.groupValues?.get(1)
        val ext = f.extension.lowercase()
        return when {
            fmt == null -> when (ext) {
                "qcow2" -> "qcow2"; "vhd" -> "vpc"; "vhdx" -> "vhdx"; "vmdk" -> "vmdk"; "vdi" -> "vdi"
                else -> "raw"
            }
            fmt == "raw" && ext == "vhd" -> "vpc"      // VHD de tamanho fixo costuma ser lido como raw
            else -> fmt
        }
    }

    fun sizeLabel(bytes: Long): String =
        if (bytes >= 1L shl 30) "%.1f GB".format(bytes / (1024.0 * 1024.0 * 1024.0))
        else "${bytes / (1024L * 1024L)} MB"
}
