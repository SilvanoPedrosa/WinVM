package com.winvm.app.ui

import android.app.Application
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateMap
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.winvm.app.model.VmConfig
import com.winvm.app.model.VmRepository
import com.winvm.app.model.VmState
import com.winvm.app.qemu.QemuService
import com.winvm.app.qemu.QmpClient
import com.winvm.app.qemu.Rootfs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class HomeViewModel(private val app: Application) : AndroidViewModel(app) {
    var vms by mutableStateOf(VmRepository.list(app))
        private set
    var envReady by mutableStateOf(Rootfs.isReady(app))
        private set
    val states: SnapshotStateMap<String, VmState> = mutableStateMapOf()
    private val startedAt = HashMap<String, Long>()

    init {
        viewModelScope.launch {
            while (true) { sync(); delay(3000) }
        }
    }

    fun refresh() {
        vms = VmRepository.list(app)
        envReady = Rootfs.isReady(app)
    }

    private suspend fun sync() {
        for (c in vms) {
            val st = QmpClient(c.qmpPort).status()
            val cur = states[c.name]
            val recentlyStarted = System.currentTimeMillis() - (startedAt[c.name] ?: 0L) < 90_000
            states[c.name] = when {
                st != null -> st
                cur == VmState.STARTING && recentlyStarted -> VmState.STARTING
                else -> VmState.STOPPED
            }
        }
    }

    fun start(c: VmConfig) {
        startedAt[c.name] = System.currentTimeMillis()
        states[c.name] = VmState.STARTING
        QemuService.start(app, c)
    }

    fun pause(c: VmConfig) = qmp(c, "stop", VmState.PAUSED)
    fun resume(c: VmConfig) = qmp(c, "cont", VmState.RUNNING)
    fun shutdown(c: VmConfig) = qmp(c, "system_powerdown", null)
    fun forceStop(c: VmConfig) = qmp(c, "quit", VmState.STOPPED)

    private fun qmp(c: VmConfig, cmd: String, next: VmState?) {
        viewModelScope.launch {
            runCatching { QmpClient(c.qmpPort).send(cmd) }
                .onSuccess { if (next != null) states[c.name] = next }
        }
    }

    fun delete(c: VmConfig) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { VmRepository.delete(app, c) }
            states.remove(c.name)
            refresh()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    vm: HomeViewModel = viewModel(),
    onCreate: () -> Unit,
    onSetup: () -> Unit,
    onOpenDisplay: (VmConfig) -> Unit
) {
    var toDelete by remember { mutableStateOf<VmConfig?>(null) }
    LaunchedEffect(Unit) { vm.refresh() }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Minhas VMs") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = onCreate) { Icon(Icons.Default.Add, "Nova VM") }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (!vm.envReady) {
                Card(Modifier.fillMaxWidth().padding(16.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Ambiente Linux (Alpine + QEMU) não instalado.")
                        Button(onClick = onSetup, modifier = Modifier.padding(top = 8.dp)) {
                            Text("Instalar agora")
                        }
                    }
                }
            }
            if (vm.vms.isEmpty()) {
                Box(Modifier.fillMaxSize(), Alignment.Center) {
                    Text("Nenhuma VM. Toque em + para criar.")
                }
            } else LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(vm.vms, key = { it.name }) { c ->
                    val st = vm.states[c.name] ?: VmState.STOPPED
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text(c.name, style = MaterialTheme.typography.titleMedium)
                            Text(
                                "${c.cpus} CPUs • ${c.ramMb} MB • " + when (st) {
                                    VmState.STOPPED -> "Parada"
                                    VmState.STARTING -> "Iniciando…"
                                    VmState.RUNNING -> "Em execução"
                                    VmState.PAUSED -> "Pausada"
                                },
                                style = MaterialTheme.typography.bodySmall
                            )
                            Row(
                                Modifier.padding(top = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                when (st) {
                                    VmState.STOPPED -> {
                                        Button(
                                            onClick = { vm.start(c); onOpenDisplay(c) },
                                            enabled = vm.envReady
                                        ) { Text("Iniciar") }
                                        TextButton(onClick = { toDelete = c }) { Text("Excluir") }
                                    }
                                    VmState.STARTING -> {
                                        Button(onClick = { onOpenDisplay(c) }) { Text("Abrir") }
                                        TextButton(onClick = { vm.forceStop(c) }) { Text("Forçar") }
                                    }
                                    VmState.RUNNING -> {
                                        Button(onClick = { onOpenDisplay(c) }) { Text("Abrir") }
                                        OutlinedButton(onClick = { vm.pause(c) }) { Text("Pausar") }
                                        TextButton(onClick = { vm.shutdown(c) }) { Text("Desligar") }
                                    }
                                    VmState.PAUSED -> {
                                        Button(onClick = { vm.resume(c) }) { Text("Continuar") }
                                        TextButton(onClick = { vm.forceStop(c) }) { Text("Forçar") }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    toDelete?.let { c ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Excluir ${c.name}?") },
            text = { Text("O disco virtual e a ISO copiada serão apagados.") },
            confirmButton = { TextButton(onClick = { vm.delete(c); toDelete = null }) { Text("Excluir") } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancelar") } }
        )
    }
}
