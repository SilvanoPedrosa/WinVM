package com.winvm.app.ui

import android.app.Application
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Stop
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import com.winvm.app.R
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateMap
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.winvm.app.model.DiskRef
import com.winvm.app.model.VmConfig
import com.winvm.app.model.VmRepository
import com.winvm.app.model.VmState
import com.winvm.app.qemu.DiskTools
import com.winvm.app.qemu.QemuCommandBuilder
import com.winvm.app.qemu.QemuService
import com.winvm.app.qemu.QmpClient
import com.winvm.app.qemu.Rootfs
import com.winvm.app.qemu.RootfsWarmup
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

class HomeViewModel(private val app: Application) : AndroidViewModel(app) {
    var vms by mutableStateOf(VmRepository.list(app))
        private set
    var envReady by mutableStateOf(Rootfs.isReady(app))
        private set
    val states: SnapshotStateMap<String, VmState> = mutableStateMapOf()
    val notes: SnapshotStateMap<String, String> = mutableStateMapOf()
    val hibernating = mutableStateListOf<String>()
    private val startedAt = HashMap<String, Long>()

    init {
        RootfsWarmup.start(app)                            // deixa o QEMU no cache de memória antes de iniciar a VM
        viewModelScope.launch {
            while (true) {
                sync()
                // enquanto uma VM está iniciando, confere a cada 0,7 s: "Em execução" aparece assim que o QEMU responde
                delay(if (states.values.any { it == VmState.STARTING }) 700L else 3000L)
            }
        }
    }

    fun refresh() {
        vms = VmRepository.list(app)
        envReady = Rootfs.isReady(app)
    }

    private fun vmDir(c: VmConfig) = File(VmRepository.root(app), c.name)

    private suspend fun sync() {
        for (c in vms) {
            if (c.name in hibernating) continue            // salvando estado: o QMP fica ocupado
            val st = QmpClient(c.qmpPort).status()
            val cur = states[c.name]
            val recentlyStarted = System.currentTimeMillis() - (startedAt[c.name] ?: 0L) < 90_000
            states[c.name] = when {
                st != null -> st
                cur == VmState.STARTING && recentlyStarted -> VmState.STARTING
                else -> VmState.STOPPED
            }
        }
    }

    fun start(c: VmConfig) {
        notes.remove(c.name)
        startedAt[c.name] = System.currentTimeMillis()
        states[c.name] = VmState.STARTING
        QemuService.start(app, c)
    }

    fun pause(c: VmConfig) = qmp(c, "stop", VmState.PAUSED)
    fun resume(c: VmConfig) = qmp(c, "cont", VmState.RUNNING)
    fun shutdown(c: VmConfig) {
        // Início rápido: o botão desligar hiberna (salva a VM); no próximo início ela volta em segundos
        if (c.quickStart && c.canHibernate) hibernate(c) else qmp(c, "system_powerdown", null)
    }

    /** Há um estado salvo compatível com esta versão do app? (o próximo início será uma retomada rápida) */
    fun isHibernated(c: VmConfig): Boolean {
        val f = File(vmDir(c), "hibernated")
        return f.exists() && runCatching { f.readText().trim() }.getOrNull() == QemuCommandBuilder.HIB_VERSION
    }
    fun forceStop(c: VmConfig) = qmp(c, "quit", VmState.STOPPED)

    private fun qmp(c: VmConfig, cmd: String, next: VmState?) {
        viewModelScope.launch {
            runCatching { QmpClient(c.qmpPort).send(cmd) }
                .onSuccess { if (next != null) states[c.name] = next }
        }
    }

    /** Salva a RAM e o disco num ponto (savevm) e fecha; no próximo início a VM volta em segundos. */
    fun hibernate(c: VmConfig) {
        if (c.name in hibernating) return
        if (!c.canHibernate) {
            notes[c.name] = "Para hibernar, o disco principal e os HDs extras precisam ser qcow2."
            return
        }
        hibernating.add(c.name)
        notes[c.name] = "Hibernando… (pode levar de 10 s a alguns minutos)"
        viewModelScope.launch {
            val r = runCatching {
                QmpClient(c.qmpPort).execute(
                    "human-monitor-command",
                    JSONObject().put("command-line", "savevm hib"),
                    600_000
                )
            }.getOrNull()
            val err = r?.optJSONObject("error")?.optString("desc")
            val out = r?.optString("return").orEmpty()
            if (r != null && err == null && out.isBlank()) {
                withContext(Dispatchers.IO) { File(vmDir(c), "hibernated").writeText(QemuCommandBuilder.HIB_VERSION) }
                runCatching { QmpClient(c.qmpPort).send("quit") }
                states[c.name] = VmState.STOPPED
                notes[c.name] = "Hibernada. Ao iniciar, volta de onde parou."
            } else {
                notes[c.name] = "Não foi possível hibernar: " + (err ?: out.ifBlank { "sem resposta" })
            }
            hibernating.remove(c.name)
        }
    }

    /** Texto de progresso enquanto copia um arquivo para dentro do app (null = nada em andamento). */
    var copying by mutableStateOf<String?>(null)

    private fun cfgOf(name: String) = vms.firstOrNull { it.name == name }

    private fun saveStorage(name: String, change: (VmConfig) -> VmConfig) {
        val cur = cfgOf(name) ?: return
        VmRepository.save(app, change(cur))
        File(vmDir(cur), "hibernated").delete()            // armazenamento mudou: estado salvo não vale mais
        refresh()
    }

    /** Troca o CD/DVD (ISO). uri = null remove. */
    fun setIso(name: String, uri: Uri?) {
        val c = cfgOf(name) ?: return
        viewModelScope.launch {
            copying = "Copiando ISO…"
            try {
                val newPath: String? = withContext(Dispatchers.IO) {
                    if (uri == null) {
                        c.isoPath?.let { File(it).delete() }
                        null
                    } else {
                        val dest = File(vmDir(c), "boot.iso")
                        DiskTools.copy(app, uri, dest) { b -> copying = "Copiando ISO… ${b / (1024L * 1024L)} MB" }
                        dest.path
                    }
                }
                saveStorage(name) { it.copy(isoPath = newPath) }
                notes[name] = if (newPath == null) "CD/DVD removido." else "ISO trocada. Vale na próxima vez que a VM iniciar."
            } catch (e: Exception) {
                notes[name] = "Falha ao trocar a ISO: ${e.message}"
            } finally {
                copying = null
            }
        }
    }

    /** Adiciona um disco (qcow2, vhd, vhdx, vmdk, vdi, img) como HD extra da VM. */
    fun addExtraDisk(name: String, uri: Uri) {
        val c = cfgOf(name) ?: return
        if (c.extraDisks.size >= 2) {
            notes[name] = "Máximo de 2 HDs extras."
            return
        }
        viewModelScope.launch {
            copying = "Copiando disco…"
            try {
                val ref = withContext(Dispatchers.IO) {
                    val dir = vmDir(c)
                    val dest = File(dir, "extra_${System.currentTimeMillis()}.${DiskTools.extOf(DiskTools.displayName(app, uri))}")
                    DiskTools.copy(app, uri, dest) { b -> copying = "Copiando disco… ${b / (1024L * 1024L)} MB" }
                    DiskRef(dest.path, DiskTools.detectFormat(app, dir, dest))
                }
                saveStorage(name) { it.copy(extraDisks = (it.extraDisks + ref).take(2)) }
                notes[name] = "HD extra adicionado (${ref.format}). Vale na próxima vez que a VM iniciar. " +
                    "Se ele não aparecer no Windows, é porque o disco novo ainda não tem partição: " +
                    "abra Gerenciamento de Disco (diskmgmt.msc), inicialize o disco e crie um volume NTFS."
            } catch (e: Exception) {
                notes[name] = "Falha ao adicionar o disco: ${e.message}"
            } finally {
                copying = null
            }
        }
    }

    fun removeExtraDisk(name: String, disk: DiskRef) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { File(disk.path).delete() }
            saveStorage(name) { it.copy(extraDisks = it.extraDisks.filter { d -> d.path != disk.path }) }
            notes[name] = "HD extra removido."
        }
    }

    fun setHardware(
        c: VmConfig, cpu: String, card: String, vram: Int, w: Int, h: Int, audio: String,
        turbo: Boolean, cpuTurbo: Boolean, quick: Boolean, ram: Int
    ) {
        VmRepository.save(app, c.copy(
            ramMb = ram, cpuModel = cpu, videoCard = card, vramMb = vram, width = w, height = h,
            audioCard = audio, diskTurbo = turbo, cpuTurbo = cpuTurbo, quickStart = quick
        ))
        File(vmDir(c), "hibernated").delete()              // hardware mudou: o estado salvo não vale mais
        refresh()
    }

    fun delete(c: VmConfig) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { VmRepository.delete(app, c) }
            states.remove(c.name)
            refresh()
        }
    }
}

@Composable
private fun HomeHeader() {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Column {
            Text("WinVM", style = MaterialTheme.typography.headlineSmall)
            Text(
                "Suas máquinas virtuais",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun SetupBanner(onSetup: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer,
            contentColor = MaterialTheme.colorScheme.onPrimaryContainer
        )
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Falta instalar o ambiente Linux", style = MaterialTheme.typography.titleMedium)
            Text(
                "O app usa um Alpine Linux com QEMU dentro dele. A instalação é feita uma vez (cerca de 100 MB).",
                style = MaterialTheme.typography.bodyMedium
            )
            Button(onClick = onSetup) { Text("Instalar agora") }
        }
    }
}

@Composable
private fun EmptyState() {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier.size(96.dp).clip(RoundedCornerShape(32.dp)).background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Default.Add,
                contentDescription = null,
                modifier = Modifier.size(44.dp),
                tint = MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
        Text(
            "Nenhuma VM ainda",
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(top = 20.dp)
        )
        Text(
            "Toque no + para criar sua primeira máquina virtual.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}

private fun specChips(c: VmConfig, resumable: Boolean): List<String> = buildList {
    if (resumable) add("Retomada rápida")
    add("${c.vcpus} CPU")
    if (c.cpuTurbo) add("CPU turbo")
    add("${c.ramMb} MB")
    val card = VIDEO_CARDS.firstOrNull { it.first == c.videoCard }?.second?.substringBefore(" (") ?: c.videoCard
    add("$card ${c.vramMb} MB")
    if (c.width > 0 && c.height > 0) add("${c.width}x${c.height}")
    add(if (c.netModel == "none") "Sem internet" else "Internet")
    if (c.audioCard != "none") add("Som")
    if (c.extraDisks.isNotEmpty()) add("${c.extraDisks.size} HD extra")
}

private enum class ActionKind { PRIMARY, TONAL, DANGER }

/** Botão redondo só com ícone (o texto fica como descrição para leitores de tela). */
@Composable
private fun ActionIcon(
    icon: ImageVector,
    description: String,
    kind: ActionKind,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val size = Modifier.size(42.dp)
    val glyph: @Composable () -> Unit = {
        Icon(icon, contentDescription = description, modifier = Modifier.size(22.dp))
    }
    when (kind) {
        ActionKind.PRIMARY -> FilledIconButton(onClick = onClick, modifier = size, enabled = enabled, content = glyph)
        ActionKind.TONAL -> FilledTonalIconButton(onClick = onClick, modifier = size, enabled = enabled, content = glyph)
        ActionKind.DANGER -> FilledTonalIconButton(
            onClick = onClick,
            modifier = size,
            enabled = enabled,
            colors = IconButtonDefaults.filledTonalIconButtonColors(
                containerColor = MaterialTheme.colorScheme.errorContainer,
                contentColor = MaterialTheme.colorScheme.onErrorContainer
            ),
            content = glyph
        )
    }
}

@Composable
private fun VmCard(
    c: VmConfig,
    vm: HomeViewModel,
    onOpen: () -> Unit,
    onConfigure: () -> Unit,
    onDelete: () -> Unit
) {
    val st = vm.states[c.name] ?: VmState.STOPPED
    val saving = c.name in vm.hibernating
    val (statusText, statusColor) = when {
        saving -> "Hibernando…" to MaterialTheme.colorScheme.tertiary
        st == VmState.STOPPED -> "Parada" to MaterialTheme.colorScheme.onSurfaceVariant
        st == VmState.STARTING -> "Iniciando…" to Color(0xFFD99A00)
        st == VmState.RUNNING -> "Em execução" to Color(0xFF2E9E5B)
        else -> "Pausada" to MaterialTheme.colorScheme.primary
    }

    Card(
        Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Box(
                    Modifier.size(48.dp).clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        c.name.take(1).uppercase(),
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
                Column(Modifier.weight(1f)) {
                    Text(
                        c.name,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(statusColor))
                        Text(statusText, style = MaterialTheme.typography.bodySmall, color = statusColor)
                    }
                }
                // Ações: só ícones, no canto direito do cartão (como pedido)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    when {
                        saving -> {}
                        st == VmState.STOPPED -> {
                            ActionIcon(Icons.Default.PlayArrow, "Iniciar", ActionKind.PRIMARY, enabled = vm.envReady) {
                                vm.start(c); onOpen()
                            }
                            ActionIcon(Icons.Default.Settings, "Configurar", ActionKind.TONAL, onClick = onConfigure)
                            ActionIcon(Icons.Default.Delete, "Excluir", ActionKind.DANGER, onClick = onDelete)
                        }
                        st == VmState.STARTING -> {
                            ActionIcon(Icons.Default.Fullscreen, "Abrir", ActionKind.PRIMARY, onClick = onOpen)
                            ActionIcon(Icons.Default.Stop, "Forçar parada", ActionKind.DANGER) { vm.forceStop(c) }
                        }
                        st == VmState.RUNNING -> {
                            ActionIcon(Icons.Default.Fullscreen, "Abrir", ActionKind.PRIMARY, onClick = onOpen)
                            ActionIcon(Icons.Default.Pause, "Pausar", ActionKind.TONAL) { vm.pause(c) }
                            val quick = c.quickStart && c.canHibernate
                            if (c.canHibernate && !quick) {
                                ActionIcon(Icons.Default.Bedtime, "Hibernar", ActionKind.TONAL) { vm.hibernate(c) }
                            }
                            ActionIcon(
                                Icons.Default.PowerSettingsNew,
                                if (quick) "Desligar e salvar (início rápido)" else "Desligar",
                                ActionKind.DANGER
                            ) { vm.shutdown(c) }
                        }
                        else -> {
                            ActionIcon(Icons.Default.PlayArrow, "Continuar", ActionKind.PRIMARY) { vm.resume(c) }
                            ActionIcon(Icons.Default.Stop, "Forçar parada", ActionKind.DANGER) { vm.forceStop(c) }
                        }
                    }
                }
            }

            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                specChips(c, vm.isHibernated(c)).forEach { Pill(it) }
            }

            vm.notes[c.name]?.let {
                Box(
                    Modifier.fillMaxWidth().clip(MaterialTheme.shapes.medium)
                        .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                        .padding(12.dp)
                ) {
                    Text(it, style = MaterialTheme.typography.bodySmall)
                }
            }

        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    vm: HomeViewModel = viewModel(),
    onCreate: () -> Unit,
    onSetup: () -> Unit,
    onOpenDisplay: (VmConfig) -> Unit
) {
    val ctx = LocalContext.current
    var toDelete by remember { mutableStateOf<VmConfig?>(null) }
    var toEdit by remember { mutableStateOf<String?>(null) }
    var toRemove by remember { mutableStateOf<Pair<String, DiskRef>?>(null) }
    val isoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val n = toEdit
        if (uri != null && n != null) vm.setIso(n, uri)
    }
    val diskPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val n = toEdit
        if (uri != null && n != null) vm.addExtraDisk(n, uri)
    }
    LaunchedEffect(Unit) { vm.refresh() }

    Scaffold(
        containerColor = Color.Transparent,
        floatingActionButton = {
            FloatingActionButton(
                onClick = onCreate,
                shape = CircleShape,
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ) {
                Icon(Icons.Default.Add, contentDescription = "Nova VM")
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            HomeHeader()
            if (!vm.envReady) SetupBanner(onSetup)
            if (vm.vms.isEmpty()) {
                EmptyState()
            } else LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 340.dp),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, top = 12.dp, end = 16.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(vm.vms, key = { it.name }) { c ->
                    VmCard(
                        c = c,
                        vm = vm,
                        onOpen = { onOpenDisplay(c) },
                        onConfigure = { toEdit = c.name },
                        onDelete = { toDelete = c }
                    )
                }
            }
        }
    }

    toEdit?.let { editName ->
        val c = vm.vms.firstOrNull { it.name == editName }
        if (c != null) {
            var cpu by remember(c.name) { mutableStateOf(c.cpuModel) }
            var w by remember(c.name) { mutableStateOf(c.width) }
            var h by remember(c.name) { mutableStateOf(c.height) }
            var turbo by remember(c.name) { mutableStateOf(c.diskTurbo) }
            var cpuTurbo by remember(c.name) { mutableStateOf(c.cpuTurbo) }
            var quick by remember(c.name) { mutableStateOf(c.quickStart) }
            var ram by remember(c.name) { mutableStateOf(c.ramMb.toFloat()) }
            var card by remember(c.name) { mutableStateOf(c.videoCard) }
            var vram by remember(c.name) { mutableStateOf(c.vramMb) }
            var audio by remember(c.name) { mutableStateOf(c.audioCard) }
            val iso = c.isoPath
            val idle = vm.copying == null
            AlertDialog(
                onDismissRequest = { if (idle) toEdit = null },
                title = { Text("Configurar ${c.name}") },
                text = {
                    Column(
                        Modifier.verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        GroupTitle("Memória e processador")
                        RamPicker(ram) { ram = it }
                        OptionPicker(
                            "Processador",
                            CPU_MODELS.firstOrNull { it.first == cpu }?.second ?: cpu,
                            CPU_MODELS
                        ) { cpu = it }

                        GroupTitle("Vídeo e som")
                        VideoSoundPickers(
                            card = card, onCard = { card = it },
                            vram = vram, onVram = { vram = it },
                            audio = audio, onAudio = { audio = it },
                            resW = w, resH = h, onRes = { nw, nh -> w = nw; h = nh }
                        )

                        GroupTitle("Desempenho")
                        SwitchRow(
                            title = "Disco turbo",
                            subtitle = "A VM inicia e instala bem mais rápido. Risco pequeno de perder dados se o celular desligar de repente.",
                            checked = turbo,
                            onChange = { turbo = it }
                        )
                        SwitchRow(
                            title = "CPU turbo",
                            subtitle = "Usa os núcleos mais rápidos do celular, com no máximo 2 CPUs. A VM abre e roda bem mais rápido.",
                            checked = cpuTurbo,
                            onChange = { cpuTurbo = it }
                        )
                        SwitchRow(
                            title = "Início rápido",
                            subtitle = "Desligar salva o estado da VM e o próximo início volta em segundos. Só com disco qcow2.",
                            checked = quick,
                            onChange = { quick = it }
                        )

                        GroupTitle("Armazenamento (aplicado na hora)")
                        PickerField(
                            title = "CD/DVD",
                            value = if (iso != null) File(iso).name else "Nenhum",
                            onClick = { isoPicker.launch(arrayOf("*/*")) },
                            enabled = idle,
                            trailing = {
                                Text(
                                    if (iso != null) "Trocar" else "Escolher",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        )
                        if (iso != null) {
                            TextButton(
                                onClick = { vm.setIso(c.name, null) },
                                enabled = idle,
                                colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                            ) { Text("Remover CD/DVD") }
                        }
                        c.extraDisks.forEachIndexed { i, d ->
                            PickerField(
                                title = "HD extra ${i + 1}",
                                value = "${d.format} • ${DiskTools.sizeLabel(File(d.path).length())}",
                                onClick = { toRemove = c.name to d },
                                enabled = idle,
                                trailing = {
                                    Text(
                                        "Remover",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                }
                            )
                        }
                        if (c.extraDisks.size < 2) {
                            PickerField(
                                title = "Adicionar HD externo",
                                value = ".qcow2 .vhd .vhdx .vmdk .img",
                                onClick = { diskPicker.launch(arrayOf("*/*")) },
                                enabled = idle,
                                trailing = {
                                    Icon(Icons.Default.Add, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                }
                            )
                        }
                        vm.copying?.let {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                                Text(it)
                            }
                        }

                        Text(
                            "Mudanças de hardware valem no próximo início. Mudar o hardware ou o armazenamento " +
                                "descarta o estado hibernado.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { vm.setHardware(c, cpu, card, vram, w, h, audio, turbo, cpuTurbo, quick, ram.toInt()); toEdit = null },
                        enabled = idle
                    ) { Text("Salvar") }
                },
                dismissButton = { TextButton(onClick = { toEdit = null }, enabled = idle) { Text("Fechar") } }
            )
        }
    }

    toRemove?.let { (vmName, disk) ->
        AlertDialog(
            onDismissRequest = { toRemove = null },
            title = { Text("Remover HD extra?") },
            text = {
                Text(
                    "A cópia dentro do app será apagada, com tudo que a VM gravou nela. " +
                        "O arquivo original no celular não é afetado."
                )
            },
            confirmButton = {
                Button(
                    onClick = { vm.removeExtraDisk(vmName, disk); toRemove = null },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text("Remover") }
            },
            dismissButton = { TextButton(onClick = { toRemove = null }) { Text("Cancelar") } }
        )
    }

    toDelete?.let { c ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Excluir ${c.name}?") },
            text = {
                val outside = !c.diskPath.startsWith(ctx.filesDir.path)
                Text(
                    if (outside) {
                        "A pasta da VM e a ISO copiada serão apagadas. O disco ${File(c.diskPath).name} " +
                            "da pasta Download NÃO é apagado (apague pelo gerenciador de arquivos se quiser)."
                    } else {
                        "O disco virtual e a ISO copiada serão apagados."
                    }
                )
            },
            confirmButton = {
                Button(
                    onClick = { vm.delete(c); toDelete = null },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text("Excluir") }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancelar") } }
        )
    }
}
