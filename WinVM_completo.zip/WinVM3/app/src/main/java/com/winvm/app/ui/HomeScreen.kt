package com.winvm.app.ui

import android.app.Application
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateMap
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.winvm.app.model.DiskRef
import com.winvm.app.model.VmConfig
import com.winvm.app.model.VmRepository
import com.winvm.app.model.VmState
import com.winvm.app.qemu.DiskTools
import com.winvm.app.qemu.QemuService
import com.winvm.app.qemu.QmpClient
import com.winvm.app.qemu.Rootfs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

class HomeViewModel(private val app: Application) : AndroidViewModel(app) {
    var vms by mutableStateOf(VmRepository.list(app))
        private set
    var envReady by mutableStateOf(Rootfs.isReady(app))
        private set
    val states: SnapshotStateMap<String, VmState> = mutableStateMapOf()
    val notes: SnapshotStateMap<String, String> = mutableStateMapOf()
    val hibernating = mutableStateListOf<String>()
    private val startedAt = HashMap<String, Long>()

    init {
        viewModelScope.launch {
            while (true) { sync(); delay(3000) }
        }
    }

    fun refresh() {
        vms = VmRepository.list(app)
        envReady = Rootfs.isReady(app)
    }

    private fun vmDir(c: VmConfig) = File(c.diskPath).parentFile!!

    private suspend fun sync() {
        for (c in vms) {
            if (c.name in hibernating) continue            // salvando estado: o QMP fica ocupado
            val st = QmpClient(c.qmpPort).status()
            val cur = states[c.name]
            val recentlyStarted = System.currentTimeMillis() - (startedAt[c.name] ?: 0L) < 90_000
            states[c.name] = when {
                st != null -> st
                cur == VmState.STARTING && recentlyStarted -> VmState.STARTING
                else -> VmState.STOPPED
            }
        }
    }

    fun start(c: VmConfig) {
        notes.remove(c.name)
        startedAt[c.name] = System.currentTimeMillis()
        states[c.name] = VmState.STARTING
        QemuService.start(app, c)
    }

    fun pause(c: VmConfig) = qmp(c, "stop", VmState.PAUSED)
    fun resume(c: VmConfig) = qmp(c, "cont", VmState.RUNNING)
    fun shutdown(c: VmConfig) = qmp(c, "system_powerdown", null)
    fun forceStop(c: VmConfig) = qmp(c, "quit", VmState.STOPPED)

    private fun qmp(c: VmConfig, cmd: String, next: VmState?) {
        viewModelScope.launch {
            runCatching { QmpClient(c.qmpPort).send(cmd) }
                .onSuccess { if (next != null) states[c.name] = next }
        }
    }

    /** Salva a RAM e o disco num ponto (savevm) e fecha; no próximo início a VM volta em segundos. */
    fun hibernate(c: VmConfig) {
        if (c.name in hibernating) return
        hibernating.add(c.name)
        notes[c.name] = "Hibernando… (pode levar de 10 s a alguns minutos)"
        viewModelScope.launch {
            val r = runCatching {
                QmpClient(c.qmpPort).execute(
                    "human-monitor-command",
                    JSONObject().put("command-line", "savevm hib"),
                    600_000
                )
            }.getOrNull()
            val err = r?.optJSONObject("error")?.optString("desc")
            val out = r?.optString("return").orEmpty()
            if (r != null && err == null && out.isBlank()) {
                withContext(Dispatchers.IO) { File(vmDir(c), "hibernated").writeText("1") }
                runCatching { QmpClient(c.qmpPort).send("quit") }
                states[c.name] = VmState.STOPPED
                notes[c.name] = "Hibernada. Ao iniciar, volta de onde parou."
            } else {
                notes[c.name] = "Não foi possível hibernar: " + (err ?: out.ifBlank { "sem resposta" })
            }
            hibernating.remove(c.name)
        }
    }

    /** Texto de progresso enquanto copia um arquivo para dentro do app (null = nada em andamento). */
    var copying by mutableStateOf<String?>(null)

    private fun cfgOf(name: String) = vms.firstOrNull { it.name == name }

    private fun saveStorage(name: String, change: (VmConfig) -> VmConfig) {
        val cur = cfgOf(name) ?: return
        VmRepository.save(app, change(cur))
        File(vmDir(cur), "hibernated").delete()            // armazenamento mudou: estado salvo não vale mais
        refresh()
    }

    /** Troca o CD/DVD (ISO). uri = null remove. */
    fun setIso(name: String, uri: Uri?) {
        val c = cfgOf(name) ?: return
        viewModelScope.launch {
            copying = "Copiando ISO…"
            try {
                val newPath: String? = withContext(Dispatchers.IO) {
                    if (uri == null) {
                        c.isoPath?.let { File(it).delete() }
                        null
                    } else {
                        val dest = File(vmDir(c), "boot.iso")
                        DiskTools.copy(app, uri, dest) { b -> copying = "Copiando ISO… ${b / (1024L * 1024L)} MB" }
                        dest.path
                    }
                }
                saveStorage(name) { it.copy(isoPath = newPath) }
                notes[name] = if (newPath == null) "CD/DVD removido." else "ISO trocada. Vale na próxima vez que a VM iniciar."
            } catch (e: Exception) {
                notes[name] = "Falha ao trocar a ISO: ${e.message}"
            } finally {
                copying = null
            }
        }
    }

    /** Adiciona um disco (qcow2, vhd, vhdx, vmdk, vdi, img) como HD extra da VM. */
    fun addExtraDisk(name: String, uri: Uri) {
        val c = cfgOf(name) ?: return
        if (c.extraDisks.size >= 2) {
            notes[name] = "Máximo de 2 HDs extras."
            return
        }
        viewModelScope.launch {
            copying = "Copiando disco…"
            try {
                val ref = withContext(Dispatchers.IO) {
                    val dir = vmDir(c)
                    val dest = File(dir, "extra_${System.currentTimeMillis()}.${DiskTools.extOf(DiskTools.displayName(app, uri))}")
                    DiskTools.copy(app, uri, dest) { b -> copying = "Copiando disco… ${b / (1024L * 1024L)} MB" }
                    DiskRef(dest.path, DiskTools.detectFormat(app, dir, dest))
                }
                saveStorage(name) { it.copy(extraDisks = (it.extraDisks + ref).take(2)) }
                notes[name] = "HD extra adicionado (${ref.format}). Vale na próxima vez que a VM iniciar."
            } catch (e: Exception) {
                notes[name] = "Falha ao adicionar o disco: ${e.message}"
            } finally {
                copying = null
            }
        }
    }

    fun removeExtraDisk(name: String, disk: DiskRef) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { File(disk.path).delete() }
            saveStorage(name) { it.copy(extraDisks = it.extraDisks.filter { d -> d.path != disk.path }) }
            notes[name] = "HD extra removido."
        }
    }

    fun setHardware(c: VmConfig, cpu: String, card: String, vram: Int, w: Int, h: Int, net: String, audio: String) {
        VmRepository.save(app, c.copy(cpuModel = cpu, videoCard = card, vramMb = vram, width = w, height = h, netModel = net, audioCard = audio))
        File(vmDir(c), "hibernated").delete()              // hardware mudou: o estado salvo não vale mais
        refresh()
    }

    fun delete(c: VmConfig) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { VmRepository.delete(app, c) }
            states.remove(c.name)
            refresh()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    vm: HomeViewModel = viewModel(),
    onCreate: () -> Unit,
    onSetup: () -> Unit,
    onOpenDisplay: (VmConfig) -> Unit
) {
    var toDelete by remember { mutableStateOf<VmConfig?>(null) }
    var toEdit by remember { mutableStateOf<String?>(null) }
    var toRemove by remember { mutableStateOf<Pair<String, DiskRef>?>(null) }
    val isoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val n = toEdit
        if (uri != null && n != null) vm.setIso(n, uri)
    }
    val diskPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val n = toEdit
        if (uri != null && n != null) vm.addExtraDisk(n, uri)
    }
    LaunchedEffect(Unit) { vm.refresh() }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Minhas VMs") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = onCreate) { Icon(Icons.Default.Add, "Nova VM") }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (!vm.envReady) {
                Card(Modifier.fillMaxWidth().padding(16.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Ambiente Linux (Alpine + QEMU) não instalado.")
                        Button(onClick = onSetup, modifier = Modifier.padding(top = 8.dp)) {
                            Text("Instalar agora")
                        }
                    }
                }
            }
            if (vm.vms.isEmpty()) {
                Box(Modifier.fillMaxSize(), Alignment.Center) {
                    Text("Nenhuma VM. Toque em + para criar.")
                }
            } else LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 340.dp),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(vm.vms, key = { it.name }) { c ->
                    val st = vm.states[c.name] ?: VmState.STOPPED
                    val saving = c.name in vm.hibernating
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text(c.name, style = MaterialTheme.typography.titleMedium)
                            Text(
                                "${c.cpus} CPUs • ${c.ramMb} MB • " + when {
                                    saving -> "Hibernando…"
                                    st == VmState.STOPPED -> "Parada"
                                    st == VmState.STARTING -> "Iniciando…"
                                    st == VmState.RUNNING -> "Em execução"
                                    else -> "Pausada"
                                },
                                style = MaterialTheme.typography.bodySmall
                            )
                            vm.notes[c.name]?.let {
                                Text(it, style = MaterialTheme.typography.bodySmall)
                            }
                            Row(
                                Modifier.padding(top = 8.dp).horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                when {
                                    saving -> {}
                                    st == VmState.STOPPED -> {
                                        Button(
                                            onClick = { vm.start(c); onOpenDisplay(c) },
                                            enabled = vm.envReady
                                        ) { Text("Iniciar") }
                                        TextButton(onClick = { toEdit = c.name }) { Text("Configurar") }
                                        TextButton(onClick = { toDelete = c }) { Text("Excluir") }
                                    }
                                    st == VmState.STARTING -> {
                                        Button(onClick = { onOpenDisplay(c) }) { Text("Abrir") }
                                        TextButton(onClick = { vm.forceStop(c) }) { Text("Forçar") }
                                    }
                                    st == VmState.RUNNING -> {
                                        Button(onClick = { onOpenDisplay(c) }) { Text("Abrir") }
                                        OutlinedButton(onClick = { vm.pause(c) }) { Text("Pausar") }
                                        if (c.diskFormat == "qcow2") {
                                            OutlinedButton(onClick = { vm.hibernate(c) }) { Text("Hibernar") }
                                        }
                                        TextButton(onClick = { vm.shutdown(c) }) { Text("Desligar") }
                                    }
                                    else -> {
                                        Button(onClick = { vm.resume(c) }) { Text("Continuar") }
                                        TextButton(onClick = { vm.forceStop(c) }) { Text("Forçar") }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    toEdit?.let { editName ->
        val c = vm.vms.firstOrNull { it.name == editName }
        if (c != null) {
            var cpu by remember(c.name) { mutableStateOf(c.cpuModel) }
            var card by remember(c.name) { mutableStateOf(c.videoCard) }
            var vram by remember(c.name) { mutableStateOf(c.vramMb) }
            var w by remember(c.name) { mutableStateOf(c.width) }
            var h by remember(c.name) { mutableStateOf(c.height) }
            var net by remember(c.name) { mutableStateOf(c.netModel) }
            var audio by remember(c.name) { mutableStateOf(c.audioCard) }
            val iso = c.isoPath
            val idle = vm.copying == null
            AlertDialog(
                onDismissRequest = { if (idle) toEdit = null },
                title = { Text("Configurar ${c.name}") },
                text = {
                    Column(
                        Modifier.verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        HardwarePickers(
                            cpu = cpu, onCpu = { cpu = it },
                            card = card, onCard = { card = it },
                            vram = vram, onVram = { vram = it },
                            net = net, onNet = { net = it },
                            audio = audio, onAudio = { audio = it },
                            resW = w, resH = h, onRes = { nw, nh -> w = nw; h = nh }
                        )

                        Text(
                            "Armazenamento (aplicado na hora)",
                            style = MaterialTheme.typography.titleSmall,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                        OutlinedButton(
                            onClick = { isoPicker.launch(arrayOf("*/*")) },
                            enabled = idle,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                if (iso != null) "CD/DVD: ${File(iso).name} (trocar)"
                                else "CD/DVD: nenhum (escolher ISO)"
                            )
                        }
                        if (iso != null) {
                            TextButton(onClick = { vm.setIso(c.name, null) }, enabled = idle) {
                                Text("Remover CD/DVD")
                            }
                        }
                        c.extraDisks.forEachIndexed { i, d ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    "HD extra ${i + 1}: ${d.format} • ${DiskTools.sizeLabel(File(d.path).length())}",
                                    Modifier.weight(1f)
                                )
                                TextButton(onClick = { toRemove = c.name to d }, enabled = idle) { Text("Remover") }
                            }
                        }
                        if (c.extraDisks.size < 2) {
                            OutlinedButton(
                                onClick = { diskPicker.launch(arrayOf("*/*")) },
                                enabled = idle,
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Adicionar HD externo (.qcow2 .vhd .vhdx .vmdk .img)") }
                        }
                        vm.copying?.let {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                                Text(it)
                            }
                        }

                        Text(
                            "Hardware: vale na próxima vez que a VM iniciar (toque em Salvar). " +
                                "Mudar o hardware ou o armazenamento descarta um estado hibernado.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                },
                confirmButton = {
                    TextButton(
                        onClick = { vm.setHardware(c, cpu, card, vram, w, h, net, audio); toEdit = null },
                        enabled = idle
                    ) { Text("Salvar") }
                },
                dismissButton = { TextButton(onClick = { toEdit = null }, enabled = idle) { Text("Fechar") } }
            )
        }
    }

    toRemove?.let { (vmName, disk) ->
        AlertDialog(
            onDismissRequest = { toRemove = null },
            title = { Text("Remover HD extra?") },
            text = {
                Text(
                    "A cópia dentro do app será apagada, com tudo que a VM gravou nela. " +
                        "O arquivo original no celular não é afetado."
                )
            },
            confirmButton = {
                TextButton(onClick = { vm.removeExtraDisk(vmName, disk); toRemove = null }) { Text("Remover") }
            },
            dismissButton = { TextButton(onClick = { toRemove = null }) { Text("Cancelar") } }
        )
    }

    toDelete?.let { c ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Excluir ${c.name}?") },
            text = { Text("O disco virtual e a ISO copiada serão apagados.") },
            confirmButton = { TextButton(onClick = { vm.delete(c); toDelete = null }) { Text("Excluir") } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancelar") } }
        )
    }
}
