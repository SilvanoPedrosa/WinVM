package com.winvm.app.ui

import android.app.Application
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.winvm.app.model.VmConfig
import com.winvm.app.model.VmRepository
import com.winvm.app.qemu.QemuPaths
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class CreateVmViewModel(private val app: Application) : AndroidViewModel(app) {
    var name by mutableStateOf("Windows")
    var ramMb by mutableStateOf(3072f)
    var cpus by mutableStateOf(2f)
    var diskGb by mutableStateOf(32f)
    var isoUri by mutableStateOf<Uri?>(null)
    var useSpice by mutableStateOf(false)
    var busy by mutableStateOf(false)
    var copiedMb by mutableStateOf(0L)
    var errorMsg by mutableStateOf<String?>(null)

    fun create(onReady: (VmConfig) -> Unit) {
        viewModelScope.launch {
            busy = true; errorMsg = null; copiedMb = 0
            try {
                val cfg = withContext(Dispatchers.IO) {
                    val n = name.trim()
                    val dir = File(VmRepository.root(app), n)
                    if (dir.exists()) throw IllegalStateException("Já existe uma VM com esse nome")
                    dir.mkdirs()

                    val iso = isoUri?.let { uri ->
                        File(dir, "boot.iso").also { f ->
                            app.contentResolver.openInputStream(uri)!!.use { i ->
                                f.outputStream().use { o ->
                                    val buf = ByteArray(1 shl 20)
                                    var total = 0L
                                    while (true) {
                                        val r = i.read(buf)
                                        if (r < 0) break
                                        o.write(buf, 0, r)
                                        total += r
                                        copiedMb = total / (1024L * 1024L)
                                    }
                                }
                            }
                        }
                    }

                    val disk = File(dir, "disk.qcow2")
                    val img = QemuPaths.img(app)
                    if (!img.exists()) throw IllegalStateException("libqemu-img.so não encontrado em jniLibs/arm64-v8a")
                    val p = ProcessBuilder(img.path, "create", "-f", "qcow2", disk.path, "${diskGb.toInt()}G")
                        .redirectErrorStream(true).start()
                    val log = p.inputStream.bufferedReader().readText()
                    if (p.waitFor() != 0) throw IllegalStateException(log)

                    val idx = VmRepository.nextIndex(app)
                    VmConfig(
                        name = n, ramMb = ramMb.toInt(), cpus = cpus.toInt(),
                        diskPath = disk.path, isoPath = iso?.path,
                        vncPort = idx, qmpPort = 4444 + idx, useSpice = useSpice
                    ).also { VmRepository.save(app, it) }
                }
                onReady(cfg)
            } catch (e: Exception) {
                // desfaz pasta parcial
                File(VmRepository.root(app), name.trim()).let { d ->
                    if (!File(d, "vm.json").exists()) d.deleteRecursively()
                }
                errorMsg = e.message
            } finally {
                busy = false
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateVmScreen(
    vm: CreateVmViewModel = viewModel(),
    onCreated: (VmConfig) -> Unit
) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { vm.isoUri = it }

    Scaffold(topBar = { TopAppBar(title = { Text("Nova VM") }) }) { pad ->
        Column(
            Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = vm.name,
                onValueChange = { vm.name = it.filter { c -> c.isLetterOrDigit() || c == '_' } },
                label = { Text("Nome") }, singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            LabeledSlider("RAM: ${vm.ramMb.toInt()} MB", vm.ramMb, 1024f..6144f, 9) { vm.ramMb = it }
            LabeledSlider("CPUs: ${vm.cpus.toInt()}", vm.cpus, 1f..8f, 6) { vm.cpus = it }
            LabeledSlider("Disco: ${vm.diskGb.toInt()} GB", vm.diskGb, 16f..128f, 6) { vm.diskGb = it }

            OutlinedButton(
                onClick = { picker.launch(arrayOf("*/*")) },
                modifier = Modifier.fillMaxWidth()
            ) { Text(vm.isoUri?.lastPathSegment ?: "Escolher ISO do Windows") }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Display SPICE (avançado)", Modifier.weight(1f))
                Switch(checked = vm.useSpice, onCheckedChange = { vm.useSpice = it })
            }

            vm.errorMsg?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            if (vm.busy) Text("Copiando ISO… ${vm.copiedMb} MB")

            Button(
                onClick = { vm.create(onCreated) },
                enabled = !vm.busy && vm.name.isNotBlank() && vm.isoUri != null,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (vm.busy) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                else Text("Criar e iniciar")
            }
        }
    }
}

@Composable
private fun LabeledSlider(
    label: String, value: Float, range: ClosedFloatingPointRange<Float>,
    steps: Int, onChange: (Float) -> Unit
) {
    Column {
        Text(label)
        Slider(value = value, onValueChange = onChange, valueRange = range, steps = steps)
    }
}
