package com.winvm.app.ui

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.winvm.app.model.DiskRef
import com.winvm.app.model.VmConfig
import com.winvm.app.model.VmRepository
import com.winvm.app.qemu.Rootfs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class CreateVmViewModel(private val app: Application) : AndroidViewModel(app) {
    var name by mutableStateOf("Windows")
    var ramMb by mutableStateOf(2048f)
    var cpus by mutableStateOf(2f)
    var diskGb by mutableStateOf(32f)
    var useExistingDisk by mutableStateOf(false)
    var diskUri by mutableStateOf<Uri?>(null)
    var diskName by mutableStateOf<String?>(null)
    val extraDisks = mutableStateListOf<Pair<Uri, String>>()
    var isoUri by mutableStateOf<Uri?>(null)
    var resW by mutableStateOf(0)
    var resH by mutableStateOf(0)
    var cpuModel by mutableStateOf("max")
    var videoCard by mutableStateOf("std")
    var vramMb by mutableStateOf(32)
    var netModel by mutableStateOf("e1000")
    var audioCard by mutableStateOf("hda")
    var busy by mutableStateOf(false)
    var copiedMb by mutableStateOf(0L)
    var errorMsg by mutableStateOf<String?>(null)
    private var copiedBytes = 0L

    private fun displayName(uri: Uri): String {
        app.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0) ?: "arquivo"
        }
        return uri.lastPathSegment ?: "arquivo"
    }

    fun pickDisk(uri: Uri?) {
        diskUri = uri
        diskName = uri?.let { displayName(it) }
    }

    fun addExtra(uri: Uri?) {
        if (uri != null && extraDisks.size < 2) extraDisks.add(uri to displayName(uri))
    }

    private fun extOf(name: String): String =
        name.substringAfterLast('.', "").lowercase().filter { it.isLetterOrDigit() }.take(6).ifEmpty { "img" }

    private fun copyUri(uri: Uri, dest: File) {
        app.contentResolver.openInputStream(uri)!!.use { i ->
            dest.outputStream().use { o ->
                val buf = ByteArray(1 shl 20)
                while (true) {
                    val r = i.read(buf)
                    if (r < 0) break
                    o.write(buf, 0, r)
                    copiedBytes += r
                    copiedMb = copiedBytes / (1024L * 1024L)
                }
            }
        }
    }

    /** Pergunta ao qemu-img qual é o formato (qcow2, vpc = VHD, vhdx, vmdk, vdi, raw). */
    private suspend fun detectFormat(dir: File, f: File): String {
        val out = StringBuilder()
        Rootfs.runGuest(app, listOf("qemu-img", "info", "/vm/${f.name}"), dir) { out.appendLine(it) }
        val fmt = Regex("file format:\\s*(\\S+)").find(out.toString())?.groupValues?.get(1)
        val ext = f.extension.lowercase()
        return when {
            fmt == null -> when (ext) {
                "qcow2" -> "qcow2"; "vhd" -> "vpc"; "vhdx" -> "vhdx"; "vmdk" -> "vmdk"; "vdi" -> "vdi"
                else -> "raw"
            }
            fmt == "raw" && ext == "vhd" -> "vpc"      // VHD de tamanho fixo costuma ser lido como raw
            else -> fmt
        }
    }

    fun create(onReady: (VmConfig) -> Unit) {
        viewModelScope.launch {
            busy = true; errorMsg = null; copiedMb = 0; copiedBytes = 0
            val n = name.trim()
            try {
                if (!Rootfs.isReady(app)) {
                    throw IllegalStateException("Instale o ambiente Linux primeiro (tela inicial › Instalar agora).")
                }
                val cfg = withContext(Dispatchers.IO) {
                    val dir = File(VmRepository.root(app), n)
                    if (dir.exists()) throw IllegalStateException("Já existe uma VM com esse nome")
                    dir.mkdirs()

                    val iso = isoUri?.let { uri -> File(dir, "boot.iso").also { copyUri(uri, it) } }

                    val diskFile: File
                    val diskFormat: String
                    val existing = diskUri
                    if (useExistingDisk && existing != null) {
                        diskFile = File(dir, "disk.${extOf(displayName(existing))}")
                        copyUri(existing, diskFile)
                        diskFormat = detectFormat(dir, diskFile)
                    } else {
                        diskFile = File(dir, "disk.qcow2")
                        val out = StringBuilder()
                        val code = Rootfs.runGuest(
                            app,
                            listOf("qemu-img", "create", "-f", "qcow2", "-o", "preallocation=metadata,lazy_refcounts=on",
                                "/vm/disk.qcow2", "${diskGb.toInt()}G"),
                            dir
                        ) { out.appendLine(it) }
                        if (code != 0) throw IllegalStateException("Falha ao criar o disco (código $code): $out")
                        diskFormat = "qcow2"
                    }

                    val extras = extraDisks.toList().mapIndexed { i, (uri, nm) ->
                        val f = File(dir, "extra${i + 1}.${extOf(nm)}")
                        copyUri(uri, f)
                        DiskRef(f.path, detectFormat(dir, f))
                    }

                    val idx = VmRepository.nextIndex(app)
                    VmConfig(
                        name = n, ramMb = ramMb.toInt(), cpus = cpus.toInt(),
                        diskPath = diskFile.path, isoPath = iso?.path,
                        vncPort = idx, qmpPort = 4444 + idx,
                        diskFormat = diskFormat, extraDisks = extras,
                        width = resW, height = resH,
                        cpuModel = cpuModel, videoCard = videoCard, vramMb = vramMb,
                        netModel = netModel, audioCard = audioCard
                    ).also { VmRepository.save(app, it) }
                }
                onReady(cfg)
            } catch (e: Exception) {
                File(VmRepository.root(app), n).let { d ->
                    if (d.exists() && !File(d, "vm.json").exists()) d.deleteRecursively()
                }
                errorMsg = e.message
            } finally {
                busy = false
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateVmScreen(
    vm: CreateVmViewModel = viewModel(),
    onCreated: (VmConfig) -> Unit
) {
    val isoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { vm.isoUri = it }
    val diskPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { vm.pickDisk(it) }
    val extraPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { vm.addExtra(it) }

    val hasBoot = vm.isoUri != null || (vm.useExistingDisk && vm.diskUri != null)
    val diskOk = !vm.useExistingDisk || vm.diskUri != null

    Scaffold(topBar = { TopAppBar(title = { Text("Nova VM") }) }) { pad ->
        Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.TopCenter) {
        Column(
            Modifier.widthIn(max = 640.dp).fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = vm.name,
                onValueChange = { vm.name = it.filter { c -> c.isLetterOrDigit() || c == '_' } },
                label = { Text("Nome") }, singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            LabeledSlider("RAM: ${vm.ramMb.toInt()} MB", vm.ramMb, 1024f..6144f, 9) { vm.ramMb = it }
            LabeledSlider("CPUs: ${vm.cpus.toInt()}", vm.cpus, 1f..8f, 6) { vm.cpus = it }

            Text("Disco principal", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = !vm.useExistingDisk,
                    onClick = { vm.useExistingDisk = false },
                    label = { Text("Novo (qcow2)") }
                )
                FilterChip(
                    selected = vm.useExistingDisk,
                    onClick = { vm.useExistingDisk = true },
                    label = { Text("Usar arquivo existente") }
                )
            }
            if (vm.useExistingDisk) {
                OutlinedButton(
                    onClick = { diskPicker.launch(arrayOf("*/*")) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(vm.diskName ?: "Escolher disco (.qcow2 .vhd .vhdx .vmdk .vdi .img)") }
                Text(
                    "O arquivo é copiado para dentro do app (precisa de espaço livre igual ao tamanho dele).",
                    style = MaterialTheme.typography.bodySmall
                )
            } else {
                LabeledSlider("Tamanho do disco: ${vm.diskGb.toInt()} GB", vm.diskGb, 16f..128f, 6) { vm.diskGb = it }
            }

            Text("Discos extras (opcional, até 2)", style = MaterialTheme.typography.titleSmall)
            vm.extraDisks.forEachIndexed { i, e ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(e.second, Modifier.weight(1f))
                    TextButton(onClick = { vm.extraDisks.removeAt(i) }) { Text("Remover") }
                }
            }
            if (vm.extraDisks.size < 2) {
                OutlinedButton(
                    onClick = { extraPicker.launch(arrayOf("*/*")) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Adicionar disco (.qcow2 / .vhd / .vhdx)") }
            }

            Text("Instalação", style = MaterialTheme.typography.titleSmall)
            OutlinedButton(
                onClick = { isoPicker.launch(arrayOf("*/*")) },
                modifier = Modifier.fillMaxWidth()
            ) { Text(vm.isoUri?.lastPathSegment ?: "ISO do sistema (opcional se usar disco existente)") }

            Text("Hardware e tela", style = MaterialTheme.typography.titleSmall)
            HardwarePickers(
                cpu = vm.cpuModel, onCpu = { vm.cpuModel = it },
                card = vm.videoCard, onCard = { vm.videoCard = it },
                vram = vm.vramMb, onVram = { vm.vramMb = it },
                net = vm.netModel, onNet = { vm.netModel = it },
                audio = vm.audioCard, onAudio = { vm.audioCard = it },
                resW = vm.resW, resH = vm.resH, onRes = { w, h -> vm.resW = w; vm.resH = h }
            )
            Text(
                "Linux ajusta a resolução sozinho. No Windows/ReactOS, depois de iniciar, confirme em " +
                    "Propriedades de vídeo. Dá para mudar tudo isso depois, com a VM parada (botão Configurar).",
                style = MaterialTheme.typography.bodySmall
            )

            vm.errorMsg?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            if (vm.busy) Text("Copiando arquivos… ${vm.copiedMb} MB")

            Button(
                onClick = { vm.create(onCreated) },
                enabled = !vm.busy && vm.name.isNotBlank() && hasBoot && diskOk,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (vm.busy) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                else Text("Criar e iniciar")
            }
        }
        }
    }
}

@Composable
private fun LabeledSlider(
    label: String, value: Float, range: ClosedFloatingPointRange<Float>,
    steps: Int, onChange: (Float) -> Unit
) {
    Column {
        Text(label)
        Slider(value = value, onValueChange = onChange, valueRange = range, steps = steps)
    }
}
