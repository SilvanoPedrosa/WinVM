Coloque aqui os arquivos de firmware do QEMU (bios-256k.bin, vgabios-stdvga.bin, kvmvapic.bin, efi-e1000.rom ...)
