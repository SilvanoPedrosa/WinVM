Coloque aqui patches (*.patch, -p1) para o QEMU se o build no Android exigir.
