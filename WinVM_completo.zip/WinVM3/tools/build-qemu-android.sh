#!/usr/bin/env bash
# Cross-compila QEMU (x86_64-softmmu + qemu-img) para Android arm64 usando o NDK.
# Uso (Linux x86_64):  ANDROID_NDK_HOME=/caminho/ndk-r27c bash tools/build-qemu-android.sh
# Saída: out/jniLibs/arm64-v8a/{libqemu.so,libqemu-img.so} e out/assets/qemu-share/*
set -euo pipefail

QEMU_VERSION="${QEMU_VERSION:-11.0.0}"
API="${API:-28}"                       # API 28+: bionic tem iconv (glib precisa)
: "${ANDROID_NDK_HOME:?defina ANDROID_NDK_HOME}"
TRIPLE=aarch64-linux-android
TC="$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/linux-x86_64"
ROOT="$PWD"
WORK="${WORK:-$ROOT/build-qemu}"
PREFIX="$WORK/prefix"
OUT="${OUT:-$ROOT/out}"
JOBS="$(nproc)"
mkdir -p "$WORK/src" "$WORK/bin" "$PREFIX" "$OUT/jniLibs/arm64-v8a" "$OUT/assets/qemu-share"

export CC="$TC/bin/${TRIPLE}${API}-clang"
export CXX="$TC/bin/${TRIPLE}${API}-clang++"
export AR="$TC/bin/llvm-ar" RANLIB="$TC/bin/llvm-ranlib" STRIP="$TC/bin/llvm-strip"
export PATH="$WORK/bin:$TC/bin:$PATH"

# nomes com prefixo de triple que o configure do QEMU espera
for t in ar ranlib strip nm objcopy objdump readelf; do ln -sf "$TC/bin/llvm-$t" "$WORK/bin/${TRIPLE}-$t"; done
ln -sf "$TC/bin/ld.lld" "$WORK/bin/${TRIPLE}-ld"
ln -sf "$CC" "$WORK/bin/${TRIPLE}-gcc"
cat > "$WORK/bin/${TRIPLE}-pkg-config" <<PK
#!/bin/sh
export PKG_CONFIG_LIBDIR="$PREFIX/lib/pkgconfig:$PREFIX/share/pkgconfig"
unset PKG_CONFIG_PATH
exec pkg-config --static "\$@"
PK
chmod +x "$WORK/bin/${TRIPLE}-pkg-config"
export PKG_CONFIG_LIBDIR="$PREFIX/lib/pkgconfig:$PREFIX/share/pkgconfig"

cat > "$WORK/cross.ini" <<INI
[binaries]
c = '$CC'
cpp = '$CXX'
ar = '$AR'
strip = '$STRIP'
pkg-config = '$WORK/bin/${TRIPLE}-pkg-config'
[host_machine]
system = 'android'
cpu_family = 'aarch64'
cpu = 'aarch64'
endian = 'little'
[built-in options]
c_args = ['-I$PREFIX/include']
cpp_args = ['-I$PREFIX/include']
c_link_args = ['-L$PREFIX/lib']
cpp_link_args = ['-L$PREFIX/lib']
INI

fetch() { # url dest-dir
  local f="$WORK/src/$(basename "$1")"
  [ -f "$f" ] || curl -fL --retry 4 -o "$f" "$1"
  mkdir -p "$2"; tar -xf "$f" -C "$2" --strip-components=1
}

echo "== libffi"
fetch https://github.com/libffi/libffi/releases/download/v3.4.6/libffi-3.4.6.tar.gz "$WORK/libffi"
( cd "$WORK/libffi" && ./configure --host=$TRIPLE --prefix="$PREFIX" --disable-shared --enable-static --disable-docs \
  && make -j"$JOBS" && make install )

echo "== pcre2"
fetch https://github.com/PCRE2Project/pcre2/releases/download/pcre2-10.44/pcre2-10.44.tar.gz "$WORK/pcre2"
( cd "$WORK/pcre2" && ./configure --host=$TRIPLE --prefix="$PREFIX" --disable-shared --enable-static \
  && make -j"$JOBS" && make install )

echo "== glib"
fetch https://download.gnome.org/sources/glib/2.80/glib-2.80.5.tar.xz "$WORK/glib"
( cd "$WORK/glib" && meson setup _b --cross-file "$WORK/cross.ini" --prefix "$PREFIX" --default-library=static \
    -Dtests=false -Dnls=disabled -Dlibmount=disabled -Dselinux=disabled -Dxattr=false \
    -Dlibelf=disabled -Dsysprof=disabled -Dintrospection=disabled -Dglib_debug=disabled \
    -Dman-pages=disabled -Ddtrace=false -Dsystemtap=false -Ddocumentation=false \
  && meson install -C _b )

echo "== pixman"
fetch https://cairographics.org/releases/pixman-0.43.4.tar.gz "$WORK/pixman"
( cd "$WORK/pixman" && meson setup _b --cross-file "$WORK/cross.ini" --prefix "$PREFIX" --default-library=static \
    -Dtests=disabled -Dgtk=disabled -Dlibpng=disabled -Dopenmp=disabled \
  && meson install -C _b )

echo "== libslirp (rede 'user')"
fetch https://gitlab.freedesktop.org/slirp/libslirp/-/archive/v4.8.0/libslirp-v4.8.0.tar.gz "$WORK/slirp"
( cd "$WORK/slirp" && meson setup _b --cross-file "$WORK/cross.ini" --prefix "$PREFIX" --default-library=static \
  && meson install -C _b )

# bionic nao tem librt/libutil/libpthread (as funcoes ficam na libc); o meson do QEMU
# exige a librt quando nao acha shm_open. Cria bibliotecas vazias para satisfazer o link.
mkdir -p "$PREFIX/lib"
for l in rt util pthread; do
  [ -f "$PREFIX/lib/lib$l.a" ] || "$AR" rc "$PREFIX/lib/lib$l.a"
done

echo "== QEMU $QEMU_VERSION"
fetch "https://download.qemu.org/qemu-$QEMU_VERSION.tar.xz" "$WORK/qemu"
cd "$WORK/qemu"
for p in "$ROOT"/tools/patches/*.patch; do [ -f "$p" ] && patch -p1 < "$p"; done
mkdir -p build && cd build
../configure --prefix=/usr --cross-prefix=${TRIPLE}- --cc="$CC" --cxx="$CXX" --host-cc=gcc \
  --target-list=x86_64-softmmu --without-default-features \
  --enable-tcg --enable-tools --enable-vnc --enable-slirp \
  --with-coroutine=sigaltstack --disable-werror --disable-docs \
  --extra-cflags="-I$PREFIX/include" --extra-ldflags="-L$PREFIX/lib"
make -j"$JOBS" qemu-system-x86_64 qemu-img

"$STRIP" -o "$OUT/jniLibs/arm64-v8a/libqemu.so"     qemu-system-x86_64
"$STRIP" -o "$OUT/jniLibs/arm64-v8a/libqemu-img.so" qemu-img

# firmwares mínimos (ignora os .fd grandes de outras arquiteturas)
cd ../pc-bios
for f in bios*.bin vgabios*.bin kvmvapic.bin linuxboot*.bin multiboot*.bin pvh.bin efi-*.rom; do
  [ -f "$f" ] && cp "$f" "$OUT/assets/qemu-share/"
done
echo "OK -> $OUT"
ls -la "$OUT/jniLibs/arm64-v8a" "$OUT/assets/qemu-share"
