#!/usr/bin/env bash
# Nome mantido por compatibilidade com o workflow. Agora NAO compila o QEMU:
# baixa o proot (+ libtalloc) prontos do repositorio do Termux e deixa em out/jniLibs.
# O QEMU e instalado DENTRO do app (Alpine Linux via proot + apk).
set -euo pipefail

ROOT="$PWD"; OUT="${OUT:-$ROOT/out}"; WORK="${WORK:-$ROOT/build-proot}"
JNI="$OUT/jniLibs/arm64-v8a"
mkdir -p "$WORK" "$JNI" "$OUT/assets/qemu-share"
echo "(nada aqui; o QEMU e instalado no app)" > "$OUT/assets/qemu-share/README.txt"

command -v patchelf >/dev/null || sudo apt-get install -y patchelf >/dev/null

BASES=("https://packages.termux.dev/apt/termux-main" "https://packages-cf.termux.dev/apt/termux-main")
BASE=""
for b in "${BASES[@]}"; do
  if curl -fsSL --retry 3 "$b/dists/stable/main/binary-aarch64/Packages" -o "$WORK/Packages"; then BASE="$b"; break; fi
done
[ -n "$BASE" ] || { echo "ERRO: nao consegui baixar o indice de pacotes do Termux"; exit 1; }

pkgfile() { # nome -> caminho do .deb no repositorio
  awk -v want="$1" '/^Package: /{cur=$2} /^Filename: /{ if (cur==want) { print $2; exit } }' "$WORK/Packages"
}

fetch_pkg() { # nome -> extrai em $WORK/x/<nome>
  local pkg="$1" f
  f="$(pkgfile "$pkg")"
  [ -n "$f" ] || { echo "ERRO: pacote '$pkg' nao encontrado no Termux"; exit 1; }
  echo "baixando $pkg ($f)"
  curl -fsSL --retry 3 "$BASE/$f" -o "$WORK/$pkg.deb"
  rm -rf "$WORK/x/$pkg"; mkdir -p "$WORK/x/$pkg"
  ( cd "$WORK/x/$pkg" && ar x "$WORK/$pkg.deb" && tar -xf data.tar.* )
}

echo "== proot"
fetch_pkg proot
P="$WORK/x/proot/data/data/com.termux/files/usr"
[ -f "$P/bin/proot" ] || { echo "ERRO: proot nao encontrado em $P/bin"; find "$WORK/x/proot" -name 'proot*' | head; exit 1; }
LOADER="$(find "$WORK/x/proot" -path '*libexec/proot/loader' -type f | head -1)"
[ -n "$LOADER" ] || { echo "ERRO: loader do proot nao encontrado"; exit 1; }
cp "$P/bin/proot" "$JNI/libproot.so"
cp "$LOADER" "$JNI/libproot-loader.so"
patchelf --remove-rpath "$JNI/libproot.so" || true

# resolve dependencias dinamicas (libtalloc etc.), renomeando para lib<nome>.so
needed() { readelf -d "$1" | sed -n 's/.*Shared library: \[\(.*\)\]/\1/p'; }
check=("$JNI/libproot.so")
while [ ${#check[@]} -gt 0 ]; do
  elf="${check[0]}"; check=("${check[@]:1}")
  for n in $(needed "$elf"); do
    case "$n" in libc.so|libm.so|libdl.so|liblog.so) continue ;; esac
    base="${n%%.so*}"
    if [ ! -f "$JNI/$base.so" ]; then
      fetch_pkg "$base"
      real="$(find "$WORK/x/$base" -name "$base.so*" -type f | head -1)"
      [ -n "$real" ] || { echo "ERRO: biblioteca $base nao encontrada no pacote"; exit 1; }
      cp "$real" "$JNI/$base.so"
      patchelf --set-soname "$base.so" "$JNI/$base.so"
      patchelf --remove-rpath "$JNI/$base.so" || true
      check+=("$JNI/$base.so")
    fi
    [ "$n" = "$base.so" ] || patchelf --replace-needed "$n" "$base.so" "$elf"
  done
done

echo "== resultado"
ls -la "$JNI"
echo "NEEDED do libproot.so:"; needed "$JNI/libproot.so"
