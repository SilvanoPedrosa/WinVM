# WinVM – frontend Android para QEMU

## Opção A – compilar tudo na nuvem (recomendado, funciona pelo celular)
1. Crie um repositório no GitHub e envie o conteúdo desta pasta.
2. Aba **Actions > Build WinVM (QEMU + APK) > Run workflow**.
3. Ao terminar, baixe os artefatos:
   - `WinVM-debug-apk` (APK pronto), ou
   - `qemu-android` (jniLibs + assets) para copiar em `app/src/main/` e compilar no AndroidIDE.

## Opção B – compilar o QEMU numa máquina Linux x86_64
    ANDROID_NDK_HOME=/caminho/android-ndk-r27c bash tools/build-qemu-android.sh
    cp -r out/jniLibs/* app/src/main/jniLibs/
    cp -r out/assets/*  app/src/main/assets/
Depois: Clean Project + Assemble Debug no AndroidIDE.

Variáveis: QEMU_VERSION (padrão 11.0.0), API (padrão 28 => Android 9+).
Se o build do QEMU falhar, ajuste com patches em tools/patches/ (aplicados com -p1).
Log da VM: files/vms/<nome>/qemu.log
