# WinVM – frontend Android para QEMU (via Alpine Linux + proot)

Em vez de compilar o QEMU para Android, o app baixa um Alpine Linux arm64 (rootfs),
roda-o com o **proot** e instala o **QEMU** dentro dele com o `apk`.

## Gerar o APK (GitHub Actions)
O workflow baixa o `proot` pronto (repositorio do Termux) para `app/src/main/jniLibs/arm64-v8a/`
(`libproot.so`, `libproot-loader.so`, `libtalloc.so`) e compila o APK.

## Uso
1. Abra o app > **Instalar agora** (baixa ~100 MB; precisa de internet).
2. Crie a VM (escolha a ISO) e inicie. Display via VNC embutido.
Log do QEMU: files/vms/<nome>/qemu.log

## Discos e tela
- Disco principal: novo (qcow2) ou arquivo existente (.qcow2 .vhd .vhdx .vmdk .vdi .img). O formato é detectado com `qemu-img info`.
- Até 2 discos extras (IDE slots 1 e 3). O CD-ROM usa o slot 2.
- Resolução preferida (EDID) por VM; editável com a VM parada.

## USB / OTG, hardware e velocidade
- **Pendrive OTG:** na tela da VM, ⌨ > USB. O app lê o pendrive pela API USB do Android (Bulk-Only/SCSI),
  expõe como disco NBD em localhost e o QEMU o liga à VM a quente como `usb-storage` (QMP blockdev-add + device_add).
- **CPU Intel/AMD, placa de vídeo (VGA, VMware SVGA, Cirrus), memória de vídeo e resolução:** na criação e em Configurar.
- **Proporção da tela:** Original / Esticar / 4:3 / 16:9 / 16:10 (botão "Tela" na barra de teclas).
- **Inicialização mais rápida:** -nodefaults, hpet=off, 1 soquete, tb-size proporcional à RAM, qcow2 com metadados
  pré-alocados, decodificação VNC em bloco, APK sem modo depuração e **Hibernar** (savevm/loadvm) para retomar em segundos.

## Internet e som
- **Internet:** rede NAT (usa Wi-Fi/dados do celular). Placa: e1000, RTL8139, PCnet, VirtIO ou "Sem internet".
- **Som:** o QEMU grava PCM (backend `wav`) num FIFO em `files/vms/<nome>/audio.fifo`; o `AudioBridge` lê o FIFO e toca com `AudioTrack`.
  Placas: Intel HD Audio, AC97, Sound Blaster 16. Só saída (sem microfone).

## Telas e barras do sistema
- Telas normais: o sistema desenha status/navegação e o conteúdo fica entre elas.
- Tela da VM: tela cheia (barras ocultas) ou **Barras: visíveis** (botão na barra de teclas); imagem e botões respeitam o notch
  e a área de gestos. Home em grade adaptativa; Criar/Setup com largura máxima em tablets.
