# WinVM – frontend Android para QEMU (via Alpine Linux + proot)

Em vez de compilar o QEMU para Android, o app baixa um Alpine Linux arm64 (rootfs),
roda-o com o **proot** e instala o **QEMU** dentro dele com o `apk`.

## Gerar o APK (GitHub Actions)
O workflow baixa o `proot` pronto (repositorio do Termux) para `app/src/main/jniLibs/arm64-v8a/`
(`libproot.so`, `libproot-loader.so`, `libtalloc.so`) e compila o APK.

## Uso
1. Abra o app > **Instalar agora** (baixa ~100 MB; precisa de internet).
2. Crie a VM (escolha a ISO) e inicie. Display via VNC embutido.
Log do QEMU: files/vms/<nome>/qemu.log

## Discos e tela
- Disco principal: novo (qcow2) ou arquivo existente (.qcow2 .vhd .vhdx .vmdk .vdi .img). O formato é detectado com `qemu-img info`.
- Até 2 discos extras (IDE slots 1 e 3). O CD-ROM usa o slot 2.
- Resolução preferida (EDID) por VM; editável com a VM parada.

## USB / OTG, hardware e velocidade
- **Pendrive OTG:** na tela da VM, ⌨ > USB. O app lê o pendrive pela API USB do Android (Bulk-Only/SCSI),
  expõe como disco NBD em localhost e o QEMU o liga à VM a quente como `usb-storage` (QMP blockdev-add + device_add).
- **Hardware:** CPU Intel/AMD, placa de vídeo (VGA, VMware SVGA, Cirrus), memória de vídeo, resolução e som.
- **Proporção da tela:** Original / Esticar / 4:3 / 16:9 / 16:10 (botão "Tela" na barra de teclas).
- **Inicialização mais rápida:** -nodefaults, hpet=off, 1 soquete, tb-size proporcional à RAM, qcow2 com metadados
  pré-alocados, decodificação VNC em bloco, APK sem modo depuração e **Hibernar** (savevm/loadvm) para retomar em segundos.

## Internet e som
- **Internet:** rede NAT (usa Wi-Fi/dados do celular). Placa padrão: Intel e1000 (sem opção de escolha no app).
- **Som:** o QEMU grava PCM (backend `wav`) num FIFO em `files/vms/<nome>/audio.fifo`; o `AudioBridge` lê o FIFO e toca com `AudioTrack`.
  Placa padrão: Intel HD Audio (sem opção de escolha no app). Só saída (sem microfone).

## Telas e barras do sistema
- Telas normais: o sistema desenha status/navegação e o conteúdo fica entre elas.
- Tela da VM: tela cheia (barras ocultas) ou **Barras: visíveis** (botão na barra de teclas); imagem e botões respeitam o notch
  e a área de gestos. Home em grade adaptativa; Criar/Setup com largura máxima em tablets.

## HD externo / CD pela tela Configurar
- Com a VM parada: trocar/remover o CD (ISO) e adicionar até 2 HDs extras (.qcow2 .vhd .vhdx .vmdk .vdi .img).
- Os arquivos são copiados para a pasta da VM; o formato é detectado com `qemu-img info`.

## Visual
- Tema próprio (claro/escuro automático) com cantos bem arredondados: `ui/Theme.kt`.
- Componentes reutilizáveis em `ui/Common.kt` (SectionCard, PickerField, Pill).
- Início com cartões por VM (status, especificações, ações), Criar VM em seções, Instalação com terminal.
- A tela da VM (touchpad, teclas, USB, barras) não foi alterada.

## Teclado
- Teclado físico (Bluetooth / USB OTG) reconhecido na tela da VM: letras, números, símbolos, F1–F12, setas, Home/End,
  PgUp/PgDn, Ins/Del, teclado numérico, Ctrl/Alt/Shift/Win. Caps Lock e Num Lock têm botões na barra.
- Barra virtual: Shift, F1–F12 (botão "F1–F12"), Home, End, PgUp, PgDn, Ins, PrtSc, Caps, Num, Menu.

## Disco virtual
- O disco (qcow2) de uma VM nova fica sempre dentro do app, em `files/vms/<nome>/`.
- Ao criar a VM não há opção de salvar na pasta Download. Discos de VMs antigas que já estejam lá continuam funcionando (montados como /ext0, com `locking=off`).
- Excluir a VM apaga o disco interno; discos antigos na pasta Download não são apagados.

## Desempenho / inicialização
- **Disco turbo** (`cache=unsafe`): ignora fsync do convidado (padrão ligado; por VM em Configurar).
- **CPU Nehalem** como padrão de novas VMs (sem AVX2 na emulação).
- **Aquecimento do cache** do disco enquanto o QEMU inicia (`DiskWarmup`); ao retomar de hibernação lê também o fim do arquivo.
- **Wake lock** parcial enquanto há VM rodando; VNC limitado a ~25 quadros/s; conexão do display tenta a cada 250 ms; `key-delay-ms=0`.
- **Hibernar** só quando disco principal e extras são qcow2 (`VmConfig.canHibernate`).

## Inicialização turbo (segunda rodada)
- **CPU turbo** (padrão): TCG em **1 thread** (`thread=single`, sem barreiras de memória do MTTCG), no máximo **2 vCPUs**,
  CPU "Automática" = Nehalem, QEMU fixado nos núcleos rápidos via `taskset` (`CpuTopology`, só se o Alpine tiver taskset).
- **Início rápido** (padrão): o botão desligar hiberna (savevm) e o próximo início faz `-loadvm` (segundos).
  O estado salvo tem versão (`QemuCommandBuilder.HIB_VERSION`): versões incompatíveis dão boot normal em vez de falhar.
- Boot direto no disco quando não há ISO (`-boot order=c,menu=off`).

## Desempenho (2ª rodada)
- Boot: `-boot order=c,once=d` (CD só na 1ª inicialização), `smm=off`, `vmport=off`, qcow2 com `l2-cache-size=8M`, rede sem IPv6.
- Aquecimento do cache: QEMU/bibliotecas/firmware (`RootfsWarmup`), disco e ISO (`DiskWarmup`).
- `QemuBoost`: prioridade maior (nice) para as threads do QEMU/proot. HIB_VERSION=4 invalida estados hibernados antigos.

## RAM
- O controle de RAM (criar VM e Configurar) vai de 1 GB até a RAM do celular (máx. 16 GB) e avisa acima de ~60%.

