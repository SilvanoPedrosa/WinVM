# WinVM – frontend Android para QEMU (via Alpine Linux + proot)

Em vez de compilar o QEMU para Android, o app baixa um Alpine Linux arm64 (rootfs),
roda-o com o **proot** e instala o **QEMU** dentro dele com o `apk`.

## Gerar o APK (GitHub Actions)
O workflow baixa o `proot` pronto (repositorio do Termux) para `app/src/main/jniLibs/arm64-v8a/`
(`libproot.so`, `libproot-loader.so`, `libtalloc.so`) e compila o APK.

## Uso
1. Abra o app > **Instalar agora** (baixa ~100 MB; precisa de internet).
2. Crie a VM (escolha a ISO) e inicie. Display via VNC embutido.
Log do QEMU: files/vms/<nome>/qemu.log

## Discos e tela
- Disco principal: novo (qcow2) ou arquivo existente (.qcow2 .vhd .vhdx .vmdk .vdi .img). O formato é detectado com `qemu-img info`.
- Até 2 discos extras (IDE slots 1 e 3). O CD-ROM usa o slot 2.
- Resolução preferida (EDID) por VM; editável com a VM parada.
