package com.wineqm.app.vm

import android.content.Context
import android.net.LocalSocket
import android.net.LocalSocketAddress
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Gerencia o processo do QEMU: instalação de firmware, start, comunicação
 * QMP e desligamento.
 */
class VmController(private val context: Context) {

    private var process: Process? = null
    private var config: VmConfig? = null

    val isRunning: Boolean
        get() = process?.isAlive == true

    fun firmwareDir(): File =
        File(context.filesDir, "qemu/firmware").apply { mkdirs() }

    /** Copia os arquivos de firmware de assets/firmware para o armazenamento interno. */
    fun installFirmware() {
        val dir = firmwareDir()
        val assets = context.assets
        for (name in assets.list("firmware").orEmpty()) {
            val out = File(dir, name)
            if (out.exists()) continue
            assets.open("firmware/$name").use { src ->
                out.outputStream().use { dst -> src.copyTo(dst) }
            }
        }
    }

    fun start(cfg: VmConfig): Result<Unit> = runCatching {
        check(!isRunning) { "A VM já está em execução" }

        val binary = File(context.applicationInfo.nativeLibraryDir, QemuCommand.BINARY_NAME)
        check(binary.exists()) { "Binário do QEMU não encontrado em ${binary.path}" }

        installFirmware()
        cfg.logFile.parentFile?.mkdirs()
        cfg.qmpSocket.delete()

        val pb = ProcessBuilder(QemuCommand.build(binary, cfg))
            .directory(context.filesDir)
            .redirectErrorStream(true)
            .redirectOutput(ProcessBuilder.Redirect.appendTo(cfg.logFile))
        pb.environment()["TMPDIR"] = context.cacheDir.absolutePath
        // O QEMU empacotado depende de bibliotecas .so que estão no mesmo diretório
        pb.environment()["LD_LIBRARY_PATH"] = context.applicationInfo.nativeLibraryDir

        process = pb.start()
        config = cfg
    }

    /** Desligamento gracioso via ACPI, com fallback para encerrar o processo. */
    fun shutdown(timeoutMs: Long = 30_000) {
        val p = process ?: return
        val cfg = config
        if (p.isAlive && cfg != null) {
            runCatching { qmp(cfg.qmpSocket, "system_powerdown") }
            p.waitFor(timeoutMs, TimeUnit.MILLISECONDS)
        }
        if (p.isAlive) {
            p.destroy()
            if (!p.waitFor(5, TimeUnit.SECONDS)) p.destroyForcibly()
        }
        process = null
        config = null
    }

    private fun qmp(socketFile: File, command: String) {
        val socket = LocalSocket()
        try {
            socket.connect(
                LocalSocketAddress(socketFile.absolutePath, LocalSocketAddress.Namespace.FILESYSTEM)
            )
            val reader = socket.inputStream.bufferedReader()
            val writer = socket.outputStream.bufferedWriter()
            reader.readLine() // saudação do QMP
            writer.write("{\"execute\":\"qmp_capabilities\"}\n")
            writer.flush()
            reader.readLine()
            writer.write("{\"execute\":\"$command\"}\n")
            writer.flush()
            reader.readLine()
        } finally {
            socket.close()
        }
    }
}
