package com.wineqm.app.vm

import java.io.File

/**
 * Monta a linha de comando do qemu-system-x86_64.
 * Função pura, sem efeitos colaterais, para ser testável no JVM.
 */
object QemuCommand {

    /** Nome do binário empacotado em jniLibs/arm64-v8a. */
    const val BINARY_NAME = "libqemu-system-x86_64.so"

    private const val ROOTFS_CMDLINE =
        "root=rootfs rootfstype=9p rootflags=trans=virtio,version=9p2000.L,cache=mmap " +
            "rw console=ttyS0 init=/sbin/init"

    fun build(binary: File, cfg: VmConfig): List<String> {
        val args = mutableListOf(
            binary.absolutePath,
            // Diretório com BIOS/ROMs (bios-256k.bin, vgabios-virtio.bin, ...)
            "-L", cfg.firmwareDir.absolutePath,
            "-machine", "q35",
            // Emulação pura (TCG): não há KVM disponível para apps Android comuns
            "-accel", "tcg,thread=multi",
            "-cpu", "max",
            "-m", cfg.ramMb.toString(),
            "-smp", cfg.cpus.toString()
        )
        args += storageArgs(cfg)
        args += listOf(
            "-netdev", "user,id=net0",
            "-device", "virtio-net-pci,netdev=net0",
            "-device", "virtio-vga",
            "-device", "virtio-keyboard-pci",
            // Ponteiro absoluto: necessário para toque funcionar bem no noVNC
            "-device", "virtio-tablet-pci",
            // Display VNC só em localhost, servido também via WebSocket
            "-vnc", "127.0.0.1:0,websocket=${cfg.wsPort}",
            "-qmp", "unix:${cfg.qmpSocket.absolutePath},server=on,wait=off",
            "-serial", "file:${cfg.logFile.absolutePath}",
            "-no-reboot"
        )
        return args
    }

    private fun storageArgs(cfg: VmConfig): List<String> {
        val rootfs = cfg.rootfsDir
        return if (rootfs != null) {
            val kernel = requireNotNull(cfg.kernel) { "Kernel não encontrado em /boot do rootfs" }
            val args = mutableListOf(
                "-kernel", kernel.absolutePath,
                "-append", ROOTFS_CMDLINE,
                "-fsdev", "local,id=fs0,path=${rootfs.absolutePath},security_model=mapped-file",
                "-device", "virtio-9p-pci,fsdev=fs0,mount_tag=rootfs"
            )
            cfg.initrd?.let { args += listOf("-initrd", it.absolutePath) }
            args
        } else {
            val disk = requireNotNull(cfg.diskImage) { "Nenhum rootfs ou disco configurado" }
            listOf("-drive", "file=${disk.absolutePath},format=${cfg.diskFormat},if=virtio")
        }
    }
}
