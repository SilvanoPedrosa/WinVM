package com.wineqm.app.vm

import java.io.File

/**
 * Parâmetros de uma execução da VM.
 *
 * Use [diskImage] para boot de um disco, ou [rootfsDir] + [kernel] para boot
 * direto de um rootfs extraído (via virtio-9p). Se os dois forem informados,
 * o rootfs tem prioridade.
 */
data class VmConfig(
    val firmwareDir: File,
    val qmpSocket: File,
    val logFile: File,
    val diskImage: File? = null,
    val diskFormat: String = "qcow2",
    val rootfsDir: File? = null,
    val kernel: File? = null,
    val initrd: File? = null,
    val ramMb: Int = 4096,
    val cpus: Int = 4,
    /** Porta WebSocket onde o QEMU serve o framebuffer para o noVNC. */
    val wsPort: Int = 5700
)
