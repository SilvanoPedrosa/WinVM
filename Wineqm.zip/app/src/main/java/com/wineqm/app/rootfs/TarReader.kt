package com.wineqm.app.rootfs

import java.io.InputStream

/**
 * Leitor mínimo de tar (ustar, pax e extensões GNU de nome longo).
 * Não depende de bibliotecas externas.
 */
object TarReader {

    class Entry(
        val name: String,
        val type: Char,
        val size: Long,
        val mode: Int,
        val linkName: String
    ) {
        val isDirectory: Boolean get() = type == '5'
        val isFile: Boolean get() = type == '0' || type == '\u0000' || type == '7'
        val isSymlink: Boolean get() = type == '2'
        val isHardlink: Boolean get() = type == '1'
    }

    private const val BLOCK = 512

    /** Chama [onEntry] para cada entrada; o InputStream recebido contém só os dados dela. */
    fun read(input: InputStream, onEntry: (Entry, InputStream) -> Unit) {
        val header = ByteArray(BLOCK)
        var longName: String? = null
        var longLink: String? = null
        var paxPath: String? = null
        var paxLink: String? = null
        var paxSize: Long? = null

        while (readFully(input, header)) {
            if (header.all { it == 0.toByte() }) break

            val size = parseNumber(header, 124, 12)
            val type = (header[156].toInt() and 0xFF).toChar()

            // Metadados que valem para a próxima entrada
            if (type == 'L' || type == 'K' || type == 'x' || type == 'g') {
                val data = ByteArray(size.toInt())
                readFully(input, data)
                skip(input, padding(size))
                when (type) {
                    'L' -> longName = String(data, Charsets.UTF_8).trimEnd('\u0000')
                    'K' -> longLink = String(data, Charsets.UTF_8).trimEnd('\u0000')
                    'x' -> {
                        val rec = parsePax(data)
                        paxPath = rec["path"]
                        paxLink = rec["linkpath"]
                        paxSize = rec["size"]?.toLongOrNull()
                    }
                    // 'g' (pax global): ignorado
                }
                continue
            }

            val ustarName = field(header, 0, 100)
            val prefix = field(header, 345, 155)
            val baseName = if (prefix.isNotEmpty()) "$prefix/$ustarName" else ustarName

            val entry = Entry(
                name = paxPath ?: longName ?: baseName,
                type = type,
                size = paxSize ?: size,
                mode = parseNumber(header, 100, 8).toInt(),
                linkName = paxLink ?: longLink ?: field(header, 157, 100)
            )
            longName = null; longLink = null
            paxPath = null; paxLink = null; paxSize = null

            val data = Bounded(input, entry.size)
            onEntry(entry, data)
            skip(input, data.remaining)
            skip(input, padding(entry.size))
        }
    }

    private class Bounded(private val s: InputStream, var remaining: Long) : InputStream() {
        override fun read(): Int {
            if (remaining <= 0) return -1
            val b = s.read()
            if (b >= 0) remaining--
            return b
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (remaining <= 0) return -1
            val n = s.read(b, off, minOf(len.toLong(), remaining).toInt())
            if (n > 0) remaining -= n
            return n
        }
    }

    private fun readFully(s: InputStream, buf: ByteArray): Boolean {
        var off = 0
        while (off < buf.size) {
            val n = s.read(buf, off, buf.size - off)
            if (n < 0) return false
            off += n
        }
        return true
    }

    private fun skip(s: InputStream, n: Long) {
        var left = n
        val buf = ByteArray(8192)
        while (left > 0) {
            val k = s.read(buf, 0, minOf(left, buf.size.toLong()).toInt())
            if (k < 0) break
            left -= k
        }
    }

    private fun padding(size: Long): Long = (BLOCK - size % BLOCK) % BLOCK

    private fun field(buf: ByteArray, off: Int, len: Int): String =
        String(buf, off, len, Charsets.UTF_8).substringBefore('\u0000')

    private fun parseNumber(buf: ByteArray, off: Int, len: Int): Long {
        // Formato binário (base-256) usado para valores grandes
        if ((buf[off].toInt() and 0x80) != 0) {
            var v = buf[off].toLong() and 0x7F
            for (i in 1 until len) v = (v shl 8) or (buf[off + i].toLong() and 0xFF)
            return v
        }
        val s = String(buf, off, len, Charsets.US_ASCII).trim { it == ' ' || it == '\u0000' }
        return if (s.isEmpty()) 0L else s.toLong(8)
    }

    /** Registros pax: "<tamanho> <chave>=<valor>\n", com tamanho em bytes. */
    private fun parsePax(data: ByteArray): Map<String, String> {
        val result = HashMap<String, String>()
        var pos = 0
        while (pos < data.size) {
            var space = pos
            while (space < data.size && data[space] != 0x20.toByte()) space++
            val len = String(data, pos, space - pos, Charsets.US_ASCII).toIntOrNull() ?: break
            if (len <= 0 || pos + len > data.size) break
            val record = String(data, space + 1, pos + len - space - 2, Charsets.UTF_8)
            val eq = record.indexOf('=')
            if (eq > 0) result[record.substring(0, eq)] = record.substring(eq + 1)
            pos += len
        }
        return result
    }
}
