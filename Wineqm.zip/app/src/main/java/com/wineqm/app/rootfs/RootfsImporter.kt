package com.wineqm.app.rootfs

import java.io.BufferedInputStream
import java.io.File
import java.io.InputStream
import java.nio.file.Files
import java.util.zip.GZIPInputStream

/** Kernel e initrd encontrados dentro de /boot do rootfs. */
data class BootFiles(val kernel: File, val initrd: File?)

object RootfsImporter {

    private val XZ_MAGIC = byteArrayOf(0xFD.toByte(), 0x37, 0x7A, 0x58, 0x5A, 0x00)

    /**
     * Extrai um tar plano ou .tar.gz para [destDir], apagando o conteúdo anterior.
     * A compressão é detectada pelos primeiros bytes, não pela extensão.
     */
    fun import(input: InputStream, destDir: File, onProgress: (Int) -> Unit) {
        destDir.deleteRecursively()
        destDir.mkdirs()
        val root = destDir.toPath().toAbsolutePath().normalize()

        val buffered = BufferedInputStream(input)
        buffered.mark(6)
        val magic = ByteArray(6)
        val read = buffered.read(magic)
        buffered.reset()

        val stream: InputStream = when {
            read >= 2 && magic[0] == 0x1f.toByte() && magic[1] == 0x8b.toByte() ->
                GZIPInputStream(buffered)
            read == 6 && magic.contentEquals(XZ_MAGIC) ->
                throw IllegalArgumentException(
                    "Arquivos .tar.xz não são suportados no celular. " +
                        "No PC, converta com: xz -dc rootfs.tar.xz | gzip > rootfs.tar.gz"
                )
            else -> buffered
        }

        var count = 0
        TarReader.read(stream) { entry, data ->
            val target = root.resolve(entry.name).normalize()
            // Impede entradas com ".." que escapem do diretório de destino
            require(target.startsWith(root)) { "Caminho inválido no tar: ${entry.name}" }

            when {
                entry.isDirectory -> Files.createDirectories(target)

                entry.isSymlink -> {
                    Files.createDirectories(target.parent)
                    Files.deleteIfExists(target)
                    Files.createSymbolicLink(target, java.nio.file.Paths.get(entry.linkName))
                }

                entry.isHardlink -> {
                    val source = root.resolve(entry.linkName).normalize()
                    Files.createDirectories(target.parent)
                    Files.deleteIfExists(target)
                    Files.copy(source, target)
                }

                entry.isFile -> {
                    Files.createDirectories(target.parent)
                    Files.deleteIfExists(target)
                    Files.newOutputStream(target).use { out -> data.copyTo(out) }
                    val f = target.toFile()
                    f.setReadable(true, false)
                    f.setWritable(true, false)
                    if (entry.mode and 0b001_001_001 != 0) f.setExecutable(true, false)
                }

                // Dispositivos e FIFOs são ignorados: o Android não permite criá-los
            }

            count++
            if (count % 500 == 0) onProgress(count)
        }
        onProgress(count)
    }

    /** Procura vmlinuz-* e initrd.img-* em /boot. Retorna null se não houver kernel. */
    fun findBoot(rootfs: File): BootFiles? {
        val boot = File(rootfs, "boot")
        val kernel = boot.listFiles { f -> f.name.startsWith("vmlinuz-") }
            ?.maxByOrNull { it.name } ?: return null
        val initrd = boot.listFiles { f -> f.name.startsWith("initrd.img-") }
            ?.maxByOrNull { it.name }
        return BootFiles(kernel.canonicalFile, initrd?.canonicalFile)
    }
}
