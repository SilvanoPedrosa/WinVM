package com.wineqm.app

import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader
import com.wineqm.app.rootfs.RootfsImporter
import com.wineqm.app.vm.VmConfig
import com.wineqm.app.vm.VmController
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var placeholder: TextView
    private lateinit var webView: WebView
    private lateinit var btnImport: Button
    private lateinit var btnImportRootfs: Button
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button

    private val vm by lazy { VmController(this) }
    private val diskFile by lazy { File(filesDir, "vm/disk.qcow2") }
    private val rootfsDir by lazy { File(filesDir, "vm/rootfs") }
    private val qmpSocket by lazy { File(cacheDir, "qmp.sock") }
    private val logFile by lazy { File(filesDir, "vm/qemu.log") }

    private val pickDisk = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importDisk(uri)
    }

    private val pickRootfs = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importRootfs(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.txtStatus)
        placeholder = findViewById(R.id.txtPlaceholder)
        webView = findViewById(R.id.webView)
        btnImport = findViewById(R.id.btnImport)
        btnImportRootfs = findViewById(R.id.btnImportRootfs)
        btnStart = findViewById(R.id.btnStart)
        btnStop = findViewById(R.id.btnStop)

        setupWebView()

        btnImportRootfs.setOnClickListener { pickRootfs.launch(arrayOf("*/*")) }
        btnImport.setOnClickListener { pickDisk.launch(arrayOf("*/*")) }
        btnStart.setOnClickListener { startVm() }
        btnStop.setOnClickListener { stopVm() }

        updateUi()
    }

    override fun onDestroy() {
        // Se o usuário fechar o app, desliga a VM para não deixar o QEMU órfão.
        if (isFinishing && vm.isRunning) Thread { vm.shutdown() }.start()
        super.onDestroy()
    }

    private fun setupWebView() {
        // Serve os arquivos de assets/ como https://appassets.androidplatform.net/assets/...
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.setBackgroundColor(Color.BLACK)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = loader.shouldInterceptRequest(request.url)
        }
    }

    private fun importRootfs(uri: Uri) {
        setStatus(getString(R.string.status_extracting_rootfs))
        setImporting(true)
        Thread {
            try {
                val input = contentResolver.openInputStream(uri)
                    ?: error(getString(R.string.error_open_file))
                input.use { src ->
                    RootfsImporter.import(src, rootfsDir) { n ->
                        runOnUiThread { setStatus(getString(R.string.status_extracting_entries, n)) }
                    }
                }
                val boot = RootfsImporter.findBoot(rootfsDir)
                runOnUiThread {
                    setStatus(
                        if (boot != null) getString(R.string.status_rootfs_ready, boot.kernel.name)
                        else getString(R.string.status_rootfs_no_kernel)
                    )
                }
            } catch (e: Exception) {
                runOnUiThread { setStatus(getString(R.string.status_rootfs_failed, e.message)) }
            } finally {
                runOnUiThread { setImporting(false) }
            }
        }.start()
    }

    private fun importDisk(uri: Uri) {
        setStatus(getString(R.string.status_importing_disk))
        setImporting(true)
        Thread {
            try {
                diskFile.parentFile?.mkdirs()
                val input = contentResolver.openInputStream(uri)
                    ?: error(getString(R.string.error_open_file))
                input.use { src -> diskFile.outputStream().use { dst -> src.copyTo(dst) } }
                runOnUiThread { setStatus(getString(R.string.status_disk_ready)) }
            } catch (e: Exception) {
                runOnUiThread { setStatus(getString(R.string.status_disk_failed, e.message)) }
            } finally {
                runOnUiThread { setImporting(false) }
            }
        }.start()
    }

    private fun startVm() {
        val boot = RootfsImporter.findBoot(rootfsDir)
        val cfg = when {
            // Rootfs tem prioridade sobre o disco se ambos existirem
            boot != null -> VmConfig(
                firmwareDir = vm.firmwareDir(),
                qmpSocket = qmpSocket,
                logFile = logFile,
                rootfsDir = rootfsDir,
                kernel = boot.kernel,
                initrd = boot.initrd
            )
            diskFile.exists() -> VmConfig(
                firmwareDir = vm.firmwareDir(),
                qmpSocket = qmpSocket,
                logFile = logFile,
                diskImage = diskFile
            )
            else -> {
                toast(getString(R.string.toast_import_first))
                return
            }
        }

        setStatus(getString(R.string.status_starting))
        btnStart.isEnabled = false
        Thread {
            val result = vm.start(cfg)
            runOnUiThread {
                result
                    .onSuccess {
                        setStatus(getString(R.string.status_connecting))
                        webView.loadUrl(NOVNC_URL)
                    }
                    .onFailure { setStatus(getString(R.string.status_error, it.message)) }
                updateUi()
            }
        }.start()
    }

    private fun stopVm() {
        setStatus(getString(R.string.status_stopping))
        btnStop.isEnabled = false
        Thread {
            vm.shutdown()
            runOnUiThread {
                webView.loadUrl("about:blank")
                setStatus(getString(R.string.status_stopped))
                updateUi()
            }
        }.start()
    }

    private fun setImporting(busy: Boolean) {
        btnImport.isEnabled = !busy
        btnImportRootfs.isEnabled = !busy
        if (busy) btnStart.isEnabled = false else updateUi()
    }

    private fun updateUi() {
        val running = vm.isRunning
        val ready = diskFile.exists() || RootfsImporter.findBoot(rootfsDir) != null
        btnStart.isEnabled = !running && ready
        btnStop.isEnabled = running
        placeholder.visibility = if (running) View.GONE else View.VISIBLE
    }

    private fun setStatus(text: String) {
        status.text = text
    }

    private fun toast(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }

    companion object {
        private const val WS_PORT = 5700
        private const val NOVNC_URL =
            "https://appassets.androidplatform.net/assets/novnc/vnc.html" +
                "?host=127.0.0.1&port=$WS_PORT&autoconnect=1&reconnect=1&resize=scale"
    }
}
