package com.wineqm.app.rootfs

import org.junit.Assert.assertEquals
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

class TarReaderTest {

    /** Monta um header ustar mínimo de 512 bytes. */
    private fun header(name: String, size: Int, type: Char): ByteArray {
        val h = ByteArray(512)
        name.toByteArray().copyInto(h, 0)
        "%07o".format(420).toByteArray().copyInto(h, 100)
        "%011o".format(size).toByteArray().copyInto(h, 124)
        h[156] = type.toByte()
        "ustar".toByteArray().copyInto(h, 257)
        return h
    }

    private fun tarOf(vararg parts: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        parts.forEach { out.write(it) }
        out.write(ByteArray(1024)) // dois blocos zerados = fim do arquivo
        return out.toByteArray()
    }

    private fun padded(data: ByteArray): ByteArray {
        val size = (512 - data.size % 512) % 512
        return data + ByteArray(size)
    }

    @Test
    fun reads_files_and_contents() {
        val content = "hello".toByteArray()
        val tar = tarOf(header("a.txt", content.size, '0'), padded(content))

        val names = mutableListOf<String>()
        var text = ""
        TarReader.read(ByteArrayInputStream(tar)) { entry, data ->
            names.add(entry.name)
            text = data.readBytes().toString(Charsets.UTF_8)
        }
        assertEquals(listOf("a.txt"), names)
        assertEquals("hello", text)
    }

    @Test
    fun reads_gnu_long_names() {
        val longName = "d/" + "x".repeat(150) + ".txt"
        val nameData = (longName + "\u0000").toByteArray()
        val tar = tarOf(
            header("././@LongLink", nameData.size, 'L'), padded(nameData),
            header("short", 0, '0')
        )
        val names = mutableListOf<String>()
        TarReader.read(ByteArrayInputStream(tar)) { entry, _ -> names.add(entry.name) }
        assertEquals(listOf(longName), names)
    }

    @Test
    fun reads_directories_and_symlinks() {
        val link = header("bin/sh", 0, '2')
        "/bin/bash".toByteArray().copyInto(link, 157)
        val tar = tarOf(header("bin/", 0, '5'), link)

        val types = mutableListOf<Char>()
        val links = mutableListOf<String>()
        TarReader.read(ByteArrayInputStream(tar)) { entry, _ ->
            types.add(entry.type)
            if (entry.isSymlink) links.add(entry.linkName)
        }
        assertEquals(listOf('5', '2'), types)
        assertEquals(listOf("/bin/bash"), links)
    }
}
