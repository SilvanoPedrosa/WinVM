package com.wineqm.app.vm

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class QemuCommandTest {

    private val diskCfg = VmConfig(
        diskImage = File("/data/vm/disk.qcow2"),
        firmwareDir = File("/data/fw"),
        qmpSocket = File("/data/qmp.sock"),
        logFile = File("/data/qemu.log"),
        ramMb = 2048,
        cpus = 2
    )

    private val rootfsCfg = VmConfig(
        firmwareDir = File("/data/fw"),
        qmpSocket = File("/data/qmp.sock"),
        logFile = File("/data/qemu.log"),
        rootfsDir = File("/data/vm/rootfs"),
        kernel = File("/data/vm/rootfs/boot/vmlinuz-6.1.0"),
        initrd = File("/data/vm/rootfs/boot/initrd.img-6.1.0")
    )

    private val bin = File("/lib/libqemu-system-x86_64.so")

    @Test
    fun memory_and_cpus_are_passed() {
        val args = QemuCommand.build(bin, diskCfg)
        assertEquals("2048", args[args.indexOf("-m") + 1])
        assertEquals("2", args[args.indexOf("-smp") + 1])
    }

    @Test
    fun display_is_localhost_websocket() {
        assertTrue(QemuCommand.build(bin, diskCfg).contains("127.0.0.1:0,websocket=5700"))
    }

    @Test
    fun disk_uses_configured_format() {
        assertTrue(QemuCommand.build(bin, diskCfg).contains("file=/data/vm/disk.qcow2,format=qcow2,if=virtio"))
    }

    @Test
    fun binary_is_first_argument() {
        assertEquals(bin.absolutePath, QemuCommand.build(bin, diskCfg).first())
    }

    @Test
    fun rootfs_boots_from_9p_with_kernel() {
        val args = QemuCommand.build(bin, rootfsCfg)
        assertTrue(args.contains("virtio-9p-pci,fsdev=fs0,mount_tag=rootfs"))
        assertTrue(args.contains("-kernel"))
        assertTrue(args.contains("-initrd"))
        assertFalse(args.contains("-drive"))
    }
}
