#!/data/data/com.termux/files/usr/bin/bash
# Coleta o QEMU x86_64 instalado no Termux, junto com todas as bibliotecas
# que ele precisa, para empacotar no APK do Wineqm.
#
# Uso (dentro do Termux):
#   pkg install qemu-system-x86-64-headless patchelf
#   bash collect_qemu_termux.sh
#
# Saída em ~/wineqm-out/jniLibs (vai para app/src/main/jniLibs/arm64-v8a)
# e ~/wineqm-out/firmware (vai para app/src/main/assets/firmware).

set -e

PREFIX=/data/data/com.termux/files/usr
BIN="$PREFIX/bin/qemu-system-x86_64"
OUT="${OUT:-$HOME/wineqm-out}"
# Bibliotecas do próprio Android: não copiar
SYSTEM_LIBS=" libc.so libm.so libdl.so liblog.so "

[ -x "$BIN" ] || { echo "ERRO: $BIN não encontrado. Rode: pkg install qemu-system-x86-64-headless"; exit 1; }
command -v patchelf >/dev/null || { echo "ERRO: instale com: pkg install patchelf"; exit 1; }

rm -rf "$OUT"
mkdir -p "$OUT/jniLibs" "$OUT/firmware"

declare -A seen
queue=("$BIN")

# Percorre as dependências (NEEDED) de forma recursiva
while [ ${#queue[@]} -gt 0 ]; do
    current="${queue[0]}"
    queue=("${queue[@]:1}")
    for dep in $(patchelf --print-needed "$current"); do
        case "$SYSTEM_LIBS" in *" $dep "*) continue ;; esac
        [ -n "${seen[$dep]}" ] && continue
        src="$PREFIX/lib/$dep"
        if [ ! -e "$src" ]; then
            echo "AVISO: dependência não encontrada: $dep"
            continue
        fi
        seen[$dep]=1
        cp -L "$src" "$OUT/jniLibs/$dep"
        echo "lib: $dep"
        queue+=("$OUT/jniLibs/$dep")
    done
done

# O binário vira uma "lib" para o Android extraí-lo em nativeLibraryDir
cp -L "$BIN" "$OUT/jniLibs/libqemu-system-x86_64.so"
echo "binário: libqemu-system-x86_64.so"

# Firmware (BIOS, ROMs de vídeo, etc.)
for f in bios-256k.bin vgabios-virtio.bin kvmvapic.bin linuxboot_dma.bin; do
    if [ -e "$PREFIX/share/qemu/$f" ]; then
        cp -L "$PREFIX/share/qemu/$f" "$OUT/firmware/"
        echo "firmware: $f"
    else
        echo "AVISO: firmware ausente: $f"
    fi
done

echo
echo "Pronto. Copie:"
echo "  $OUT/jniLibs/*  ->  app/src/main/jniLibs/arm64-v8a/"
echo "  $OUT/firmware/* ->  app/src/main/assets/firmware/"
