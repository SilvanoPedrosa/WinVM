# Wineqm

App Android que executa uma VM Linux com Wine usando QEMU (emulação TCG),
exibindo o desktop da VM dentro do app via VNC sobre WebSocket e noVNC.

## Arquitetura

```
┌──────────────────────── App Android (Wineqm) ─────────────────────────┐
│  MainActivity ──► VmController ──► ProcessBuilder                      │
│       │                │                 │                            │
│       │                │ QMP (unix sock) ▼                            │
│       │                │          libqemu-system-x86_64.so (QEMU)     │
│       │                │                 │ -vnc :0,websocket=5700     │
│       ▼                                  ▼                            │
│  WebView + noVNC ◄──── ws://127.0.0.1:5700 ◄── framebuffer da VM      │
│  (assets/novnc)                           disco: disk.qcow2 (Wine)    │
└────────────────────────────────────────────────────────────────────────┘
```

| Arquivo | Função |
|---|---|
| `vm/QemuCommand.kt` | Monta os argumentos do QEMU (função pura, testada) |
| `vm/VmController.kt` | Instala firmware, inicia o processo, desliga via QMP |
| `vm/VmConfig.kt` | Parâmetros da VM (RAM, CPUs, disco, portas) |
| `MainActivity.kt` | UI: importar disco, iniciar, desligar, exibir display |

## O que já está pronto

- Projeto migrado para AGP 8.2, Kotlin 1.9, Gradle 8.2, compileSdk 34
  (o original usava versões de 2020 e repositórios Aliyun).
- Lançamento do QEMU via `nativeLibraryDir` com `useLegacyPackaging`, necessário
  para executar binários no Android.
- Controle por QMP (desligamento ACPI com fallback para `destroy`).
- Display via WebView + noVNC, com teclado e toque.
- Testes unitários da linha de comando.

## O que você precisa providenciar

Não é possível fazer tudo a partir do código do app. Faltam quatro peças.

### 1. Binário do QEMU para Android arm64

Caminho mais simples: pegar o QEMU que o Termux já compila para Android.

No Termux (no próprio celular):

```bash
pkg install qemu-system-x86-64-headless patchelf
cp ~/wineqm/scripts/collect_qemu_termux.sh .   # ou copie o script do projeto
bash collect_qemu_termux.sh
```

O script gera `~/wineqm-out/jniLibs/` (o binário `libqemu-system-x86_64.so` e as bibliotecas
que ele usa) e `~/wineqm-out/firmware/`. Copie:

- `~/wineqm-out/jniLibs/*` para `app/src/main/jniLibs/arm64-v8a/`
- `~/wineqm-out/firmware/*` para `app/src/main/assets/firmware/`

Para acessar as pastas do projeto a partir do Termux, rode `termux-setup-storage` antes e use `~/storage/shared/`.

Alternativa: compilar o QEMU com o NDK (mais trabalhoso, veja o histórico do projeto).

### 2. Firmware

O script do passo 1 já copia o firmware. Ele também fica em `app/src/main/assets/firmware/`.

### 3. noVNC

Baixe a release em https://github.com/novnc/noVNC/releases e extraia o conteúdo
em `app/src/main/assets/novnc/` (o `vnc.html` precisa ficar na raiz dessa pasta).

### 4. Imagem da VM (disco)

Crie uma imagem x86_64 com um desktop leve e Wine, por exemplo com Debian:

```bash
# No host Linux
sudo debootstrap --arch=amd64 bookworm ./rootfs http://deb.debian.org/debian
sudo chroot ./rootfs apt install -y xfce4 lightdm wine64 winetricks
# Configure login automático no lightdm e depois converta:
qemu-img convert -O qcow2 disco.raw wine.qcow2
```

Depois, no app, use **Importar disco** e escolha o `wine.qcow2`.

## Importar rootfs (sistema Linux + Wine)

O botão **Importar rootfs** aceita um tar plano ou `.tar.gz` com um sistema Linux x86_64 completo. Arquivos `.tar.xz` precisam ser convertidos antes, no PC: `xz -dc rootfs.tar.xz | gzip > rootfs.tar.gz`. O app extrai o arquivo para o armazenamento interno (`files/vm/rootfs/`) e inicia a VM com essa pasta como raiz, via virtio-9p. O kernel e o initrd são encontrados automaticamente em `/boot`.

Requisitos do rootfs:

- `/boot/vmlinuz-*` (obrigatório) e, de preferência, `/boot/initrd.img-*`.
- O initramfs precisa carregar os módulos de 9p, senão a raiz não monta. No Debian:
  ```bash
  echo -e "9p\n9pnet\n9pnet_virtio" | sudo tee -a /etc/initramfs-tools/modules
  sudo update-initramfs -u
  ```
- `/sbin/init` (no Debian, systemd).

Gerando o rootfs num PC Linux:

```bash
sudo debootstrap --arch=amd64 --include=linux-image-amd64,initramfs-tools,xfce4,lightdm,wine64 \
     bookworm rootfs http://deb.debian.org/debian
# (aplique a configuração do initramfs acima dentro do rootfs, via chroot)
sudo tar -C rootfs -czf wine-rootfs.tar.gz .
```

Depois copie `wine-rootfs.tar.gz` para o celular e use **Importar rootfs**.

Se houver rootfs e disco importados ao mesmo tempo, o rootfs é usado. O disco `.qcow2` continua disponível como alternativa, e costuma ser mais rápido que 9p.

**Limitações:**

- Root via 9p é mais lento que disco de bloco. Sob TCG, o primeiro boot do systemd pode levar vários minutos.
- A extração de um rootfs grande (centenas de MB) é lenta no celular.
- Dispositivos (`/dev/*`) e FIFOs do tar são ignorados, porque o Android não permite criá-los.

## Compilar no AndroidIDE (no próprio celular)

1. Instale o AndroidIDE pela Play Store ou pelo GitHub (`AndroidIDE`) e abra-o uma vez para concluir a configuração inicial. Ele já traz o JDK 17.
2. Copie `Wineqm.zip` para o armazenamento do celular e extraia-o (por exemplo em `Documentos/`).
3. No AndroidIDE: **Open Project** e selecione a pasta extraída. Aguarde o Gradle sincronizar; a primeira vez baixa o Gradle 8.2 e o AGP, então precisa de internet.
4. Se o `gradlew` der "Permission denied", rode no terminal do AndroidIDE:
   ```bash
   chmod +x gradlew
   ```
5. Build: **Build > Build Project**, ou no terminal `./gradlew assembleDebug`. O APK sai em `app/build/outputs/apk/debug/`.
6. Testes unitários: `./gradlew testDebugUnitTest`.

Não é preciso configurar `JAVA_HOME` nem instalar nada à parte. O AndroidIDE usa o JDK e o SDK próprios.

Se o AndroidIDE pedir para instalar um SDK ou plataforma (API 34), aceite. Se o Gradle reclamar da versão do AGP, reduza para `8.1.4` em `build.gradle` e para `8.0` no Gradle wrapper.

## Build (computador)

Requer JDK 17 e Android Studio Hedgehog ou mais novo. Se o `JAVA_HOME` do seu sistema apontar para um caminho inválido, corrija-o ou remova-o antes de rodar `./gradlew`.

```bash
./gradlew testDebugUnitTest   # testes unitários
./gradlew assembleDebug       # APK em app/build/outputs/apk/debug/
```

## Limitações conhecidas

- **Desempenho:** a VM roda por emulação TCG, sem KVM, pois apps Android comuns
  não têm acesso a `/dev/kvm`. Emular x86_64 em um SoC arm64 é lento, e Wine
  dentro da VM fica ainda mais pesado. Espere algo bem abaixo de um PC comum.
- **Alternativa mais prática:** uma guest arm64 (`qemu-system-aarch64`) com
  box64 + Wine evita uma camada de emulação. É a rota usada por projetos como
  Winlator, e normalmente roda mais rápido. Se fizer sentido para você, o
  `QemuCommand` muda pouco.
- **Memória:** `ramMb` é fixo em 4096 em `MainActivity`. Ajuste conforme o aparelho.
- **Sem áudio** no momento.
- **Ciclo de vida:** a VM é encerrada quando o app fecha, mas ainda não há um
  Foreground Service. Se o Android matar o app em segundo plano, a VM também cai.
- **Importação:** o disco é copiado para o armazenamento interno. Imagens grandes
  demoram e ocupam espaço duplicado durante a cópia.
