package com.winvm.app.qemu

import java.io.File

/** Descobre os núcleos "rápidos" do celular (big/prime) para fixar o QEMU neles. */
object CpuTopology {
    /**
     * Lista de núcleos para o `taskset -c` (ex.: "4,5,6,7"), ou null quando os núcleos são todos iguais
     * ou o Android não deixa ler as frequências.
     */
    fun fastCores(): String? = try {
        val freqs = HashMap<Int, Long>()
        File("/sys/devices/system/cpu").listFiles()?.forEach { d ->
            val m = Regex("cpu(\\d+)").matchEntire(d.name) ?: return@forEach
            val v = runCatching { File(d, "cpufreq/cpuinfo_max_freq").readText().trim().toLong() }.getOrNull()
                ?: return@forEach
            freqs[m.groupValues[1].toInt()] = v
        }
        if (freqs.size < 4) {
            null
        } else {
            val max = freqs.values.max()
            val min = freqs.values.min()
            if (min.toDouble() >= max * 0.75) {
                null                                             // núcleos iguais: nada a fixar
            } else {
                val fast = freqs.filter { it.value >= max * 0.75 }.keys.sorted()
                val chosen = if (fast.size >= 2) fast
                else freqs.entries.sortedByDescending { it.value }.take(2).map { it.key }.sorted()
                chosen.joinToString(",")
            }
        }
    } catch (e: Exception) {
        null
    }
}
