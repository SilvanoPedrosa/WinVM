package com.winvm.app.qemu

import com.winvm.app.model.VmConfig
import java.io.File

/** Mapeia discos/ISO do Android para caminhos simples dentro do Alpine (/vm, /ext0...). */
class DiskMounts(private val vmDir: File, cfg: VmConfig) {
    private fun normalized(path: String): String = runCatching { File(path).canonicalPath }.getOrElse { File(path).absolutePath }
    private val vmPath = normalized(vmDir.path)
    private val extDirs: List<String> =
        (listOf(cfg.diskPath) + cfg.extraDisks.map { it.path } + listOfNotNull(cfg.isoPath))
            .mapNotNull { File(it).absoluteFile.parentFile?.let { parent -> normalized(parent.path) } }
            .filter { it != vmPath }
            .distinct()

    fun isExternal(hostPath: String): Boolean =
        File(hostPath).absoluteFile.parentFile?.let { normalized(it.path) } in extDirs

    fun guestPath(hostPath: String): String {
        val f = File(hostPath)
        val parent = f.absoluteFile.parentFile?.let { normalized(it.path) }
        val idx = extDirs.indexOf(parent)
        return if (idx >= 0) "/ext$idx/${f.name}" else "/vm/${f.name}"
    }

    /** Diretórios externos montados pelo proot. */
    fun binds(): List<Pair<String, String>> = extDirs.mapIndexed { i, d -> d to "/ext$i" }
}
