package com.winvm.app.qemu

import com.winvm.app.model.VmConfig
import java.io.File
import java.io.RandomAccessFile

/**
 * Lê o disco em segundo plano (prioridade mínima) enquanto o QEMU inicia, para o Android
 * já deixá-lo no cache de memória. Ao retomar uma VM hibernada lê também o fim do arquivo,
 * onde fica o estado da RAM salvo.
 */
object DiskWarmup {
    private const val MB = 1024L * 1024L

    fun start(cfg: VmConfig, resume: Boolean) {
        Thread({
            runCatching {
                // Pré-aquece uma amostra pequena: leituras enormes em paralelo podem atrasar o boot.
                val disks = listOf(cfg.diskPath) + cfg.extraDisks.map { it.path }
                disks.distinct().forEachIndexed { index, path ->
                    val f = File(path)
                    if (f.isFile && f.canRead()) {
                        read(f, 0L, if (index == 0) 32 * MB else 16 * MB)
                        if (resume && index == 0) read(f, maxOf(0L, f.length() - 128 * MB), 128 * MB)
                    }
                }
                cfg.isoPath?.let { iso ->
                    val i = File(iso)
                    if (!resume && i.isFile && i.canRead()) read(i, 0L, 32 * MB)
                }
            }
        }, "disk-warmup").apply {
            priority = Thread.MIN_PRIORITY
            isDaemon = true
        }.start()
    }

    private fun read(file: File, offset: Long, bytes: Long) {
        RandomAccessFile(file, "r").use { raf ->
            val total = raf.length()
            var pos = offset.coerceIn(0L, total)
            val end = minOf(total, pos + bytes)
            raf.seek(pos)
            val buf = ByteArray(1 shl 20)
            while (pos < end) {
                val n = raf.read(buf, 0, minOf(buf.size.toLong(), end - pos).toInt())
                if (n <= 0) break
                pos += n
            }
        }
    }
}
