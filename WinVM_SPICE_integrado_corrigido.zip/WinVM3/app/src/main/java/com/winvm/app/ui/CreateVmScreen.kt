package com.winvm.app.ui

import android.app.Application
import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Environment
import android.widget.Toast
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.winvm.app.model.DiskRef
import com.winvm.app.model.VmConfig
import com.winvm.app.model.VmRepository
import com.winvm.app.qemu.Rootfs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class CreateVmViewModel(private val app: Application) : AndroidViewModel(app) {
    var name by mutableStateOf("Windows")
    var ramMb by mutableStateOf(2048f)
    var virtualRam by mutableStateOf(0f)
    var cpus by mutableStateOf(2f)
    var diskGb by mutableStateOf(32f)
    var useExistingDisk by mutableStateOf(false)
    var saveInDownload by mutableStateOf(true)
    var diskUri by mutableStateOf<Uri?>(null)
    var diskName by mutableStateOf<String?>(null)
    val extraDisks = mutableStateListOf<Pair<Uri, String>>()
    var isoUri by mutableStateOf<Uri?>(null)
    var resW by mutableStateOf(0)
    var resH by mutableStateOf(0)
    var cpuModel by mutableStateOf("Nehalem")      // sem AVX: costuma ser mais rápido na emulação
    var diskTurbo by mutableStateOf(true)
    var cpuTurbo by mutableStateOf(true)
    var quickStart by mutableStateOf(true)
    var spice by mutableStateOf(false)
    var videoCard by mutableStateOf("std")
    var vramMb by mutableStateOf(32)
    var netModel by mutableStateOf("e1000")
    var audioCard by mutableStateOf("hda")
    var busy by mutableStateOf(false)
    var copiedMb by mutableStateOf(0L)
    var errorMsg by mutableStateOf<String?>(null)
    private var copiedBytes = 0L

    private fun displayName(uri: Uri): String {
        app.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0) ?: "arquivo"
        }
        return uri.lastPathSegment ?: "arquivo"
    }

    fun pickDisk(uri: Uri?) {
        diskUri = uri
        diskName = uri?.let { displayName(it) }
    }

    fun addExtra(uri: Uri?) {
        if (uri != null && extraDisks.size < 2) extraDisks.add(uri to displayName(uri))
    }

    private fun extOf(name: String): String =
        name.substringAfterLast('.', "").lowercase().filter { it.isLetterOrDigit() }.take(6).ifEmpty { "img" }

    private fun copyUri(uri: Uri, dest: File) {
        app.contentResolver.openInputStream(uri)!!.use { i ->
            dest.outputStream().use { o ->
                val buf = ByteArray(1 shl 20)
                while (true) {
                    val r = i.read(buf)
                    if (r < 0) break
                    o.write(buf, 0, r)
                    copiedBytes += r
                    copiedMb = copiedBytes / (1024L * 1024L)
                }
            }
        }
    }

    /** Pergunta ao qemu-img qual é o formato (qcow2, vpc = VHD, vhdx, vmdk, vdi, raw). */
    /** Arquivo novo em Download/WinVM/<nome>.qcow2, ou null se a pasta não aceitar escrita. */
    @Suppress("DEPRECATION")
    private fun downloadDiskFile(name: String): File? = try {
        val folder = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "WinVM")
        if (!folder.exists() && !folder.mkdirs()) {
            null
        } else {
            val probe = File(folder, ".winvm_probe")
            probe.writeText("ok")
            probe.delete()
            var f = File(folder, "$name.qcow2")
            var i = 2
            while (f.exists()) {
                f = File(folder, "${name}_$i.qcow2")
                i++
            }
            f
        }
    } catch (e: Exception) {
        null
    }

    private suspend fun detectFormat(dir: File, f: File): String {
        val out = StringBuilder()
        Rootfs.runGuest(app, listOf("qemu-img", "info", "/vm/${f.name}"), dir) { out.appendLine(it) }
        val fmt = Regex("file format:\\s*(\\S+)").find(out.toString())?.groupValues?.get(1)
        val ext = f.extension.lowercase()
        return when {
            fmt == null -> when (ext) {
                "qcow2" -> "qcow2"; "vhd" -> "vpc"; "vhdx" -> "vhdx"; "vmdk" -> "vmdk"; "vdi" -> "vdi"
                else -> "raw"
            }
            fmt == "raw" && ext == "vhd" -> "vpc"      // VHD de tamanho fixo costuma ser lido como raw
            else -> fmt
        }
    }

    fun create(onReady: (VmConfig) -> Unit) {
        viewModelScope.launch {
            busy = true; errorMsg = null; copiedMb = 0; copiedBytes = 0
            val n = name.trim()
            var externalDisk: File? = null
            try {
                if (!Rootfs.isReady(app)) {
                    throw IllegalStateException("Instale o ambiente Linux primeiro (tela inicial › Instalar agora).")
                }
                val cfg = withContext(Dispatchers.IO) {
                    val dir = File(VmRepository.root(app), n)
                    if (dir.exists()) throw IllegalStateException("Já existe uma VM com esse nome")
                    dir.mkdirs()

                    val iso = isoUri?.let { uri -> File(dir, "boot.iso").also { copyUri(uri, it) } }

                    val diskFile: File
                    val diskFormat: String
                    val existing = diskUri
                    if (useExistingDisk && existing != null) {
                        diskFile = File(dir, "disk.${extOf(displayName(existing))}")
                        copyUri(existing, diskFile)
                        diskFormat = detectFormat(dir, diskFile)
                    } else {
                        // Disco novo: na pasta Download (acessível fora do app) ou, se não der, dentro do app
                        var target = File(dir, "disk.qcow2")
                        var guestDisk = "/vm/disk.qcow2"
                        var binds: List<Pair<String, String>> = emptyList()
                        if (saveInDownload) {
                            val d = downloadDiskFile(n)
                            if (d != null) {
                                target = d
                                guestDisk = "/ext0/${d.name}"
                                binds = listOf(d.parentFile!!.path to "/ext0")
                                externalDisk = d
                            } else {
                                withContext(Dispatchers.Main) {
                                    Toast.makeText(
                                        app,
                                        "Sem acesso à pasta Download. O disco foi salvo dentro do app.",
                                        Toast.LENGTH_LONG
                                    ).show()
                                }
                            }
                        }
                        diskFile = target
                        val out = StringBuilder()
                        val code = Rootfs.runGuest(
                            app,
                            listOf("qemu-img", "create", "-f", "qcow2", "-o", "preallocation=metadata,lazy_refcounts=on",
                                guestDisk, "${diskGb.toInt()}G"),
                            dir,
                            binds
                        ) { out.appendLine(it) }
                        if (code != 0) throw IllegalStateException("Falha ao criar o disco (código $code): $out")
                        diskFormat = "qcow2"
                    }

                    val extras = extraDisks.toList().mapIndexed { i, (uri, nm) ->
                        val f = File(dir, "extra${i + 1}.${extOf(nm)}")
                        copyUri(uri, f)
                        DiskRef(f.path, detectFormat(dir, f))
                    }

                    val idx = VmRepository.nextIndex(app)
                    VmConfig(
                        name = n, ramMb = ramMb.toInt(), cpus = cpus.toInt(),
                        diskPath = diskFile.path, isoPath = iso?.path,
                        vncPort = idx, qmpPort = 4444 + idx,
                        diskFormat = diskFormat, extraDisks = extras,
                        width = resW, height = resH,
                        cpuModel = cpuModel, videoCard = videoCard, vramMb = vramMb,
                        netModel = netModel, audioCard = audioCard, diskTurbo = diskTurbo,
                        cpuTurbo = cpuTurbo, quickStart = quickStart, spice = spice,
                        virtualRamMb = virtualRam.toInt()
                    ).also { VmRepository.save(app, it) }
                }
                onReady(cfg)
            } catch (e: Exception) {
                externalDisk?.delete()          // não deixa disco órfão na pasta Download
                File(VmRepository.root(app), n).let { d ->
                    if (d.exists() && !File(d, "vm.json").exists()) d.deleteRecursively()
                }
                errorMsg = e.message
            } finally {
                busy = false
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateVmScreen(
    vm: CreateVmViewModel = viewModel(),
    onBack: () -> Unit = {},
    onCreated: (VmConfig) -> Unit
) {
    val isoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { vm.isoUri = it }
    val diskPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { vm.pickDisk(it) }
    val extraPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { vm.addExtra(it) }

    val hasBoot = vm.isoUri != null || (vm.useExistingDisk && vm.diskUri != null)
    val diskOk = !vm.useExistingDisk || vm.diskUri != null
    val primary = MaterialTheme.colorScheme.primary
    val ctx = LocalContext.current
    val storagePermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        vm.create(onCreated)    // se negar, o app tenta mesmo assim e, sem acesso, salva dentro do app
    }

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = { Text("Nova VM") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Voltar") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.TopCenter) {
            Column(
                Modifier.widthIn(max = 640.dp).fillMaxWidth().verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                SectionCard("Identificação", "Como a VM aparece na lista") {
                    OutlinedTextField(
                        value = vm.name,
                        onValueChange = { vm.name = it.filter { c -> c.isLetterOrDigit() || c == '_' } },
                        label = { Text("Nome") },
                        singleLine = true,
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                SectionCard("Recursos", "Memória e processadores da VM") {
                    RamPicker(vm.ramMb) { vm.ramMb = it }
                    VirtualRamPicker(vm.virtualRam) { vm.virtualRam = it }
                    LabeledSlider("CPUs: ${vm.cpus.toInt()}", vm.cpus, 1f..8f, 6) { vm.cpus = it }
                    Text(
                        "Dica: na emulação, 1 ou 2 CPUs é o mais rápido. Com o CPU turbo ligado, o app usa no máximo 2.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                SectionCard("Armazenamento", "Disco, discos extras e CD de instalação") {
                    GroupTitle("Disco principal")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = !vm.useExistingDisk,
                            onClick = { vm.useExistingDisk = false },
                            label = { Text("Novo (qcow2)") }
                        )
                        FilterChip(
                            selected = vm.useExistingDisk,
                            onClick = { vm.useExistingDisk = true },
                            label = { Text("Usar arquivo existente") }
                        )
                    }
                    if (vm.useExistingDisk) {
                        PickerField(
                            title = "Arquivo de disco",
                            value = vm.diskName ?: "Escolher (.qcow2 .vhd .vhdx .vmdk .vdi .img)",
                            onClick = { diskPicker.launch(arrayOf("*/*")) },
                            trailing = {
                                Text("Escolher", style = MaterialTheme.typography.labelLarge, color = primary)
                            }
                        )
                        Text(
                            "O arquivo é copiado para dentro do app (precisa de espaço livre igual ao tamanho dele).",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        LabeledSlider("Tamanho do disco: ${vm.diskGb.toInt()} GB", vm.diskGb, 16f..128f, 6) { vm.diskGb = it }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Salvar o disco na pasta Download", style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    "Fica em Download/WinVM/<nome>.qcow2, visível no gerenciador de arquivos e mantido " +
                                        "se o app for desinstalado. Pode ficar um pouco mais lento que dentro do app.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(checked = vm.saveInDownload, onCheckedChange = { vm.saveInDownload = it })
                        }
                    }

                    GroupTitle("Discos extras (opcional, até 2)")
                    vm.extraDisks.forEachIndexed { i, e ->
                        PickerField(
                            title = "HD extra ${i + 1}",
                            value = e.second,
                            onClick = { vm.extraDisks.removeAt(i) },
                            trailing = {
                                Text(
                                    "Remover",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                        )
                    }
                    if (vm.extraDisks.size < 2) {
                        PickerField(
                            title = "Adicionar disco",
                            value = ".qcow2 .vhd .vhdx",
                            onClick = { extraPicker.launch(arrayOf("*/*")) },
                            trailing = { Icon(Icons.Default.Add, contentDescription = null, tint = primary) }
                        )
                    }

                    GroupTitle("CD/DVD de instalação")
                    PickerField(
                        title = "ISO do sistema",
                        value = vm.isoUri?.lastPathSegment ?: "Opcional se usar disco existente",
                        onClick = { isoPicker.launch(arrayOf("*/*")) },
                        trailing = {
                            Text("Escolher", style = MaterialTheme.typography.labelLarge, color = primary)
                        }
                    )
                }

                SectionCard("Hardware e tela", "Processador, vídeo, rede e som") {
                    HardwarePickers(
                        cpu = vm.cpuModel, onCpu = { vm.cpuModel = it },
                        card = vm.videoCard, onCard = { vm.videoCard = it },
                        vram = vm.vramMb, onVram = { vm.vramMb = it },
                        net = vm.netModel, onNet = { vm.netModel = it },
                        audio = vm.audioCard, onAudio = { vm.audioCard = it },
                        resW = vm.resW, resH = vm.resH, onRes = { w, h -> vm.resW = w; vm.resH = h }
                    )
                    SwitchRow(
                        title = "Disco turbo",
                        subtitle = "Ignora a gravação forçada no disco: a VM inicia e instala bem mais rápido. " +
                            "Risco pequeno de perder dados se o celular desligar de repente.",
                        checked = vm.diskTurbo,
                        onChange = { vm.diskTurbo = it }
                    )
                    SwitchRow(
                        title = "CPU turbo",
                        subtitle = "Emulação em 1 thread, no máximo 2 CPUs e núcleos rápidos do celular: " +
                            "o sistema abre e roda bem mais rápido.",
                        checked = vm.cpuTurbo,
                        onChange = { vm.cpuTurbo = it }
                    )
                    SwitchRow(
                        title = "Início rápido",
                        subtitle = "Desligar salva a VM (hiberna) e o próximo início volta em segundos, sem dar boot. " +
                            "Só com disco qcow2.",
                        checked = vm.quickStart,
                        onChange = { vm.quickStart = it }
                    )
                    SwitchRow(
                        title = "SPICE integrado no WinVM3",
                        subtitle = "Ativa o servidor SPICE real do QEMU. O botão SPICE abre o cliente HTML5 dentro do WinVM3; " +
                            "na primeira compilação é necessário internet para baixar o cliente.",
                        checked = vm.spice,
                        onChange = { vm.spice = it }
                    )
                    Text(
                        "Linux ajusta a resolução sozinho. No Windows/ReactOS, depois de iniciar, confirme em " +
                            "Propriedades de vídeo. Dá para mudar tudo isso depois, com a VM parada (botão Configurar).",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                vm.errorMsg?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(horizontal = 4.dp))
                }
                if (vm.busy) {
                    Text(
                        "Copiando arquivos… ${vm.copiedMb} MB",
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )
                }

                Button(
                    onClick = {
                        val needPermission = vm.saveInDownload && !vm.useExistingDisk &&
                            ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) !=
                            PackageManager.PERMISSION_GRANTED
                        if (needPermission) storagePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        else vm.create(onCreated)
                    },
                    enabled = !vm.busy && vm.name.isNotBlank() && hasBoot && diskOk,
                    modifier = Modifier.fillMaxWidth().height(56.dp)
                ) {
                    if (vm.busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                    else Text("Criar e iniciar", style = MaterialTheme.typography.titleMedium)
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun LabeledSlider(
    label: String, value: Float, range: ClosedFloatingPointRange<Float>,
    steps: Int, onChange: (Float) -> Unit
) {
    Column {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Slider(value = value, onValueChange = onChange, valueRange = range, steps = steps)
    }
}
