package com.winvm.app.ui

import android.annotation.SuppressLint
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.unit.dp
import com.winvm.app.model.VmConfig

/** Cliente SPICE HTML5 incorporado en el WebView del propio WinVM. */
@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun SpiceScreen(cfg: VmConfig, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    Scaffold(topBar = {
        TopAppBar(
            title = { Text("SPICE integrado") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Voltar") } }
        )
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Surface(color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.fillMaxWidth()) {
                Text(
                    "Cliente SPICE dentro do WinVM3. No cliente, conecte ao WebSocket local 127.0.0.1:${cfg.spicePort + 1}; o proxy encaminha para a porta SPICE ${cfg.spicePort}.",
                    Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall
                )
            }
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { context ->
                    WebView(context).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.allowFileAccess = true
                        settings.allowContentAccess = true
                        settings.mediaPlaybackRequiresUserGesture = false
                        settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                        settings.useWideViewPort = true
                        settings.loadWithOverviewMode = true
                        webChromeClient = WebChromeClient()
                        webViewClient = WebViewClient()
                        // O cliente SPICE HTML5 recebe o host/porta do proxy WebSocket local.
                        // O proxy websockify liga esta porta ao servidor SPICE real do QEMU.
                        val url = Uri.parse("file:///android_asset/spice-client/spice.html")
                            .buildUpon()
                            .appendQueryParameter("host", "127.0.0.1")
                            .appendQueryParameter("port", (cfg.spicePort + 1).toString())
                            .build()
                        loadUrl(url.toString())
                    }
                },
                update = { }
            )
        }
    }
}
